﻿using System.Threading.Tasks;
using NUnit.Framework;

namespace Core.UnitTests.Services
{
    [TestFixture]
    public class FechasServiceTests
    {
       
        [Test]
        public async Task EsDiaHabil_CuandoEsFinDeSemana_RetornaNo()
        {
        }

        [Test]
        public async Task EsDiaHabil_CuandoEsFeriado_RetornaNo()
        {
        }

        [Test]
        public async Task EsDiaHabil_CuandoEsDiaHabil_RetornaSi()
        {
        }
    }
}
