﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum EstadoBloqueo
    {
       Exitoso = 1,
       Erroneo = 2
    }
}
