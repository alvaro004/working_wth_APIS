﻿namespace Continental.API.Core.Enums
{
    public static class ParametricaRenovacion
    {
        public const decimal Id = 26860;
        public const string TipoMotivoTransferencia = "MOTIVO_TRANSFERENCIA";
        public const string Prendido = "PRENDIDO";
        public const decimal SecuenciaSwitchEjecucion = 7;
        public const decimal SecuenciaEstadoBepsaOk = 8;
        public const decimal SecuenciaEstadoBepsaNoOk = 9;
        public const decimal SecuenciaParametrosConsulta = 11;
    }
}
