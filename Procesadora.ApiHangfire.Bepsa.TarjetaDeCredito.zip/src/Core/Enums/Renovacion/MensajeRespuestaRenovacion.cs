﻿namespace Continental.API.Core.Enums
{
    public static class MensajeRespuestaRenovacion
    {
        public const string Procesado = "Procesado";
        public const string ErrorAutenticacionServicioBepsa = "No se pudo obtener el token del servicio de Bepsa";
        public const string ErrorTransmisionRenovaciones = "No se pudo realizar la transmisión de las renovaciones a la procesadora";
        public const string ErrorConsultaRenovaciones = "No se pudo obtener el estado del lote de renovaciones enviado a la procesadora";
        public const string ErrorInterno = "Ocurrió un error interno en el servicio";
    }
}
