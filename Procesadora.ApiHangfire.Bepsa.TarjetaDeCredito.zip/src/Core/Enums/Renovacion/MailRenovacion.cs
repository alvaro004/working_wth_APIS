﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.Renovacion
{
    public static class MailRenovacion
    {
        public const string EstadoError = "Error";
        public const string ObservacionError = "Quedará pendiente en el servicio: ";

        public const string EstadoConsultaCancelada = "Consulta cancelada";
        public const string ObservacionConsultaCancelada = "Se cancela la consulta del seguimiento a la procesadora";
    }
}
