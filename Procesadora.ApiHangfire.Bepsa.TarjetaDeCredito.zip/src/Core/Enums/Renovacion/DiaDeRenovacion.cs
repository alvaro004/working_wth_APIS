﻿namespace Continental.API.Core.Enums
{
    public static class DiaDeRenovacion
    {
        public const string Si = "S";
        public const string No = "N";

    }
}
