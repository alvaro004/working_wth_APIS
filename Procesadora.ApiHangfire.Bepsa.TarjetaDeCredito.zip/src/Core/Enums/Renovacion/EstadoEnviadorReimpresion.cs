﻿namespace Continental.API.Core.Enums
{
    public enum EstadoEnviadorReimpresion
    {
        Cancelado,
        Pendiente,
        Rechazado,
        Correcto
    }
}
