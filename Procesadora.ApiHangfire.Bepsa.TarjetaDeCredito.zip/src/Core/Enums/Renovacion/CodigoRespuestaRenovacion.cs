﻿namespace Continental.API.Core.Enums
{
    public static class CodigoRespuestaRenovacion
    {
        public const string Procesado = "00";
        public const string ErrorAutenticacionServicioBepsa = "90";
        public const string ErrorTransmisionRenovaciones = "91";
        public const string ErrorConsultaRenovaciones = "92";
        public const string ErrorInterno = "99";
    }
}
