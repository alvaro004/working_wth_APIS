﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.Renovacion
{
    public static class EstadoServicioRenovacion
    {
        public const string Encendido = "S";
        public const string Apagado = "N";
    }
}
