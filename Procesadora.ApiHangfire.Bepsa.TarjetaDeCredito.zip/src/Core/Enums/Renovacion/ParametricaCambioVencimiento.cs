﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.Renovacion
{
    public class ParametricaCambioVencimiento
    {
        public const decimal Id = 16572;
        public const string Prendido = "PRENDIDO";
        public const decimal SecuenciaSwitch = 4;
        public const decimal SecuenciaDatos = 3;
    }
}
