﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public static class EstadoProceso
    {
        public static string Disponible = "D";
        public static string Ocupado = "O";
    }
}
