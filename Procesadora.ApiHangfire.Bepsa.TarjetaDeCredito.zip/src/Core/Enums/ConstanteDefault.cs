﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public static class ConstanteDefault
    {
        public const string PagoProcesado = "SI";

        public const string PagoCancelado = "CC";

        public const string CodigoRespuestaOk = "00";

        public const string CodigoRespuestaRechazo = "10";

        public const string CodigoRespuestaError = "99";

        public const string MensajePagado = "APROBADA ID SEGUIMIENTO: ";

        public const string MensajeCancelado = "PAGO CANCELADO ID SEGUIMIENTO: ";

        public const string MensajeRechazo = "PAGO RECHAZADO ID SEGUIMIENTO: ";

        public const string UsuarioProceso = "TAR";

        public const string ProcesadoCorrectamente = "S";

        public const string Activar = "A";

        public const string ObservacionActivacion = "ALTA Y PIN";

        public const string TipoTransaccionPush = "TRANSACCIONES";

        public const string MarcaInternacional = "I";
    }
}
