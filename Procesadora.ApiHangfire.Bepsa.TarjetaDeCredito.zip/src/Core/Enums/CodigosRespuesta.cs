﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Enums
{
    static class CodigosRespuesta
    {
        public const string Procesado = "00";

        public const string CuentaYaActiva = "53";

    }
}
