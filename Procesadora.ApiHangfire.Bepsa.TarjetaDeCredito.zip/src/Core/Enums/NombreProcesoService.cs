﻿
namespace Continental.API.Core.Enums
{
    public class NombreProcesoService
    {
        public const string RenovacionService = "Renovacion";
        public const string ConsultaRenovacionService = "Consulta Renovacion";
    }
}
