﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum EnumMethods
    {
        Default,
        ConsultaPago,
        ConsultaEstado
    }
}
