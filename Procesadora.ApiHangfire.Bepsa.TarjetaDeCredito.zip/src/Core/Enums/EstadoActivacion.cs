﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Enums
{
    public enum EstadoActivacion

    {
        EstadoPendienteActivacionCuenta = 0,
        EstadoTarjetaActivada = 1,
        EstadoPendienteActivacionTarjeta = 2,
        EstadoCanceladoReintentos = 99,
        TipoActivacionCorrecta = 1,
        TipoActivacionError = 0
    }
}
