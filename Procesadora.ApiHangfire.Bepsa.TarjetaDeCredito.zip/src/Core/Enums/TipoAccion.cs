﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum TipoAccion
    {
        BLOQUEO,
        DESBLOQUEO,
        REIMPRESION,
        ALTA
    }
}
