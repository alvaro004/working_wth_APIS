﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    static class TipoEmailBloqueoDesbloqueo
    {
        public const string TarjetaBloqueadaConExito = "PROCESADO";
        public const string ErrorAlProcesarEnBepsa = "ERRORTC";
        public const string CancelacionEnvioBloqueo = "CANCELADO";
        public const string ErrorInterno = "ERRORINTERNO";
    }
}