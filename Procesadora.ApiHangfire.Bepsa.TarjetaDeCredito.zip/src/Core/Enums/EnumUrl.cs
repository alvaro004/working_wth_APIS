﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum EnumUrl
    {
        AutenticacionPago,
        ServicioPago,
        Servicio,
        ConsultaEstadoAlta,
        ActivacionTarjeta,
        ActivacionCuenta,
        ServicioReverso,
        ServicioListaBlanca
    }
}
