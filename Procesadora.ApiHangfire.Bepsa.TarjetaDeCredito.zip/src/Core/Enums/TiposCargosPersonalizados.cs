﻿namespace Continental.API.Core.Enums
{
    public static class TiposCargosPersonalizados
    {
        public const string Defecto = "00";
        public const string SeguroDeVida = "164";
        public const string MantenimientoAnual = "27";

    }
}
