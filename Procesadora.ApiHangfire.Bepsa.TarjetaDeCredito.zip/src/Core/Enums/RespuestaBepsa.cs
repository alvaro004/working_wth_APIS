﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public static class RespuestaBepsa
    {
        public static string Aprobada = "00";
        public static string UsuarioContrasenaNoValido = "07";
        public static string UsuarioSinPermiso = "08";
        public static string DireccionIpNoValida = "09";
        public static string UsuarioIpNoCorrespondenEntidad = "10";
        public static string CantidadInvocacionesSuperaLimite = "11";
        public static string CantidadInvocacionesSuperaLimitePorDia = "12";
        public static string SuperaCantidadRegistrosAProcesar = "13";
        public static string NoExisteRegistrosAProcesar = "14";
        public static string ProcesoDeCorteEnEjecucion = "15";
        public static string ExisteTransmisionesPendientes = "16";
        public static string RangoHorarioNoHabilitado = "17";
        public static string FormatoJsonIncorrecto = "57";
        public static string NoSePermitenValoresNulosOVacios = "58";
        public static string ParametroEntradaIncorrectoOInvalido = "72";
        public static string SeDebeCargarCuentaAdherenteEmisionOTarjeta = "74";
        public static string Error = "99";
    }
}
