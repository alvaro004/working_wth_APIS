﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum EnumEstadoPago
    {
        Pagado = 1,
        cancelado = 2,
        Reversado = 4,
        ReversoCancelado = 5
    }
}
