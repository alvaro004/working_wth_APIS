﻿
namespace Continental.API.Core.Enums
{
    public enum TareasRecurrentes
    {
         Renovacion,
         ConsultaRenovacion,
         CambioVencimiento
    }
}
