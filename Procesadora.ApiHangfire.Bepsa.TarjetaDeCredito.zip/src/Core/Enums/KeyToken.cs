﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Enums
{
    public enum KeyToken
    {
        SERVICIO,
        WALEDBLOQUEO,
        WALEDDESBLOQUEO,
        AUTENTICARSERVICIOBEPSA,
        RENOVACIONBEPSA,
        CONSULTARENOVACIONBEPSA,
        CAMBIOVENCIMIENTO
    }
}
