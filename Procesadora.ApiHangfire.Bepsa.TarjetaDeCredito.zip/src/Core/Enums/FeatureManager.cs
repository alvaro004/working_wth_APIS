namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum FeatureManager
    {
        PagoTarjetaWorker,
        TarjetaVirtualWorker,
        ReversoTarjetaWorker,
        AltaListaBlancaWorker,
        BajaListaBlancaWorker
    }
}