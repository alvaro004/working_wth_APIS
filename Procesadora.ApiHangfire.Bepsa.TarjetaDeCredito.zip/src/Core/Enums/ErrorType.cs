﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum ErrorType
    {
        error_interno_servidor,
        validacion_parametro_entrada,
        error_proceso
    }
}
