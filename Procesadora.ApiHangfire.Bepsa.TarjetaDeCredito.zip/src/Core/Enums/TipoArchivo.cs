﻿namespace Continental.API.Core.Enums
{
    public static class TipoArchivo
    {
        public const string Debito = "D";
        public const string Cuenta = "C";
        public const string Persona = "P";
        public const string Tarjeta = "T";
    }
}
