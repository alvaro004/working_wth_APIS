﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public static class RespuestaBloqueoDesbloqueo
    {
        public const string TarjetaBloqueadaDesbloqueada = "00";
        public const string TarjetaNoExiste = "01";
        public const string ParametroEntradaVacio = "21";
        public const string NoExisteTipoBloqueo = "82";
        public const string AccionInvalida = "83";
        public const string BloqueoNoPuedeSerInternacional_AmbitoBloqueoEsTemporal = "84";
    }
}