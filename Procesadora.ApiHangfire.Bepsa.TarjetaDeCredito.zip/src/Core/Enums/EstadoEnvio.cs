﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Enums
{
    public enum EstadoEnvio
    {
        EstadoExitoso = 3,
        EstadoErroneo = 2

    }
}
