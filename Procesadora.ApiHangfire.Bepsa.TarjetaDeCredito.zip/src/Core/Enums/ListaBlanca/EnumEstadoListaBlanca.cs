﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.ListaBlanca
{
    public enum EnumEstadoListaBlanca
    {
        Procesado = 1,
        Cancelado = 2
    }
}
