﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.ListaBlanca
{
    public static class EnumTipoMarca
    {
        public static string Todos = "T";
        public static string Unitario = "U";
    }
}
