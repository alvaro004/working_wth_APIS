﻿
namespace Continental.API.Core.Enums
{
    public enum CodigoProcesadora
    {
        Bancard = 1,
        Cabal = 2,
        Bepsa = 3
    }
}