﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums
{
    public enum EnumParametrica
    {
        ParametricaPago = 115,
        SecuenciaParametros = 1,
        SecuenciaRechazo = 2,
        SecuenciaConsultaEstado = 3,
        SecuenciaParamReversos = 4,
        ParametricaLB = 115,
        SecuenciaParamLB = 5,
        SecuenciaBajaLB = 6,
        SecuenciaConsultaLB = 7,
        ParametricaEstadoLB = 50399,
        ParametricaABM = 118
    }
}
