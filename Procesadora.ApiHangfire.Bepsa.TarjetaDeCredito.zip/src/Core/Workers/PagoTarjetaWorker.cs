using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class PagoTarjetaWorker : BackgroundService
    {
        private readonly ILogger<PagoTarjetaWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public PagoTarjetaWorker(
            ILogger<PagoTarjetaWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("PagoTarjetaWorker stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkPago(stoppingToken);
            }
        }

        private async Task DoWorkPago(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de PagoTarjetaWorker...");
            using var scope = _serviceProvider.CreateScope();
            var scopedFeatureManagement = scope.ServiceProvider.GetRequiredService<IFeatureManager>();
            var isEnablePagoTarjetaWorkerFeature = await scopedFeatureManagement.IsEnabledAsync(nameof(Enums.FeatureManager.PagoTarjetaWorker));
            _logger.LogInformation("PagoTarjetaWorker feature is enable: {isEnablePagoTarjetaWorkerFeature}", isEnablePagoTarjetaWorkerFeature);

            if (!isEnablePagoTarjetaWorkerFeature)
                return;

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkPago(stoppingToken);
        }
    }
}