using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Continental.API.Core.Interfaces;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    internal interface IScopedProcessingService
    {
        Task DoWorkPago(CancellationToken stoppingToken);

        Task DoWorkTarjetaVirtual(CancellationToken stoppingToken);

        Task DoWorkReverso(CancellationToken stoppingToken);

        Task DoWorkAltaListaBlanca(CancellationToken stoppingToken);

        Task DoWorkBajaListaBlanca(CancellationToken stoppingToken);

        Task DoWorkTransmicionABM(CancellationToken stoppingToken);
    }

    internal class ScopedProccessingService : IScopedProcessingService
    {
        private readonly ILogger<ScopedProccessingService> _logger;
        private readonly ITransmisionTarjetaCredito _service;
        private readonly int _retryTimePago;
        private readonly int _retryTimeTarjetaVirutal;
        private readonly int _retryReverso;
        private readonly int _retryABM;
        private readonly IMediator _mediator;
        private readonly int _retryAltaLista;
        private readonly int _retryBajaLista;

        public ScopedProccessingService(
            ILogger<ScopedProccessingService> logger,
            ITransmisionTarjetaCredito service,
            IConfiguration configuration,
            IMediator mediator)
        {
            _logger = logger;
            _service = service;
            _retryTimePago = configuration.GetValue<int?>("TiempoRecurrenteEnSegundoPago") ?? 3;
            _retryTimeTarjetaVirutal = configuration.GetValue<int?>("TimerTarjetaVirtual") ?? 3;
            _retryReverso = configuration.GetValue<int?>("TiempoRecurrenteEnReverso") ?? 3;
            _retryABM = configuration.GetValue<int?>("TiempoRecurrenteABM") ?? 3;
            _mediator = mediator;
            _retryAltaLista = configuration.GetValue<int?>("TiempoRecurrenteAltaLista") ?? 3;
            _retryBajaLista = configuration.GetValue<int?>("TiempoRecurrenteBajaLista") ?? 3;
        }

        public async Task DoWorkPago(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("ServicioPagoTC - Proximo proceso de pago en {retryTime} seg. A las {retryDateTime}.", _retryTimePago, DateTime.Now + TimeSpan.FromMinutes(_retryTimePago));
                await Task.Delay(TimeSpan.FromSeconds(_retryTimePago), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["PagoTarjetaId"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("ServicioPagoTC - Iniciando Worker de pagos de tarjetas...");

                    try
                    {
                        await _service.PagosTarjetaAsync();
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "ServicioPagoTC - Ocurrio un error al procesar los pagos.");
                    }
                }
            }
        }

        public async Task DoWorkTarjetaVirtual(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("ServicioTarjetaVirtual - Proximo proceso de ALTATARJETAVIRTUAL en {retryTime} seg. A las {retryDateTime}.", _retryTimeTarjetaVirutal, DateTime.Now + TimeSpan.FromMinutes(_retryTimeTarjetaVirutal));
                await Task.Delay(TimeSpan.FromSeconds(_retryTimeTarjetaVirutal), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["TarjetaVirtualId"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("ServicioTarjetaVirtual - Iniciando Worker de alta Tarjeta Virtual...");

                    try
                    {
                        await _mediator.Send(new TarjetaVirtualCommand(), stoppingToken);
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error dar la alta.");
                    }
                }
            }
        }

        public async Task DoWorkReverso(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("ServicioReversoTC - Proximo proceso de reverso en {retryTime} seg. A las {retryDateTime}.", _retryReverso, DateTime.Now + TimeSpan.FromMinutes(_retryReverso));
                await Task.Delay(TimeSpan.FromSeconds(_retryReverso), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["ReversoTarjetaId"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("ServicioReversoTC - Iniciando Worker de pagos de tarjetas...");

                    try
                    {
                        await _mediator.Send(new ReversoCommand(), stoppingToken);
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "ServicioReversoTC - Ocurrio un error al procesar los pagos.");
                    }
                }
            }
        }

        public async Task DoWorkTransmicionABM(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("AbmTarjetasCreditoBepsa - Proximo proceso de transmicion en {retryTime} seg. A las {retryDateTime}.", _retryABM, DateTime.Now + TimeSpan.FromMinutes(_retryABM));
                await Task.Delay(TimeSpan.FromSeconds(_retryABM), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["AbmTarjetasCreditoBepsa"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("AbmTarjetasCreditoBepsa - Iniciando Worker de transmicion de alta de TC...");

                    try
                    {
                        await Task.Run(() => _service.AltaBajaModificacionTarjetacredito());
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "AbmTarjetasCreditoBepsa - Ocurrio un error dar la alta.");
                    }
                }
            }
        }

        public async Task DoWorkAltaListaBlanca(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("ServicioListaBlanca - Proximo proceso de alta en {retryTime} seg. A las {retryDateTime}.", _retryAltaLista, DateTime.Now + TimeSpan.FromMinutes(_retryAltaLista));
                await Task.Delay(TimeSpan.FromSeconds(_retryAltaLista), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["AltaListaId"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("ServicioListaBlanca - Iniciando Worker de alta de lista blanca...");

                    try
                    {
                        await _mediator.Send(new ListaBlancaCommand(), stoppingToken);
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "ServicioListaBlanca - Ocurrio un error al procesar las altas.");
                    }
                }
            }
        }

        public async Task DoWorkBajaListaBlanca(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("ServicioBajaListaB - Proximo proceso de baja en {retryTime} seg. A las {retryDateTime}.", _retryBajaLista, DateTime.Now + TimeSpan.FromMinutes(_retryBajaLista));
                await Task.Delay(TimeSpan.FromSeconds(_retryBajaLista), stoppingToken);
                using (_logger.BeginScope(new Dictionary<string, object> { ["BajaListaId"] = Guid.NewGuid() }))
                {
                    _logger.LogInformation("ServicioBajaListaB - Iniciando Worker de baja de lista blanca...");

                    try
                    {
                        await _mediator.Send(new BajaListaBlancaCommand(), stoppingToken);
                    }
                    catch (ApiException.ApiException ae)
                    {
                        _logger.LogWarning(ae, ae.Message);
                    }
                    catch (Exception ex) 
                    {
                        _logger.LogError(ex, "ServicioBajaListaB - Ocurrio un error al procesar las bajas.");
                    }
                }
            }
        }
    }
}