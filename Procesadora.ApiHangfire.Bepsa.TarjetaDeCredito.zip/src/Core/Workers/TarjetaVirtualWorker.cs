﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class TarjetaVirtualWorker : BackgroundService
    {
        private readonly ILogger<TarjetaVirtualWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public TarjetaVirtualWorker(
            ILogger<TarjetaVirtualWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("TarjetaVirtualWorker stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkTarjetaVirtual(stoppingToken);
            }
        }

        private async Task DoWorkTarjetaVirtual(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de TarjetaVirtualWorker...");
            using var scope = _serviceProvider.CreateScope();

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkTarjetaVirtual(stoppingToken);
        }
    }
}
