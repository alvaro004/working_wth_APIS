﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class TransmicionABMWorker : BackgroundService
    {
        private readonly ILogger<TransmicionABMWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public TransmicionABMWorker(
            ILogger<TransmicionABMWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("AbmTarjetasCreditoBepsa stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkTransmicionABM(stoppingToken);
            }
        }

        private async Task DoWorkTransmicionABM(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de AbmTarjetasCreditoBepsa...");
            using var scope = _serviceProvider.CreateScope();

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkTransmicionABM(stoppingToken);
        }
    }
}
