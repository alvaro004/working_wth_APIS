using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class ReversoTarjetaWorker : BackgroundService
    {
        private readonly ILogger<ReversoTarjetaWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public ReversoTarjetaWorker(
            ILogger<ReversoTarjetaWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("ReversoTarjetaWorker stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkReverso(stoppingToken);
            }
        }

        private async Task DoWorkReverso(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de ReversoTarjetaWorker...");
            using var scope = _serviceProvider.CreateScope();
            var scopedFeatureManagement = scope.ServiceProvider.GetRequiredService<IFeatureManager>();
            var isEnableReversoTarjetaWorkerFeature = await scopedFeatureManagement.IsEnabledAsync(nameof(Enums.FeatureManager.ReversoTarjetaWorker));
            _logger.LogInformation("ReversoTarjetaWorker feature is enable: {isEnableReversoTarjetaWorkerFeature}", isEnableReversoTarjetaWorkerFeature);

            if (!isEnableReversoTarjetaWorkerFeature)
                return;

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkReverso(stoppingToken);
        }
    }
}