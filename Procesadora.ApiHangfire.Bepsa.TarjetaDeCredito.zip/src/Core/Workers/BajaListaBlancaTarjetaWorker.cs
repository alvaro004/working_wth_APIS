using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class BajaListaBlancaTarjetaWorker : BackgroundService
    {
        private readonly ILogger<BajaListaBlancaTarjetaWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public BajaListaBlancaTarjetaWorker(
            ILogger<BajaListaBlancaTarjetaWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("BajaListaBlancaTarjetaWorker stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkListaBlancaBaja(stoppingToken);
            }
        }

        private async Task DoWorkListaBlancaBaja(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de BajaListaBlancaTcWorker...");
            using var scope = _serviceProvider.CreateScope();
            var scopedFeatureManagement = scope.ServiceProvider.GetRequiredService<IFeatureManager>();
            var isEnableBajaListaBlancaTarjetaWorkerFeature = await scopedFeatureManagement.IsEnabledAsync(nameof(Enums.FeatureManager.BajaListaBlancaWorker));
            _logger.LogInformation("BajaListaBlancaTcWorker feature is enable: {isEnableBajaListaBlancaTarjetaWorkerFeature}", isEnableBajaListaBlancaTarjetaWorkerFeature);

            if (!isEnableBajaListaBlancaTarjetaWorkerFeature)
                return;

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkBajaListaBlanca(stoppingToken);
        }
    }
}