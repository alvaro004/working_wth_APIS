using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.FeatureManagement;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers
{
    public class ListaBlancaTarjetaWorker : BackgroundService
    {
        private readonly ILogger<ListaBlancaTarjetaWorker> _logger;
        private readonly IServiceProvider _serviceProvider;

        public ListaBlancaTarjetaWorker(
            ILogger<ListaBlancaTarjetaWorker> logger,
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("ListaBlancaTarjetaWorker stopping.");
            await base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await DoWorkListaBlanca(stoppingToken);
            }
        }

        private async Task DoWorkListaBlanca(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Inicio de ListaBlancaTarjetaWorker...");
            using var scope = _serviceProvider.CreateScope();
            var scopedFeatureManagement = scope.ServiceProvider.GetRequiredService<IFeatureManager>();
            var isEnableListaBlancaTarjetaWorkerFeature = await scopedFeatureManagement.IsEnabledAsync(nameof(Enums.FeatureManager.AltaListaBlancaWorker));
            _logger.LogInformation("ListaBlancaTarjetaWorker feature is enable: {isEnableListaBlancaTarjetaWorkerFeature}", isEnableListaBlancaTarjetaWorkerFeature);

            if (!isEnableListaBlancaTarjetaWorkerFeature)
                return;

            var scopedProccessingService = scope.ServiceProvider.GetRequiredService<IScopedProcessingService>();
            await scopedProccessingService.DoWorkAltaListaBlanca(stoppingToken);
        }
    }
}