﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException
{
    public class ApiBepsaError
    {
        public int Codigo { get; set; }
        public string Mensaje { get; set; }
    }
}
