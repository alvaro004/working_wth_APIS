﻿using System;
using System.Runtime.Serialization;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException
{
    [Serializable]
    public class ApiException : Exception
    {
        public string Mensaje { get; set; }
        public int CodigoError { get; set; }
        public int StatusCode { get; set; }

        public ApiException(string mensaje, int codigoError) : base(mensaje)
        {
            this.Mensaje = mensaje;
            this.CodigoError = codigoError;
        }

        public ApiException(string mensaje, int codigoError, int statusCode) : base(mensaje)
        {
            this.Mensaje = mensaje;
            this.CodigoError = codigoError;
            this.StatusCode = statusCode;
        }

        protected ApiException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}