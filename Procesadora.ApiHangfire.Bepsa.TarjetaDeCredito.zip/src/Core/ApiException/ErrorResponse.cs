﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException
{
    public class ErrorResponse
    {
        public ErrorType ErrorType { get; set; }
        public string ErrorDescription { get; set; }
    }
}
