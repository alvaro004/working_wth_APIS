﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Hangfire;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.Renovacion;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;

namespace Continental.API.Core.Interfaces
{
    public class RenovacionService : IRenovacionService
    {
        private readonly IRenovacionRepository _renovacionRepository;
        private readonly ILogger<RenovacionService> _logger;
        private readonly IConexionApi _conexionApi;

        public RenovacionService(IRenovacionRepository renovacionRepository, ILogger<RenovacionService> logger, IConexionApi conexionApi)
        {
            _renovacionRepository = renovacionRepository;
            _logger = logger;
            _conexionApi = conexionApi;
        }

        [DisableConcurrentExecution(timeoutInSeconds: 0)]
        [AutomaticRetry(Attempts = 0, LogEvents = false)]
        public void Renovacion()
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Inicio del servicio de Renovacion de tarjetas de crédito de la procesadora Bepsa");

                if (!ValidarEjecucionServicio(NombreProcesoService.RenovacionService))
                {
                    _logger.LogInformation(NombreProcesoService.RenovacionService + " - Servicio configurado para no ser ejecutado");
                    return;
                }
				
                if (!EsDiaDeRenovacion())
                {
                    _logger.LogInformation(NombreProcesoService.RenovacionService + " - No es día de renovaciones");
                    return;
                }

                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Es día de renovaciones in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);

                var valorParametroJson = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                                  ParametricaRenovacion.SecuenciaParametrosConsulta,
                                                                                  ParametricaRenovacion.Prendido).Result.Valor;

                var parametros = JsonConvert.DeserializeObject<ParametrosRenovacion>(valorParametroJson);

                if (parametros == null)
                {
                    _logger.LogError(NombreProcesoService.RenovacionService + " - No se encontraron los parámetros de configuración para la consulta de renovaciones");
                    return;
                }

                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Se obtuvieron los parámetros de configuración para la consulta de renovaciones {@Parametros} in {Timer} ms",
                    (Object)parametros, timer.Elapsed.TotalMilliseconds);

                var maxIntentos = parametros.MaxIntentos;

                var habilitaHoraEjecucion = (bool)parametros.HabilitaHoraEjecucionRenovacion;
                var horaEjecucion = parametros.HoraRenovacion * 60 + parametros.MinutoRenovacion;
                var horaActual = DateTime.Now.Hour * 60 + DateTime.Now.Minute;

                if (habilitaHoraEjecucion && (horaActual <= horaEjecucion))
                {
                    _logger.LogInformation(NombreProcesoService.RenovacionService + " - Aún no es la hora de ejecución in {Timer} ms",
                            timer.Elapsed.TotalMilliseconds);
                    return;
                }

                // Obtenemos las renovaciones pendientes
                var renovacionPendiente = _renovacionRepository.GetNumeroProcesoPendientesReenvio();
                if (renovacionPendiente.Count == 0)
                {
                    _renovacionRepository.GetNuevoProcesoRenovacion();
                    _logger.LogInformation(NombreProcesoService.RenovacionService + " - Generación de nuevo lote de proceso por renovaciones pendientes de transmisión ejecutado in {Timer} ms",
                        timer.Elapsed.TotalMilliseconds);

                    renovacionPendiente = _renovacionRepository.GetNumeroProcesoPendientesReenvio();
                }

                if (renovacionPendiente.Count == 0)
                {
                    _logger.LogInformation(NombreProcesoService.RenovacionService + " - No se encontraron registros pendientes in {Timer}",
                        timer.Elapsed.TotalMilliseconds);
                    return;
                }

                // Transmitimos las renovaciones a la procesadora Bepsa
                var numeroProceso = renovacionPendiente[0].NumeroProceso;

                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Se obtuvo el numero de proceso {NumeroProceso}, que será transmitido a la procesadora Bepsa in {Timer} ms",
                    numeroProceso, timer.Elapsed.TotalMilliseconds);

                var renovacionBepsaRequest = new RenovacionBepsaRequest
                {
                    Lote = _renovacionRepository.GetLotesReimpresion(numeroProceso)
                };

                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Se encontraron {CantidadRenovaciones} renovaciones pendientes de transmisión a la procesadora Bepsa in {Timer} ms",
                    renovacionBepsaRequest.Lote.Count, timer.Elapsed.TotalMilliseconds);

                var renovacionBepsaResponse = _conexionApi.TransmisionRenovacionBepsa(renovacionBepsaRequest).Result;

                // Actualizamos los registros
                _renovacionRepository.ActualizaDatosEnvio(numeroProceso,
                                                          renovacionBepsaResponse.IdSeguimiento,
                                                          renovacionBepsaResponse.CodigoRespuesta);

                if (renovacionBepsaResponse.CodigoRespuesta != CodigoRespuestaRenovacion.Procesado)
                {
                    _logger.LogWarning(NombreProcesoService.RenovacionService + " - Error en transmision: " + renovacionBepsaResponse.CodigoRespuesta + " - " + renovacionBepsaResponse.MensajeRespuesta);

                    EnviaMail(NombreProcesoService.RenovacionService,
                              renovacionBepsaResponse.CodigoRespuesta + " - " + renovacionBepsaResponse.MensajeRespuesta,
                              MailRenovacion.ObservacionError + NombreProcesoService.RenovacionService,
                              MailRenovacion.EstadoError,
                              numeroProceso.ToString(),
                              string.Empty);
                    return;
                }
                foreach (var item in renovacionBepsaRequest.Lote)
                {
                    _renovacionRepository.ActualizaTransmisionReimpresion(item.TarjetaActual);
                }                
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, NombreProcesoService.RenovacionService + " - Ocurrió un error interno en el servicio de renovaciones de Bepsa");
            }
            finally
            {
                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Fin del servicio de Renovacion de tarjetas de crédito de la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);
            }
        }

        [DisableConcurrentExecution(timeoutInSeconds: 0)]
        [AutomaticRetry(Attempts = 0, LogEvents = false)]
        public void ConsultaRenovacion()
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Inicio del servicio de Consulta de renovaciones de tarjetas de crédito a la procesadora Bepsa");

                if (!ValidarEjecucionServicio(NombreProcesoService.ConsultaRenovacionService))
                {
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Servicio configurado para no ser ejecutado");
                    return;
                }
				
                if (!EsDiaDeRenovacion())
                {
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - No es día de renovaciones");
                    return;
                }

                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Es día de renovaciones in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);

                var valorParametroJson = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                                  ParametricaRenovacion.SecuenciaParametrosConsulta,
                                                                                  ParametricaRenovacion.Prendido).Result.Valor;

                var parametros = JsonConvert.DeserializeObject<ParametrosRenovacion>(valorParametroJson);

                if (parametros == null)
                {
                    _logger.LogError(NombreProcesoService.ConsultaRenovacionService + " - No se encontraron los parámetros de configuración para la consulta de renovaciones");
                    return;
                }

                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Se obtuvieron los parámetros de configuración para la consulta de renovaciones {@Parametros} in {Timer} ms",
                    (Object)parametros, timer.Elapsed.TotalMilliseconds);

                var maxIntentos = parametros.MaxIntentos;

                var habilitaHoraEjecucion = (bool)parametros.HabilitaHoraEjecucionConsulta;
                var horaEjecucion = parametros.HoraConsulta * 60 + parametros.MinutoConsulta;
                var horaActual = DateTime.Now.Hour * 60 + DateTime.Now.Minute;

                if (habilitaHoraEjecucion && (horaActual <= horaEjecucion))
                {
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Aún no es la hora de ejecución in {Timer} ms",
                            timer.Elapsed.TotalMilliseconds);
                    return;
                }

                // Obtenemos el Id de Seguimiento de renovaciones pendientes
                var listSeguimientosPendientes = _renovacionRepository.GetSeguimientosPendientes(maxIntentos).Result;

                if (listSeguimientosPendientes.Count == 0)
                {
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - No se encontraron registros pendientes in {Timer}",
                        timer.Elapsed.TotalMilliseconds);
                    return;
                }

                // Obtenemos los Id de Estado de Bepsa que tomaremos como OK y NOOK
                var parametroEstadoOkBepsa = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                                      ParametricaRenovacion.SecuenciaEstadoBepsaOk,
                                                                                      ParametricaRenovacion.Prendido).Result.Valor;
                var parametroEstadoNoOkBepsa = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                                        ParametricaRenovacion.SecuenciaEstadoBepsaNoOk,
                                                                                        ParametricaRenovacion.Prendido).Result.Valor;

                var estadoBepsaProcesado = JsonConvert.DeserializeObject<List<EstadoRenovacionBepsa>>(parametroEstadoOkBepsa);
                var estadoBepsaPendiente = JsonConvert.DeserializeObject<List<EstadoRenovacionBepsa>>(parametroEstadoNoOkBepsa);

                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Se obtuvieron los parametros para las validaciones de los estados. Procesado: {@Procesado} Pendiente: {@Pendiente} in {Timer}",
                    JsonConvert.SerializeObject(estadoBepsaProcesado, Formatting.Indented), JsonConvert.SerializeObject(estadoBepsaPendiente, Formatting.Indented), timer.Elapsed.TotalMilliseconds);

                // Giramos por los Id de Seguimientos pendientes para obtener los estados
                var cantidadSeguimientosPendientes = listSeguimientosPendientes.Count;
                var cantidadConsultada = 0;
                foreach (var seguimiento in listSeguimientosPendientes)
                {
                    cantidadConsultada++;
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - {CantidadConsultada}/{CantidadSeguimientosPendientes} - Consultamos a Bepsa el id de seguimiento {IdSeguimiento}",
                    cantidadConsultada, cantidadSeguimientosPendientes, seguimiento.Id);
                    var consultaRenovacionBepsaResponse = _conexionApi.ConsultaRenovacionBepsa(seguimiento.Id).Result;
                    
                    if (consultaRenovacionBepsaResponse.CodigoRespuesta != CodigoRespuestaRenovacion.Procesado)
                    {
                        _logger.LogWarning(NombreProcesoService.ConsultaRenovacionService + " - IdSeguimiento: {IdSeguimiento} - Error en la consulta del seguimiento: " + consultaRenovacionBepsaResponse.CodigoRespuesta + " - " + consultaRenovacionBepsaResponse.MensajeRespuesta);

                        EnviaMail(NombreProcesoService.ConsultaRenovacionService,
                                  consultaRenovacionBepsaResponse.CodigoRespuesta + " - " + consultaRenovacionBepsaResponse.MensajeRespuesta,
                                  MailRenovacion.ObservacionError + NombreProcesoService.ConsultaRenovacionService,
                                  MailRenovacion.EstadoError,
                                  seguimiento.NumeroProceso.ToString(),
                                  seguimiento.Id.ToString());

                        continue;
                    }

                    // Actualizamos la cantidad de intentos de este id de seguimiento
                    _renovacionRepository.ActualizarCantidadIntento(seguimiento.Id);
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - IdSeguimiento: {IdSeguimiento} - Se actualizó la cantidad de intentos in {Timer}",
                        seguimiento.Id, timer.Elapsed.TotalMilliseconds);

                    // Si es pendiente, seguimos para poder volver a consultar hasta tener una respuesta
                    var validacionPendiente = consultaRenovacionBepsaResponse.Lote.Any(x => estadoBepsaPendiente.Any(p => p.Estado == x.Estado));
                    if (validacionPendiente)
                    {
                        // Validamos la cantidad de intentos
                        var cantidadIntentos = seguimiento.CantidadIntentos + 1;
                        _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - IdSeguimiento: {IdSeguimiento} - Estado: Pendiente - Intentos del Id de seguimiento: {CantidadIntentos}/{CantidadMaxIntentos} in {Timer}",
                            seguimiento.Id, cantidadIntentos, maxIntentos, timer.Elapsed.TotalMilliseconds);

                        if (cantidadIntentos == maxIntentos)
                        {
                            _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - IdSeguimiento: {IdSeguimiento} - Superó la cantidad máxima de intentos, se procede al envío de mail por cancelación de consulta",
                                seguimiento.Id);

                            EnviaMail(NombreProcesoService.ConsultaRenovacionService,
                                      string.Empty,
                                      MailRenovacion.ObservacionConsultaCancelada,
                                      MailRenovacion.EstadoConsultaCancelada,
                                      seguimiento.NumeroProceso.ToString(),
                                      seguimiento.Id.ToString());
                        }
                        continue;
                    }

                    // Insertamos en el log de procesos si existe en nuestro parámetro de estados OK
                    foreach (var item in consultaRenovacionBepsaResponse.Lote)
                    {
                        // Verificamos si el estado está en el parámetro de estados OK para marcar como procesado
                        if (estadoBepsaProcesado.Any(x => x.IdEstado == item.IdEstado && 
                                                          x.Estado == item.Estado))
                        {
                            _renovacionRepository.InsertaLogProceso(seguimiento.NumeroProceso,
                                                                    seguimiento.Id,
                                                                    consultaRenovacionBepsaResponse.Lote.Count,
                                                                    CodigoRespuestaRenovacion.Procesado,
                                                                    MensajeRespuestaRenovacion.Procesado,
                                                                    item.TarjetaActual);
                        }
                        else
                        {
                            // Si no es Ok, entonces guardamos con el estado que nos envío Bepsa
                            _renovacionRepository.InsertaLogProceso(seguimiento.NumeroProceso,
                                                                    seguimiento.Id,
                                                                    consultaRenovacionBepsaResponse.Lote.Count,
                                                                    item.IdEstado,
                                                                    item.Estado,
                                                                    item.TarjetaActual);
                        }
                    }
                    _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - IdSeguimiento: {IdSeguimiento} - Se insertaron los logs por cada registro",
                        seguimiento.Id);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, NombreProcesoService.ConsultaRenovacionService + " - Ocurrió un error interno en el servicio de consulta de renovaciones de Bepsa");
            }
            finally
            {
                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - Fin del servicio de Consulta de renovaciones de tarjetas de crédito a la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);
            }
        }

        public void EnviaMail(string nombreProceso,
                              string mensaje,
                              string observacion,
                              string estado,
                              string numeroProceso,
                              string idSeguimiento)
        {
            var asuntoMail = $"Servicio de {nombreProceso} de Tarjetas de Crédito Bepsa - {estado}";

            var cuerpoMail = $"Bepsa número proceso: {numeroProceso}\n" +
                             (string.IsNullOrEmpty(idSeguimiento) ? string.Empty : $"Id seguimiento: {idSeguimiento}\n") +
                             $"Estado: {estado}\n" +
                             (string.IsNullOrEmpty(mensaje) ? string.Empty : $"Mensaje de respuesta: {mensaje}\n") +
                             (string.IsNullOrEmpty(observacion) ? string.Empty : $"Observación: {observacion}\n") +
                             $"Fecha: {DateTime.Now:dd/MM/yyyy HH:mm:ss}.";

            _renovacionRepository.GeneraMail(asuntoMail, cuerpoMail);
        }

        public bool EsDiaDeRenovacion()
        {
            var esDiaDeRenovacion = _renovacionRepository.GetEsDiaDeRenovacion();

            if (esDiaDeRenovacion.Equals(DiaDeRenovacion.Si))
            {
                return true;
            }
            else
            {
                var parametrosEjecucion = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                                   ParametricaRenovacion.SecuenciaSwitchEjecucion,
                                                                                   ParametricaRenovacion.Prendido).Result;

                return (parametrosEjecucion?.Valor ?? "N").Equals(DiaDeRenovacion.Si);
            }
        }

        public bool ValidarEjecucionServicio(string nombreProceso)
        {
            var parametrosEjecucion = _renovacionRepository.ObtenerParametrica(ParametricaRenovacion.Id,
                                                                               ParametricaRenovacion.SecuenciaSwitchEjecucion,
                                                                               ParametricaRenovacion.Prendido).Result.ValorDos;

            var parametrosEjecucionRenovacion = JsonConvert.DeserializeObject<ParametrosEjecucionRenovacion>(parametrosEjecucion);

            if (nombreProceso.Equals(NombreProcesoService.RenovacionService))
            {
                return (parametrosEjecucionRenovacion.Renovacion ?? "N").Equals(EstadoServicioRenovacion.Encendido);
            }
            else if (nombreProceso.Equals(NombreProcesoService.ConsultaRenovacionService))
            {
                return (parametrosEjecucionRenovacion.ConsultaRenovacion ?? "N").Equals(EstadoServicioRenovacion.Encendido);
            }
            else
            {
                return false;
            }
        }

        public async Task TransmicionCambioVencimiento()
        {
            _logger.LogInformation("TransmicionCambioVencimiento - Inicio del servicio de TransmicionCambioVencimiento - Obteniendo Tarjetas Entregadas");

            var valorParametroJson = _renovacionRepository.ObtenerParametrica(ParametricaCambioVencimiento.Id,
                                                                                  ParametricaCambioVencimiento.SecuenciaSwitch,
                                                                                  ParametricaCambioVencimiento.Prendido).Result.Valor;
            var parametrica = JsonConvert.DeserializeObject<ParametricaSwitch>(valorParametroJson);

            if (parametrica.Switch)
            {
                _logger.LogWarning("TransmicionCambioVencimiento - Servicio de cambio vencimiento apagado temporalmente");
                return;
            }

            var tarjetas = await ObtenerTarjetasEntregadas();
            if (tarjetas is null || tarjetas.Count == 0)
            {
                _logger.LogInformation("TransmicionCambioVencimiento - No existen tarjetas pendientes de cambio de vencimiento");
                return;
            }
            _logger.LogInformation("TransmicionCambioVencimiento - Cantidad de tarjetas obtenidas: {@cantidad}", tarjetas.Count);
            await ProcesarCambioVencimiento(tarjetas, parametrica.Hilo);
        }

        private async Task<List<TarjetasEntregadasPendientes>> ObtenerTarjetasEntregadas() =>
            await _renovacionRepository.ObtenerTarjetasEntregadas();

        private async Task ProcesarCambioVencimiento(List<TarjetasEntregadasPendientes> tarjetasEntregadas, int hilo)
        {
            try
            {
                var tasks = new List<Task>();
                int count = 0;
                int giro = 0;
                foreach (var tarjeta in tarjetasEntregadas)
                {
                    giro++;
                    _logger.LogInformation("TransmicionCambioVencimiento - Procesando tarjeta: {@tarjeta}", tarjeta.Tarjeta[12..]);
                    var requestCambioVencimiento = PrepararCambioVencimiento(tarjeta);
                    tasks.Add(Task.Run(() => CambioVencimientoPorTarjeta(requestCambioVencimiento)));
                    count++;

                    if (count == hilo)
                    {
                        try
                        {
                            //Esperamos que se ejecuten todas las tareas.
                            await Task.WhenAll(tasks);
                        }
                        catch (AggregateException ae)
                        {
                            foreach (var ex in ae.Flatten().InnerExceptions)
                                _logger.LogError(ex, "TransmicionCambioVencimiento - Ocurrio una excepcion al iniciar el servicio de cambio vencimiento");
                        }
                        count = 0;
                        tasks = new List<Task>();
                    }
                }

                if (tasks.Count > 0)
                    await Task.WhenAll(tasks);
                _logger.LogInformation($"TransmicionCambioVencimiento - total de operaciones procesadas: {giro}.");

            }

            catch (Exception ex)
            {
                _logger.LogError(ex, "TransmicionCambioVencimiento - Error al intentar procesar el cambio de vencimiento");
                throw;
            }
        }

        private async Task CambioVencimientoPorTarjeta(RequestCambioVencimiento tarjetas)
        {
            try
            {
                var resultado = await _conexionApi.ConexionCambioVencimiento(tarjetas, KeyToken.CAMBIOVENCIMIENTO);

                if (!string.IsNullOrWhiteSpace(resultado.Procesados[0].Codigo) && !resultado.Procesados[0].Codigo.Equals(CodigosRespuesta.CuentaYaActiva))
                {
                    _logger.LogError("TransmicionCambioVencimiento - Ocurrio una excepcion al consultar la api de Bepsa: {@error}", resultado.Procesados[0].Mensaje);
                    return;
                }

                await _renovacionRepository.ActualizarTarjetaEntregada(tarjetas.Lote[0]);
                _logger.LogInformation("TransmicionCambioVencimiento - Tarjeta {0} actualizada correctamente.", tarjetas.Lote[0].Tarjeta[12..]);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "TransmicionCambioVencimiento - Ocurrio una excepcion al enviar el cambio de vencimiento de la tarjeta: {@tarjeta}", tarjetas.Lote[0].Tarjeta[12..]);
            }
        }

        private RequestCambioVencimiento PrepararCambioVencimiento(TarjetasEntregadasPendientes tarjeta)
        {
            var parametricaCambioVencimiento = _renovacionRepository.ObtenerParametrica(ParametricaCambioVencimiento.Id, 
                                                                                        ParametricaCambioVencimiento.SecuenciaDatos, 
                                                                                        ParametricaCambioVencimiento.Prendido)
                                                                                            .Result
                                                                                            .Valor;
            var requestCambioVencimiento = JsonConvert.DeserializeObject<LoteCambioVencimiento>(parametricaCambioVencimiento);
            requestCambioVencimiento.Tarjeta = tarjeta.Tarjeta;
            requestCambioVencimiento.FechaEntrega = tarjeta.FechaEntregada;
            return new RequestCambioVencimiento
            {
                Lote = new List<LoteCambioVencimiento>
                {
                    requestCambioVencimiento
                }
            };
        }
    }
}
