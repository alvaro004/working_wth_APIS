﻿using Continental.API.Core.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Services
{
    public class ConexionApiTarjetaVirtual : IConexionApiTarjetaVirtual
    {
        private readonly IConfiguration _configuraciones;
        private readonly HttpClient _apiClient;

        public ConexionApiTarjetaVirtual(IConfiguration configuraciones,
                                         IHttpClientFactory httpClientFactory,
                                         ILogger<ConexionApiTarjetaVirtual> logger)
        {
            _configuraciones = configuraciones;
            int timeout = configuraciones.GetValue<int?>("TimeoutHttpTarjetaVirtual") ?? 180;
            logger.LogInformation("HttpClientTimeoutTarjetaVirtual: {timeout} seg.", timeout);
            _apiClient = httpClientFactory.CreateClient("TarjetaVirtual");
            _apiClient.Timeout = TimeSpan.FromSeconds(timeout);
        }

        //Metodo para obtener las urls.
        public string EndPoint(EnumUrl Url, EnumMethods Methods, dynamic bodyParam)
        {
            if (EnumUrl.AutenticacionPago == Url)
            {
                return EndPointServicio(Url, Methods);
            }
            //Obtenemos la url de la appsetting.
            var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key.ToUpper() == EnumUrl.Servicio.ToString().ToUpper());

            string endpoint = Url switch
            {
                EnumUrl.ConsultaEstadoAlta => credenciales.UrlServicioErrores,
                EnumUrl.ActivacionTarjeta => credenciales.UrlServicioActivacion,
                EnumUrl.ActivacionCuenta => credenciales.UrlServicioCuentaActivacion,
                _ => throw new NotImplementedException()
            };

            //Completamos las urls.
            endpoint += Methods switch
            {
                EnumMethods.Default => string.Empty,
                EnumMethods.ConsultaEstado => bodyParam,
                _ => "/"
            };
            return endpoint;
        }

        public string EndPointServicio(EnumUrl Url, EnumMethods Methods)
        {

            //Obtenemos la url de la appsetting.
            var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key.ToUpper() == Url.ToString().ToUpper());
            var endpoint = credenciales.UrlServicio;

            //Completamos las urls.
            endpoint += Methods switch
            {
                EnumMethods.Default => string.Empty,
                EnumMethods.ConsultaPago => string.Empty,
                EnumMethods.ConsultaEstado => string.Empty,
                _ => throw new NotImplementedException()
            };
            return endpoint;
        }

        public async Task<HttpResponseMessage> InvocarServicios(EnumUrl url,
                                                                EnumMethods methods,
                                                                dynamic bodyParam,
                                                                HttpMethod httpMethod,
                                                                Dictionary<string, string> headers)
        {

            //Obtenemos los endpoints.
            var endpoint = EndPoint(url, methods, bodyParam);

            var requestMessage = new HttpRequestMessage(httpMethod, endpoint);

            if (headers != null)
            {
                foreach (var kvp in headers)
                {
                    requestMessage.Headers.Add(kvp.Key, kvp.Value);
                }
            }

            if (HttpMethod.Get == httpMethod)
            {
                var response = await _apiClient.SendAsync(requestMessage);

                return response;
            }
            else
            {
                string typeBody = bodyParam.GetType().Name;

                requestMessage.Content = new StringContent(typeBody == "String" ? bodyParam.ToString() : JsonConvert.SerializeObject(bodyParam),
                                                Encoding.UTF8, "application/json");

                var response = await _apiClient.SendAsync(requestMessage);

                return response;
            }
        }

        public async Task<HttpResponseMessage> InvocarGetConBody(EnumUrl url,
                                                                 EnumMethods methods,
                                                                 dynamic bodyParam,
                                                                 Dictionary<string, string> headers)
        {

            //Obtenemos los endpoints.
            var endpoint = EndPointServicio(url, methods);

            var requestMessage = new HttpRequestMessage(HttpMethod.Get, endpoint);

            if (headers != null)
            {
                foreach (var kvp in headers)
                {
                    requestMessage.Headers.Add(kvp.Key, kvp.Value);
                }
            }

            string typeBody = bodyParam.GetType().Name;

            requestMessage.Content = new StringContent(typeBody == "String" ? bodyParam.ToString() : JsonConvert.SerializeObject(bodyParam),
                                            Encoding.UTF8, "application/json");

            var response = await _apiClient.SendAsync(requestMessage);

            return response;
        }
    }
}
