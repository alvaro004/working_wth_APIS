﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace Continental.API.Core.Services
{
    public class ConexionApi : IConexionApi
    {
        private CredencialesToken credencialesToken;
        private readonly HttpClient _apiClient;
        private readonly ILogger<ProcesoServices> _logger;
        private CredencialesBepsa credencialeServices_;
        private readonly IConfiguration _configuration;
        private readonly IBloqueoDesbloqueoRepository _bloqueoDesbloqueoRepository;
        public ConexionApi(IOptions<ConfiguracionesCore> configuraciones, HttpClient apiClient, ILogger<ProcesoServices> logger,
                           IConfiguration configuration, IBloqueoDesbloqueoRepository bloqueoDesbloqueoRepository)
        {
            this.credencialesToken = configuraciones.Value.CredencialesToken;
            int timeout = configuration.GetValue<int?>("HttpClientTimeoutFromSeconds") ?? 180;
            logger.LogInformation("HttpClientTimeout: {timeout} seg.", timeout);
            apiClient.Timeout = TimeSpan.FromSeconds(timeout);
            _apiClient = apiClient;
            this._logger = logger;
            this.credencialeServices_ = new CredencialesBepsa();
            _configuration = configuration;
            _bloqueoDesbloqueoRepository = bloqueoDesbloqueoRepository;
        }
        /// <summary>
        /// Metodo de conexion a servicio de generacion de token.
        /// </summary>
        /// <param name="credenciales"></param>
        /// <returns></returns>
        public async Task<WebToken> ConexionAutenticacion(KeyToken credenciales)
        {
            try
            {
                var credencial = credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
                RequestToken requestToken = new RequestToken();
                requestToken.Usuario = credencial.Usuario;
                requestToken.Password = credencial.Password;
                var jsonObject = JsonConvert.SerializeObject(requestToken);
                _logger.LogDebug("@JsonToken ", jsonObject);
                var requestContent = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                _logger.LogDebug("UrlGetToken: "+ credencial.UrlServicio);
                var response = await _apiClient.PostAsync(credencial.UrlServicio, requestContent);
                var jsonResponse = await response.Content.ReadAsStringAsync();
                _logger.LogDebug("Respuesta Token "+jsonResponse);
                var resultado = JsonConvert.DeserializeObject<WebToken>(jsonResponse);
                return new WebToken()
                {
                    Token = resultado.Token
                };
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Metodo de conexion con el proxy de bepspa.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="token"></param>
        /// <param name="credenciales"></param>
        /// <returns></returns>
        public async Task<ResponseAbmTarjeta> ConexionAbmTarjetasCredito(RequestConexionServicioCredito request, string token, KeyToken credenciales)
        {
            var requestContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            _apiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _apiClient.PostAsync(credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault().UrlServicioCredito, requestContent);
            var jsonResponse = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<ResponseAbmTarjeta>(jsonResponse);

            response.EnsureSuccessStatusCode();
            return new ResponseAbmTarjeta()
            {
                CodRespuesta = resultado.CodRespuesta,
                IdSesion = resultado.IdSesion,
                MsgRespuesta = resultado.MsgRespuesta
            };

        }


        /// <summary>
        /// Metodo de conexion con el proxy de bepspa.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="credenciales"></param>
        /// <returns></returns>
        public async Task<CuentaActivacionResponse> ConexionActivacionCuentaTarjeta(RequestConexionServicioActivacion request, KeyToken credenciales)
        {
            _logger.LogInformation("ActivaciónCuentaTarjetaCredito - Obtenemos credenciales del servicio de bepsa.");
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
            request.Clave = credencial.ClaveCuentaActivacion;
            request.Usuario = credencial.UsuarioCuentaActivacion;
            var requestContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            _logger.LogInformation("ActivaciónCuentaTarjetaCredito - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicioCuentaActivacion);
            _logger.LogInformation("ActivaciónCuentaTarjetaCredito - Json enviado a bepsa {@} " + JsonConvert.SerializeObject(request));
            var response = await _apiClient.PostAsync(credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault().UrlServicioCuentaActivacion, requestContent);
            var jsonResponse = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<CuentaActivacionResponse>(jsonResponse);
            _logger.LogInformation("ActivaciónCuentaTarjetaCredito - Respuesta del servicio de bepsa: " + jsonResponse);


            response.EnsureSuccessStatusCode();
            return new CuentaActivacionResponse()
            {
                Codigo = resultado.Codigo,
                Mensaje = resultado.Mensaje,
                Lote = resultado.Lote
            };

        }

        public async Task<TarjetaActivacionResponse> ConexionActivacionTarjetasCredito(RequestConexionServicioActivacionTarjeta request, KeyToken credenciales)
        {
            _logger.LogInformation("ActivaciónTarjetaCredito - Obtenemos credenciales del servicio de bepsa.");
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
            request.Clave = credencial.ClaveActivacion;
            request.Usuario = credencial.UsuarioActivacion;
            var requestContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            _logger.LogInformation("ActivaciónTarjetaCredito - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicioActivacion);
            _logger.LogInformation("ActivaciónTarjetaCredito - Json enviado a bepsa {@} " + JsonConvert.SerializeObject(request));
            var response = await _apiClient.PostAsync(credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault().UrlServicioActivacion, requestContent);
            var jsonResponse = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<TarjetaActivacionResponse>(jsonResponse);
            _logger.LogInformation("ActivaciónTarjetaCredito - Respuesta del servicio de bepsa: " + jsonResponse);

            response.EnsureSuccessStatusCode();
            return new TarjetaActivacionResponse()
            {
                Codigo = resultado.Codigo,
                Mensaje = resultado.Mensaje,
                Lote = resultado.Lote
            };

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="credenciales"></param>
        /// <returns></returns>
        public async Task<ResponseMovEspeciales> ConexionMovimientosEspeciales(RequestEnvioMovEspeciales request, KeyToken credenciales)
        {
            _logger.LogInformation("MovimientosEspeciales - Obtenemos credenciales del servicio de bepsa.");
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
            request.Clave = credencial.Clave;
            request.Usuario = credencial.UsuarioServicioBepsa;
            var requestContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            _logger.LogInformation("MovimientosEspeciales - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicioMovEspecial);
            _logger.LogInformation("MovimientosEspeciales - Json enviado a bepsa {@} " + JsonConvert.SerializeObject(request));
            var response = await _apiClient.PostAsync(credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault().UrlServicioMovEspecial, requestContent);
            var jsonResponse = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<ResponseMovEspeciales>(jsonResponse);
            _logger.LogInformation("MovimientosEspeciales - Respuesta del servicio de bepsa: " + jsonResponse);

            response.EnsureSuccessStatusCode();
            return new ResponseMovEspeciales()
            {
                codRespuesta = resultado.codRespuesta,
                loteRespuesta = resultado.loteRespuesta,
                msgRespuesta = resultado.msgRespuesta
            };
        }
        /// <summary>
        /// Metodo que ejecuta api de bepsa.
        /// </summary>
        /// <param name="parametrosBepsa"></param>
        /// <param name="credenciales"></param>
        /// <returns>retorna respuesta del servicio invocado</returns>
        public async Task<ResponseAbmTarjeta> EjecutarServicioCredito(RequestAbmCredito parametrosBepsa, KeyToken credenciales)
        {
            try
            {
                _logger.LogInformation("AbmTarjetasCreditoBepsa - Obtenemos credenciales del servicio de bepsa.");
                var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
                credencialeServices_.Usuario = credencial.UsuarioAbmCredito;
                credencialeServices_.Contraseña = credencial.ClaveAbmCredito;
                parametrosBepsa.Autorizador = new List<string>();
                parametrosBepsa.Autorizador.Add(credencial.UsuarioAbmCredito);
                parametrosBepsa.Autorizador.Add(credencial.ClaveAbmCredito);
                _logger.LogInformation("AbmTarjetasCreditoBepsa - obtenemos la url del servicio de bepsa. " + credencial.UrlServicioCredito);
                var jsonObject = JsonConvert.SerializeObject(parametrosBepsa);
                var requestContent = new StringContent(jsonObject, Encoding.UTF8, "application/json");
                _guardarLogs(parametrosBepsa);
                _logger.LogInformation("AbmTarjetasCreditoBepsa - Ejecutamos el servicio de bepsa.");
                ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var response = await _apiClient.PostAsync(credencial.UrlServicioCredito, requestContent);
                var jsonResponse = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("AbmTarjetasCreditoBepsa - La respuesta del servicio de bepsa: " + jsonResponse);
                var respuesta = JsonConvert.DeserializeObject<ResponseAbmTarjeta>(jsonResponse);

                return respuesta;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "AbmTarjetasCreditoBepsa - Error en la solicitud HTTP");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "AbmTarjetasCreditoBepsa - Tiempo de espera de la solicitud agotado");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "AbmTarjetasCreditoBepsa - Ocurrio un error al transmitir las altas");
                throw;
            }
        }
        private void _guardarLogs(RequestAbmCredito dto)
        {
            _logger.LogInformation("AbmTarjetasCreditoBepsa - objeto Autorizador  {@Autorizador}", dto.Autorizador);
            _logger.LogInformation("AbmTarjetasCreditoBepsa - objeto Personas {@Personas}", dto.Personas);
            _logger.LogInformation("AbmTarjetasCreditoBepsa - objeto Cuentas {@Cuentas}", dto.Cuentas);
            _logger.LogInformation("AbmTarjetasCreditoBepsa - objeto Tarjetas {@Tarjetas}", dto.Tarjetas);
        }
        public async Task<ResponseReimpresion> ConexionReimpresion(RequestReimpresion request, KeyToken credenciales)
        {
            _logger.LogInformation("Reimpresion - Obtenemos credenciales del servicio de bepsa.");
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper())).FirstOrDefault();
            request.Clave = credencial.ClaveReimpresion;
            request.Usuario = credencial.UsuarioReimpresion;
            var requestContent = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");
            _logger.LogInformation("Reimpresion - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicioReimpresion);
            _logger.LogInformation("Reimpresion - Json enviado a bepsa {@} " + JsonConvert.SerializeObject(request));
            var response = await _apiClient.PostAsync(credencialesToken.Credenciales.Where(t => t.Key.Equals(credenciales.ToString().ToUpper())).FirstOrDefault().UrlServicioReimpresion, requestContent);
            var jsonResponse = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Reimpresion - Respuesta del servicio de bepsa: " + jsonResponse);
            var resultado = JsonConvert.DeserializeObject<ResponseReimpresion>(jsonResponse);

            response.EnsureSuccessStatusCode();
            return new ResponseReimpresion()
            {
                Codigo = resultado.Codigo,
                Mensaje = resultado.Mensaje,
                Lote = resultado.Lote
            };
        }
        public static bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        public async Task<EstadoTransmisionesResponse> EjecutarServicioAbmErroresAsync(AbmEstadoErroresRequest requestAbmErrores,
                                                                                       KeyToken credenciales)
        {
            var credencial = credencialesToken.Credenciales.FirstOrDefault(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper()));

            _logger.LogInformation("AbmEstadoTransmisionCredito - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicioErrores);

            requestAbmErrores.Usuario = credencial.UsuarioErrores;
            requestAbmErrores.Clave = credencial.ClaveErrores;
            _logger.LogInformation("AbmEstadoTransmisionCredito - Request enviado al servicio de bepsa: {@request}", requestAbmErrores);

            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            if (!_apiClient.DefaultRequestHeaders.Contains("clave"))
                _apiClient.DefaultRequestHeaders.Add("clave", requestAbmErrores.Clave);
            if (!_apiClient.DefaultRequestHeaders.Contains("usuario"))
                _apiClient.DefaultRequestHeaders.Add("usuario", requestAbmErrores.Usuario);

            var uri = $"{credencial.UrlServicioErrores}" +
                      $"?idSesion={requestAbmErrores.IdSesion}" +
                      $"&tipoArchivo={requestAbmErrores.TipoArchivo}" +
                      $"&clave1={requestAbmErrores.Cuenta}" +
                      $"&clave2=";

            _logger.LogInformation("AbmEstadoTransmisionCredito - URL del servicio de bepsa: {uriWebServiceBepsa}", uri);
            var response = _apiClient.GetAsync(uri);
            var jsonResponse = await response.Result.Content.ReadAsStringAsync();

            if (response.Exception != null)
                throw new Exception(response.Exception.Message);

            if (response.Result.StatusCode != HttpStatusCode.OK && response.Result.StatusCode != HttpStatusCode.BadRequest)
                throw new Exception("Error interno en la API." + response.Result.StatusCode);

            if (response.Result == null)
                throw new Exception("Ocurrió un inconveniente al invocar la API de AbmEstadoTransmisionCredito.");

            _logger.LogInformation("AbmEstadoTransmisionCredito - La respuesta del servicio de bepsa: {@respuestaWebServiceBepsa}", jsonResponse);
            var respuesta = JsonConvert.DeserializeObject<EstadoTransmisionesResponse>(jsonResponse);

            return respuesta;
        }

        /// <summary>
        /// Metodo que ejecuta API de PAGOS de TC de Bepsa
        /// </summary>
        /// <summary>
        /// Metodo que ejecuta API de PAGOS de TC de Bepsa
        /// </summary>
        public async Task<ResponsePagoTC> ConexionPagoTarjetaCreditoAsync(RequestPagoTC request, KeyToken credenciales)
        {
            var credencial = credencialesToken.Credenciales.FirstOrDefault(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper()));
            request.Clave = credencial.ClaveServicioPago;
            request.Usuario = credencial.UsuarioServicioPago;

            var jsonObject = JsonConvert.SerializeObject(request);

            var requestContent = new StringContent(jsonObject, Encoding.UTF8, "application/json");

            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            _logger.LogInformation("ServicioPagoTC - Request enviado a bepsa {@PagosTC} ", request);
            _logger.LogInformation("ServicioPagoTC - Request Json: {json}", JsonConvert.SerializeObject(request, Formatting.Indented));

            var urlServicioPago = credencialesToken.Credenciales.FirstOrDefault(t => t.Key.Equals(credenciales.ToString().ToUpper())).UrlServicioPago;

            var response = _apiClient.PostAsync(urlServicioPago, requestContent);

            var jsonResponse = await response.Result.Content.ReadAsStringAsync();

            if (response.Exception != null)
                throw new ApiException(response.Exception.Message, StatusCodes.Status500InternalServerError);

            if (response.Result.StatusCode != HttpStatusCode.OK)
                throw new ApiException("Ocurrió un inconveniente al invocar la API ServicioPagoTC", (int)response.Result.StatusCode);

            if (response.Result == null)
                throw new ApiException("Ocurrió un inconveniente al invocar la API ServicioPagoTC", StatusCodes.Status400BadRequest);

            var respuesta = JsonConvert.DeserializeObject<ResponsePagoTC>(jsonResponse);

            _logger.LogInformation("ServicioPagoTC - La respuesta del servicio de bepsa:  {@ResponsePagosTC}", respuesta);
            return respuesta;
        }

        public async Task<BloqueoDesbloqueoResponse> EjecutarServicioBloqueoTCAsync(BloqueoDesbloqueoRequest requestBloqueoTC, KeyToken credenciales)
        {
            var credencial = credencialesToken.Credenciales.FirstOrDefault(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper()));

            var jsonObject = JsonConvert.SerializeObject(requestBloqueoTC);
            var requestContent = new StringContent(jsonObject, Encoding.UTF8, "application/json");

            credencial.Usuario = credenciales switch
            {
                KeyToken.WALEDBLOQUEO => credencial.Usuario,
                KeyToken.SERVICIO => credencial.UsuarioServicioBloqueoTC,
                _ => credencial.UsuarioServicioBloqueoTC
            };

            credencial.Clave = credenciales switch
            {
                KeyToken.WALEDBLOQUEO => credencial.Clave,
                KeyToken.SERVICIO => credencial.ClaveServicioBloqueoTC,
                _ => credencial.ClaveServicioBloqueoTC
            };

            credencial.UrlServicio = credenciales switch
            {
                KeyToken.WALEDBLOQUEO => credencial.UrlServicio,
                KeyToken.SERVICIO => credencial.UrlServicioBloqueoTC,
                _ => credencial.UrlServicioBloqueoTC
            };


            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            _apiClient.DefaultRequestHeaders.Add("usuario", credencial.Usuario);
            _apiClient.DefaultRequestHeaders.Add("clave", credencial.Clave);

            var response = _apiClient.PostAsync(credencial.UrlServicio, requestContent);

            var jsonResponse = await response.Result.Content.ReadAsStringAsync();

            if (response.Exception != null)
                throw new ApiException(response.Exception.Message, StatusCodes.Status500InternalServerError);

            if (response.Result.StatusCode != System.Net.HttpStatusCode.OK)
                throw new ApiException($"Ocurrió un inconveniente al invocar la API BloqueoBepsaTC ",500,(int)response.Result.StatusCode);

            if (response.Result == null)
                throw new ApiException($"Ocurrió un inconveniente al invocar la API BloqueoBepsaTC ",500, (int)response.Result.StatusCode);

            var respuesta = JsonConvert.DeserializeObject<BloqueoDesbloqueoResponse>(jsonResponse);

            return respuesta;
        }

        public async Task<BloqueoDesbloqueoResponse> EjecutarServicioDesbloqueoTCAsync(BloqueoDesbloqueoRequest desbloqueoRequest, KeyToken credenciales)
        {
            var credencial = credencialesToken.Credenciales.FirstOrDefault(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper()));
            var jsonObject = JsonConvert.SerializeObject(desbloqueoRequest);
            var requestContent = new StringContent(jsonObject, Encoding.UTF8, "application/json");



            credencial.Usuario = credenciales switch
            {
                KeyToken.WALEDDESBLOQUEO => credencial.Usuario,
                KeyToken.SERVICIO => credencial.UsuarioServicioDesbloqueoTC,
                _ => credencial.UsuarioServicioDesbloqueoTC
            };

            credencial.Clave = credenciales switch
            {
                KeyToken.WALEDDESBLOQUEO => credencial.Clave,
                KeyToken.SERVICIO => credencial.ClaveServicioDesbloqueoTC,
                _ => credencial.ClaveServicioDesbloqueoTC
            };

            credencial.UrlServicio = credenciales switch
            {
                KeyToken.WALEDDESBLOQUEO => credencial.UrlServicio,
                KeyToken.SERVICIO => credencial.UrlServicioDesbloqueoTC,
                _ => credencial.UrlServicioDesbloqueoTC
            };

            _logger.LogInformation("DesbloqueoBepsaTC - Credenciales {@jsonObject} ", credencial);
            _logger.LogInformation("DesbloqueoBepsaTC - Json enviado a bepsa {@jsonObject} ", jsonObject);

            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var urlServicioDesbloqueo = credencial.UrlServicio;

            _apiClient.DefaultRequestHeaders.Add("usuario", credencial.Usuario);
            _apiClient.DefaultRequestHeaders.Add("clave", credencial.Clave);

            var response = _apiClient.PostAsync(urlServicioDesbloqueo, requestContent);

            var jsonResponse = await response.Result.Content.ReadAsStringAsync();
            _logger.LogInformation("DesbloqueoBepsaTC - La respuesta del servicio de bepsa:  {@responseDesbloqueoTC}", jsonResponse);

            if (response.Exception != null)
                throw new ApiException(response.Exception.Message, StatusCodes.Status500InternalServerError);

            if (response.Result.StatusCode != HttpStatusCode.OK)
                throw new ApiException($"Ocurrió un inconveniente al invocar la API DesbloqueoBepsaTC ", 500, (int)response.Result.StatusCode);

            if (response.Result == null)
                throw new ApiException($"Ocurrió un inconveniente al invocar la API DesbloqueoBepsaTC ", 500, (int)response.Result.StatusCode);

            var respuesta = JsonConvert.DeserializeObject<BloqueoDesbloqueoResponse>(jsonResponse);

            return respuesta;
        }

        public async Task<RenovacionBepsaResponse> TransmisionRenovacionBepsa(RenovacionBepsaRequest request)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                // 1- Obenemos el Token del servicio de Bepsa
                var tokenServicioBepsa = await ConexionObtenerTokenServicioBepsaAsync(NombreProcesoService.RenovacionService, 
                                                                                      KeyToken.AUTENTICARSERVICIOBEPSA);
                if (string.IsNullOrEmpty(tokenServicioBepsa))
                {
                    return new RenovacionBepsaResponse
                    {
                        CodigoRespuesta = CodigoRespuestaRenovacion.ErrorAutenticacionServicioBepsa,
                        MensajeRespuesta = MensajeRespuestaRenovacion.ErrorAutenticacionServicioBepsa
                    };
                }

                // 2- Transmitimos a la procesadora las renovaciones
                var renovacionBepsaResponse = await ConexionTransmisionRenovacionBepsaAsync(tokenServicioBepsa,
                                                                                            request);
                if (renovacionBepsaResponse == null)
                {
                    return new RenovacionBepsaResponse
                    {
                        CodigoRespuesta = CodigoRespuestaRenovacion.ErrorTransmisionRenovaciones,
                        MensajeRespuesta = MensajeRespuestaRenovacion.ErrorTransmisionRenovaciones
                    };
                }
                _logger.LogInformation(NombreProcesoService.RenovacionService + " - Se transmitieron éxitosamente las renovaciones. Id Seguimiento: {IdSeguimiento} in {Timer}",
                    renovacionBepsaResponse.IdSeguimiento, timer.Elapsed.TotalMilliseconds);

                renovacionBepsaResponse.CodigoRespuesta = CodigoRespuestaRenovacion.Procesado;
                renovacionBepsaResponse.MensajeRespuesta = MensajeRespuestaRenovacion.Procesado;

                return renovacionBepsaResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, NombreProcesoService.RenovacionService + " - Ocurrió un error al realizar la transmisión de las renovaciones de tarjetas de crédito in {Timer}",
                    timer.Elapsed.TotalMilliseconds);
                return new RenovacionBepsaResponse
                {
                    CodigoRespuesta = CodigoRespuestaRenovacion.ErrorInterno.ToString(),
                    MensajeRespuesta = MensajeRespuestaRenovacion.ErrorInterno + $" {NombreProcesoService.RenovacionService}"
                };
            }
        }

        public async Task<string> ConexionObtenerTokenServicioBepsaAsync(string nombreProcesoService,
                                                                         KeyToken credenciales)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();

            var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper())).FirstOrDefault();

            _logger.LogInformation(nombreProcesoService + " - GetTokenServicioBepsaAsync - Inicio de obtención del Token del servicio de Bepsa. URL: {UrlServicio}",
                credencial.UrlServicio);

            var body = new TokenServicioBepsaResquest
            {
                Usuario = credencial.Usuario,
                Clave = credencial.Clave,
            };

            var bodySerializado = JsonConvert.SerializeObject(body, new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            });

            StringContent requestContent = new StringContent(bodySerializado, Encoding.UTF8, "application/json");

            HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, credencial.UrlServicio)
            {
                Content = requestContent,
            };

            try
            {
                HttpResponseMessage tokenBepsaResponse = await _apiClient.SendAsync(requestMessage);

                string contentString = await tokenBepsaResponse.Content.ReadAsStringAsync();

                if (!tokenBepsaResponse.IsSuccessStatusCode)
                {
                    _logger.LogWarning(nombreProcesoService + " - GetTokenServicioBepsaAsync - Ocurrio un error al obtener Token de Bepsa. StatusCode: {StatusCode}. Body Response: {@ContenString} in {Timer} ms",
                        tokenBepsaResponse.StatusCode, contentString, timer.Elapsed.TotalMilliseconds);
                    return null;
                }
                _logger.LogInformation(nombreProcesoService + " - GetTokenServicioBepsaAsync - Fin de obtención del Token del servicio de Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);

                return JsonConvert.DeserializeObject<TokenServicioBepsaResponse>(contentString).Token;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogWarning(ex, nombreProcesoService + " - GetTokenServicioBepsaAsync - Tiempo límite de ejecución alcanzado al obtener el Token del servicio de Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);
                return null;
            }
            catch (Exception ex)
            {
                if (ex.InnerException is HttpRequestException httpException)
                {
                    _logger.LogWarning(ex, nombreProcesoService + " - GetTokenServicioBepsaAsync - Error en la solicitud HTTP in {Timer} ms",
                        timer.Elapsed.TotalMilliseconds);
                }
                else
                {
                    _logger.LogWarning(ex, nombreProcesoService + " - GetTokenServicioBepsaAsync - Ocurrió un error al obtener el Token del servicio de Bepsa in {Timer} ms",
                        timer.Elapsed.TotalMilliseconds);
                }
                return null;
            }
        }

        public async Task<RenovacionBepsaResponse> ConexionTransmisionRenovacionBepsaAsync(string tokenServicioBepsa, 
                                                                                           RenovacionBepsaRequest request)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(KeyToken.RENOVACIONBEPSA.ToString().ToUpper())).FirstOrDefault();
            var urlServicio = credencial.UrlServicio;
            _logger.LogInformation(NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Inicio de transmisión de renovaciones de tarjetas a la procesadora Bepsa. URL: {UrlServicio}",
                urlServicio);

            var headers = new Dictionary<string, string>()
            {
                { "Authorization", $"Bearer {tokenServicioBepsa}" }
            };

            var bodySerializado = JsonConvert.SerializeObject(request);

            StringContent requestContent = new StringContent(bodySerializado, Encoding.UTF8, "application/json");

            HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, urlServicio)
            {
                Content = requestContent,
            };

            foreach (var kvp in headers)
            {
                requestMessage.Headers.Add(kvp.Key, kvp.Value);
            }

            var renovacionBepsaLogger = request.Lote
                .Select(x => new
                {
                    TarjetaActual = _bloqueoDesbloqueoRepository.EnmascararTarjeta(x.TarjetaActual),
                    TarjetaNueva = _bloqueoDesbloqueoRepository.EnmascararTarjeta(x.TarjetaNueva),
                    x.NuevaFechaVencimiento
                })
                .ToList();
            _logger.LogInformation(NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Json enviado a bepsa {@JsonEnviado}",
                renovacionBepsaLogger);

            try
            {
                HttpResponseMessage responseHttp = await _apiClient.SendAsync(requestMessage);

                string contentString = await responseHttp.Content.ReadAsStringAsync();

                if (!responseHttp.IsSuccessStatusCode)
                {
                    _logger.LogWarning(NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Ocurrio un error al transmitir las renovaciones de tarjetas a la procesadora Bepsa. StatusCode: {StatusCodeResponse}. Body Response: {@ContenString} in {Timer} ms",
                        responseHttp.StatusCode, contentString, timer.Elapsed.TotalMilliseconds);
                    return null;
                }
                _logger.LogInformation(NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Fin de la transmisión de las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);

                return JsonConvert.DeserializeObject<RenovacionBepsaResponse>(contentString);
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogWarning(ex, NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Tiempo límite de ejecución alcanzado al transmitir las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);
                return null;
            }
            catch (Exception ex)
            {
                if (ex.InnerException is HttpRequestException httpException)
                {
                    _logger.LogWarning(ex, NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Error en la solicitud HTTP in {Timer} ms",
                        timer.Elapsed.TotalMilliseconds);
                }
                else
                {
                    _logger.LogWarning(ex, NombreProcesoService.RenovacionService + " - TransmisionRenovacionBepsaAsync - Ocurrió un error al transmitir las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms", timer.Elapsed.TotalMilliseconds);
                }
                return null;
            }
        }

        public async Task<ConsultaRenovacionBepsaResponse> ConsultaRenovacionBepsa(decimal idSeguimiento)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                // 1- Obenemos el Token del servicio de Bepsa
                var tokenServicioBepsa = await ConexionObtenerTokenServicioBepsaAsync(NombreProcesoService.ConsultaRenovacionService,
                                                                                      KeyToken.AUTENTICARSERVICIOBEPSA);
                if (string.IsNullOrEmpty(tokenServicioBepsa))
                {
                    return new ConsultaRenovacionBepsaResponse
                    {
                        CodigoRespuesta = CodigoRespuestaRenovacion.ErrorAutenticacionServicioBepsa,
                        MensajeRespuesta = MensajeRespuestaRenovacion.ErrorAutenticacionServicioBepsa
                    };
                }

                // 2- Consultamos el estado del lote según el ID de seguimiento
                var consultaRenovacionBepsaResponse = await ConexionConsultaRenovacionBepsaAsync(tokenServicioBepsa, idSeguimiento);

                if (consultaRenovacionBepsaResponse?.Lote == null)
                {
                    return new ConsultaRenovacionBepsaResponse
                    {
                        CodigoRespuesta = CodigoRespuestaRenovacion.ErrorConsultaRenovaciones,
                        MensajeRespuesta = MensajeRespuestaRenovacion.ErrorConsultaRenovaciones
                    };
                }

                var loteRenovacionBepsaResponseLogger = consultaRenovacionBepsaResponse.Lote
                    .Select(x => new
                    {
                        TarjetaActual = _bloqueoDesbloqueoRepository.EnmascararTarjeta(x.TarjetaActual),
                        TarjetaNueva = _bloqueoDesbloqueoRepository.EnmascararTarjeta(x.TarjetaNueva),
                        x.NuevaFechaVencimiento,
                        x.IdEstado,
                        x.Estado
                    })
                    .ToList();

                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - La respuesta de la procesadora según el Id de seguimiento {IdSeguimiento}: {@BepsaResponse} in {Timer}",
                    idSeguimiento,loteRenovacionBepsaResponseLogger, timer.Elapsed.TotalMilliseconds);

                return consultaRenovacionBepsaResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, NombreProcesoService.ConsultaRenovacionService + " - Ocurrio un error al consultar el seguimiento de las renovaciones de tarjetas a la procesadora Bepsa in {Timer}",
                    timer.Elapsed.TotalMilliseconds);
                return new ConsultaRenovacionBepsaResponse
                {
                    CodigoRespuesta = CodigoRespuestaRenovacion.ErrorInterno.ToString(),
                    MensajeRespuesta = MensajeRespuestaRenovacion.ErrorInterno + $" {NombreProcesoService.ConsultaRenovacionService}"
                };
            }
        }

        public async Task<ConsultaRenovacionBepsaResponse> ConexionConsultaRenovacionBepsaAsync(string tokenServicioBepsa, decimal idSeguimiento)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            var credencial = credencialesToken.Credenciales.Where(t => t.Key.ToUpper().Equals(KeyToken.CONSULTARENOVACIONBEPSA.ToString().ToUpper())).FirstOrDefault();
            var urlServicio = credencial.UrlServicio.Replace(":idSeguimiento", idSeguimiento.ToString());

            _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Inicio de la consulta del seguimiento de las renovaciones de tarjetas a la procesadora Bepsa. URL: {UrlServicio}",
            urlServicio);

            var headers = new Dictionary<string, string>()
            {
                { "Authorization", $"Bearer {tokenServicioBepsa}" }
            };

            var requestMessage = new HttpRequestMessage(HttpMethod.Get, urlServicio);

            foreach (var kvp in headers)
            {
                requestMessage.Headers.Add(kvp.Key, kvp.Value);
            }

            try
            {
                HttpResponseMessage responseHttp = await _apiClient.SendAsync(requestMessage);

                string contentString = await responseHttp.Content.ReadAsStringAsync();

                if (!responseHttp.IsSuccessStatusCode)
                {
                    _logger.LogWarning(NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Ocurrio un error al consultar el seguimiento de las renovaciones de tarjetas a la procesadora Bepsa. StatusCode: {StatusCodeResponse}. Body Response: {@ContenString} in {Timer} ms",
                        responseHttp.StatusCode, contentString, timer.Elapsed.TotalMilliseconds);
                    return null;
                }
                _logger.LogInformation(NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Fin de la consulta del seguimiento de las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);

                return new ConsultaRenovacionBepsaResponse
                {
                    CodigoRespuesta = CodigoRespuestaRenovacion.Procesado,
                    MensajeRespuesta = MensajeRespuestaRenovacion.Procesado,
                    Lote = JsonConvert.DeserializeObject<List<LoteConsultaRenovacionBepsaResponse>>(contentString)
                };
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogWarning(ex, NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Tiempo límite de ejecución alcanzado al transmitir las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms",
                    timer.Elapsed.TotalMilliseconds);
                return null;
            }
            catch (Exception ex)
            {
                if (ex.InnerException is HttpRequestException httpException)
                {
                    _logger.LogWarning(ex, NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Error en la solicitud HTTP in {Timer} ms",
                        timer.Elapsed.TotalMilliseconds);
                }
                else
                {
                    _logger.LogWarning(ex, NombreProcesoService.ConsultaRenovacionService + " - ConsultaRenovacionBepsaAsync - Ocurrio un error al consultar el seguimiento de las renovaciones de tarjetas a la procesadora Bepsa in {Timer} ms", timer.Elapsed.TotalMilliseconds);
                }
                return null;
            }
        }

        public async Task<ResponseCambioVencimiento> ConexionCambioVencimiento(RequestCambioVencimiento request, KeyToken credenciales)
        {
            try
            {
                _logger.LogInformation("TransmicionCambioVencimiento - Obtenemos credenciales del servicio de bepsa.");
                var credencial = credencialesToken.Credenciales.Find(t => t.Key.ToUpper().Equals(credenciales.ToString().ToUpper()));

                var jsonRequest = JsonConvert.SerializeObject(request);
                var requestContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                _logger.LogInformation("TransmicionCambioVencimiento - Obtenemos la url del servicio de bepsa. " + credencial.UrlServicio);
                _logger.LogInformation("TransmicionCambioVencimiento - Json enviado a bepsa " + JsonConvert.SerializeObject(request));

                if (!_apiClient.DefaultRequestHeaders.Contains("usuario"))
                    _apiClient.DefaultRequestHeaders.Add("usuario", credencial.Usuario);
                if (!_apiClient.DefaultRequestHeaders.Contains("clave"))
                    _apiClient.DefaultRequestHeaders.Add("clave", credencial.Clave);

                var response = await _apiClient.PostAsync(credencial.UrlServicio, requestContent);
                var jsonResponse = await response.Content.ReadAsStringAsync();

                _logger.LogInformation("TransmicionCambioVencimiento - Respuesta del servicio de bepsa: " + jsonResponse);

                var resultado = JsonConvert.DeserializeObject<ResponseCambioVencimiento>(jsonResponse);

                response.EnsureSuccessStatusCode();

                return resultado;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "TransmicionCambioVencimiento - Error en la solicitud HTTP para cambio vencimiento tc");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "TransmicionCambioVencimiento - Tiempo de espera de la solicitud agotado para cambio vencimiento");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "TransmicionCambioVencimiento - Ocurrio un error al invocar el servicio de cambio vencimiento");
                throw;
            }
        }
    }
}
