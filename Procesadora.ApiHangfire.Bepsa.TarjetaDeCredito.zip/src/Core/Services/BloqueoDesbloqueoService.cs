﻿using AutoMapper;
using Continental.API.Core.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Continental.API.Core.Enums;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Services
{
    public class BloqueoDesbloqueoService : IBloqueoDesbloqueoService
    {
        private readonly IBloqueoDesbloqueoRepository _bloqueoDesbloqueoRepository;
        private readonly ILogger<BloqueoDesbloqueoService> _logger;
        private readonly IConexionApi _conexionApi;
        private readonly IMapper _mapper;
        private readonly CredencialesToken _credencialesToken;

        public BloqueoDesbloqueoService(IBloqueoDesbloqueoRepository bloqueoDesbloqueoRepository, ILogger<BloqueoDesbloqueoService> logger,
                              IConexionApi conexionApi, IMapper mapper, IOptions<ConfiguracionesCore> configuraciones)
        {
            _bloqueoDesbloqueoRepository = bloqueoDesbloqueoRepository;
            _logger = logger;
            _conexionApi = conexionApi;
            _mapper = mapper;
            _credencialesToken = configuraciones.Value.CredencialesToken;
        }


        /// <summary>
        /// Metodo para procesar bloqueos de TC
        /// </summary>
        /// <returns>ResponseBloqueoTC</returns>
        public async Task<DefaultResponse> BloqueosAsync()
        {
            List<SolicitudBloqueo> pendientesBloqueo = await _bloqueoDesbloqueoRepository.GetBloqueosPendientesAsync();

            if (pendientesBloqueo == null || !pendientesBloqueo.Any())
                throw new ApiException.ApiException(
                    "BloqueoBepsaTC - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                    StatusCodes.Status200OK);

            var response = await this.TransmitirBloqueoDesbloqueoAsync(pendientesBloqueo, KeyToken.SERVICIO);
            return response;
        }

        /// <summary>
        /// Metodo para procesar bloqueos de TC E-club
        /// </summary>
        /// <returns>ResponseBloqueoTC</returns>
        public async Task<DefaultResponse> BloqueosWaledAsync()
        {
            List<SolicitudBloqueo> pendientesBloqueoWaled = await _bloqueoDesbloqueoRepository.GetBloqueosPendientesWaledAsync();

            if (pendientesBloqueoWaled == null || !pendientesBloqueoWaled.Any())
                throw new ApiException.ApiException(
                    "BloqueoWaledTC - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                    StatusCodes.Status200OK);

            var response = await this.TransmitirBloqueoDesbloqueoAsync(pendientesBloqueoWaled, KeyToken.WALEDBLOQUEO);

            return response;
        }

        /// <summary>
        /// Transmite al servico de bepsa y procesa los bloqueos
        /// </summary>
        /// <param name="tarjetaBloqueosDesbloqueos">listado de bloqueos a transmitir</param>
        /// <returns>ResponseBloqueoTC</returns>
        private async Task<DefaultResponse> TransmitirBloqueoDesbloqueoAsync<T>(List<T> tarjetaBloqueosDesbloqueos, KeyToken credencial)
        {
            var request = new BloqueoDesbloqueoRequest()
            {
                Tarjetas = _mapper.Map<List<DetalleBloqueo>>(tarjetaBloqueosDesbloqueos),
            };

            BloqueoDesbloqueoResponse resultado;
            if (tarjetaBloqueosDesbloqueos is List<SolicitudBloqueo>)
            {
                var listado = _mapper.Map<List<SolicitudBloqueo>>(tarjetaBloqueosDesbloqueos);
                listado.ForEach(i => i.Tarjeta = _bloqueoDesbloqueoRepository.EnmascararTarjeta(i.Tarjeta));
                _logger.LogInformation("BloqueoBepsaTC - Request enviado a Bepsa: {@requestBloqueoTC}", listado);
                resultado = await _conexionApi.EjecutarServicioBloqueoTCAsync(request, credencial);
                resultado.Procesados.ForEach(i => i.Tarjeta = _bloqueoDesbloqueoRepository.EnmascararTarjeta(i.Tarjeta));
                _logger.LogInformation("BloqueoBepsaTC - Respuesta del Servicio de Bepsa: {@responseBloqueoTC}", resultado);
            }
            else
            {
                var listado = _mapper.Map<List<SolicitudDesbloqueo>>(tarjetaBloqueosDesbloqueos);
                listado.ForEach(i => i.Tarjeta = _bloqueoDesbloqueoRepository.EnmascararTarjeta(i.Tarjeta));
                _logger.LogInformation("DesbloqueoBepsaTC - Request enviado a Bepsa: {@requestDesbloqueoTC}", listado);
                resultado = await _conexionApi.EjecutarServicioDesbloqueoTCAsync(request, credencial);
                resultado.Procesados.ForEach(i => i.Tarjeta = _bloqueoDesbloqueoRepository.EnmascararTarjeta(i.Tarjeta));
                _logger.LogInformation("DesbloqueoBepsaTC - Respuesta del Servicio de Bepsa: {@responseDesbloqueoTC}", resultado);
            }

            DefaultResponse response = await this.ProcesarBloqueosDesbloqueosAsync(resultado, tarjetaBloqueosDesbloqueos);

            return response;
        }

        /// <summary>
        /// Metodo para procesar los Bloqueos y Desbloqueos que fueron Transmitidos a Bepsa.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="responseBloqueoDesbloqueoTC">Respuesta de Bepsa para Bloqueos o Desbloqueos</param>
        /// <param name="tarjetaBloqueosDesbloqueos">Listado de Bloqueo o Desbloqueo Transmitido a Bepsa</param>
        /// <returns>Response generico</returns>
        private async Task<DefaultResponse> ProcesarBloqueosDesbloqueosAsync<T>(BloqueoDesbloqueoResponse responseBloqueoDesbloqueoTC,
                                                                                List<T> tarjetaBloqueosDesbloqueos)
        {
            var mensajeRetorno = string.Empty;
            var numeroProceso = string.Empty;
            var emailUser = string.Empty;
            var timer = System.Diagnostics.Stopwatch.StartNew();

            // Primero verificamos el tipo de acción
            TipoAccion tipoAccion = (tarjetaBloqueosDesbloqueos is List<SolicitudBloqueo>) ? TipoAccion.BLOQUEO : TipoAccion.DESBLOQUEO;
            var tipoAccionLogger = _bloqueoDesbloqueoRepository.CapitalizarPrimeraLetra(tipoAccion.ToString()) + "BepsaTC";
            _logger.LogInformation($"{tipoAccionLogger} - ProcesarBloqueosDesbloqueosAsync iniciado");

            foreach (var procesado in responseBloqueoDesbloqueoTC.Procesados)
            {
                EmailBloqueoDesbloqueo emailBloqueo;

                //armamos el mensaje de retorno
                mensajeRetorno = $"Local: {procesado.Local.CodigoRetorno}-{procesado.Local.MensajeRetorno}";
                
                if (procesado.Internacional != null)
                    mensajeRetorno += $" - Internacional: {procesado.Internacional.CodigoRetorno} " +
                                   $"{procesado.Internacional.MensajeRetorno}";

                //Verificamos si vamos a procesar un bloqueo o desbloqueo
                if (tarjetaBloqueosDesbloqueos is List<SolicitudBloqueo>)
                {
                    List<SolicitudBloqueo> solicitudBloqueos = tarjetaBloqueosDesbloqueos as List<SolicitudBloqueo>;

                    //obtenemos el nroproces de la tc enviada para bloqueo, buscamos por Nro. de Tarjeta
                    numeroProceso = solicitudBloqueos.FirstOrDefault(f => f.Tarjeta.Equals(procesado.Tarjeta)).NumeroProceso.ToString();
                    emailUser = solicitudBloqueos.FirstOrDefault(f => f.Tarjeta.Equals(procesado.Tarjeta)).UserCorreo.ToString();
                    tipoAccion = TipoAccion.BLOQUEO;
                }
                else
                {
                    List<SolicitudDesbloqueo> solicitudDesbloqueos = tarjetaBloqueosDesbloqueos as List<SolicitudDesbloqueo>;
                    //obtenemos el nroproces de la tc enviada para desbloqueo, buscamos por Nro. de Tarjeta
                    numeroProceso = solicitudDesbloqueos.FirstOrDefault(f => f.Tarjeta.Equals(procesado.Tarjeta.Trim())).NumeroProceso.ToString();
                    emailUser = solicitudDesbloqueos.FirstOrDefault(f => f.Tarjeta.Equals(procesado.Tarjeta.Trim())).UserCorreo.ToString();
                    tipoAccion = TipoAccion.DESBLOQUEO;
                }

                try
                {
                    //Actualizamos el registro y marcamos como proces = 'S' o 'N' segun codigoRetorno
                    await ActualizarRegistroBloqueoDesbloqueoAsync(numeroProceso, procesado.Local.CodigoRetorno, mensajeRetorno);

                    ////Cargamos los datos del Correo
                    if (procesado.Local.CodigoRetorno == RespuestaBloqueoDesbloqueo.TarjetaBloqueadaDesbloqueada)
                    {
                        emailBloqueo = new EmailBloqueoDesbloqueo
                        {
                            TipoEmailBloqueo = TipoEmailBloqueoDesbloqueo.TarjetaBloqueadaConExito,
                            Accion = tipoAccion.ToString(),
                            MensajeRetorno = mensajeRetorno,
                            Asunto = "HANGFIRE BLOQUEO/DESBLOQUEO BEPSA",
                            EmailUsuario = emailUser,
                            NumeroTarjeta = procesado.Tarjeta,
                        };
                    }
                    else
                    {
                        //si no se pudo procesar por Bepsa, se remite un correo de Error.
                        emailBloqueo = new EmailBloqueoDesbloqueo
                        {
                            TipoEmailBloqueo = TipoEmailBloqueoDesbloqueo.ErrorAlProcesarEnBepsa,
                            Accion = tipoAccion.ToString(),
                            MensajeRetorno = mensajeRetorno,
                            Asunto = "HANGFIRE BLOQUEO/DESBLOQUEO BEPSA",
                            EmailUsuario = emailUser,
                            NumeroTarjeta = procesado.Tarjeta,
                        };

                        decimal intentos = Convert.ToDecimal(_bloqueoDesbloqueoRepository.GetCantidadIntentos(numeroProceso));
                        if (intentos >= 3)
                        {
                            //Si ya se llego a 3 intentos, se emite un correo de Cancelacion.
                            emailBloqueo = new EmailBloqueoDesbloqueo
                            {
                                TipoEmailBloqueo = TipoEmailBloqueoDesbloqueo.CancelacionEnvioBloqueo,
                                Accion = tipoAccion.ToString(),
                                MensajeRetorno = mensajeRetorno,
                                Asunto = "HANGFIRE BLOQUEO/DESBLOQUEO BEPSA (CANCELACION ENVIO)",
                                EmailUsuario = emailUser,
                                NumeroTarjeta = procesado.Tarjeta,
                                NumeroIntento = intentos.ToString()
                            };
                            //Se actualiza el estado y se marca como cancelado
                            await _bloqueoDesbloqueoRepository.ActualizarEstadoBloqueoAsync(numeroProceso, Convert.ToDecimal(EstadoBloqueo.Erroneo));
                        }
                    }
                    //Enviamos el correo correspondiente
                    _bloqueoDesbloqueoRepository.EnviarEmailBloqueo(emailBloqueo);
                }
                catch (Exception em)
                {
                    EmailBloqueoDesbloqueo emailBloqueoErrorInterno = new EmailBloqueoDesbloqueo
                    {
                        TipoEmailBloqueo = TipoEmailBloqueoDesbloqueo.ErrorInterno,
                        Accion = tipoAccion.ToString(),
                        MensajeRetorno = em.Message.ToUpper().Trim(),
                        Asunto = "HANGFIRE BLOQUEO / DESBLOQUEO BEPSA(ERROR PROCESO)",
                        EmailUsuario = emailUser,
                        NumeroTarjeta = procesado?.Tarjeta
                    };

                    _bloqueoDesbloqueoRepository.EnviarEmailBloqueo(emailBloqueoErrorInterno);
                    _logger.LogWarning(em, $"{tipoAccionLogger} - ProcesarBloqueosDesbloqueosAsync - Ocurrió un error al procesar el {tipoAccion.ToString().ToLower()} " +
                                           $"de la tarjeta {procesado?.Tarjeta} con numero de proceso {numeroProceso} in {timer.Elapsed.TotalMilliseconds}");
                }
            }
            _logger.LogInformation($"{tipoAccionLogger} - ProcesarBloqueosDesbloqueosAsync terminado in {timer.Elapsed.TotalMilliseconds}");
            return new DefaultResponse()
            {
                Codigo = RespuestaBepsa.Aprobada,
                Mensaje = "Registros actualizados"
            };
        }


        private async Task ActualizarRegistroBloqueoDesbloqueoAsync(string numeroProceso, string codigoRetorno, string mensajeRetorno)
        {
            var credencial = _credencialesToken.Credenciales.FirstOrDefault(t => t.Key.ToUpper().Equals(KeyToken.SERVICIO.ToString().ToUpper()));
            //insertamos el log del envio del bloqueo o desbloqueo para todos los casos de respuesta
            await _bloqueoDesbloqueoRepository.InsertarLogEnvioAsync(numeroProceso, credencial.UsuarioServicioBloqueoTC, mensajeRetorno);

            //actualizamos la tabla de envio y en base al codigo de retorno marca como procesado, o en todo caso, marca como pendiente aun.
            await _bloqueoDesbloqueoRepository.ActualizarRegistroBloqueoAsync(numeroProceso, codigoRetorno);
        }

        /// <summary>
        /// Metodo para procesar Desbloqueos de TC
        /// </summary>
        /// <returns>DefaultResponse</returns>
        public async Task<DefaultResponse> DesbloqueosAsync()
        {
            List<SolicitudDesbloqueo> pendientesBloqueo = await _bloqueoDesbloqueoRepository.GetDesbloqueosPendientesAsync();

            if (pendientesBloqueo == null || !pendientesBloqueo.Any())
                throw new ApiException.ApiException(
                    "DesbloqueoBepsaTC - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                    StatusCodes.Status200OK);

            var response = await TransmitirBloqueoDesbloqueoAsync(pendientesBloqueo, KeyToken.SERVICIO);
            return response;
        }

        /// <summary>
        /// Metodo para procesar Desbloqueos de TC
        /// </summary>
        /// <returns>DefaultResponse</returns>
        public async Task<DefaultResponse> DesbloqueosWaledAsync()
        {
            List<SolicitudDesbloqueo> pendientesDesbloqueo = await _bloqueoDesbloqueoRepository.GetDesbloqueosPendientesWaledAsync();

            if (pendientesDesbloqueo == null || !pendientesDesbloqueo.Any())
                throw new ApiException.ApiException(
                    "DesbloqueoWaled - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                    StatusCodes.Status200OK);

            var response = await TransmitirBloqueoDesbloqueoAsync(pendientesDesbloqueo, KeyToken.WALEDDESBLOQUEO);
            return response;
        }
    }
}
