﻿using AutoMapper;
using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Continental.API.Core.Interfaces;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Continental.API.Core.Services
{
    public class ProcesoServices : ITransmisionTarjetaCredito
    {
        private readonly IRepositoryAbmCredito _tarjetasCreditoRepository;
        private readonly ILogger<ProcesoServices> _logger;
        private ResponseAbmTarjeta respuesta = new ResponseAbmTarjeta();
        private readonly IRepositoryActivacion _activacionRepository;
        private CuentaActivacionResponse respuestaCuenta = new CuentaActivacionResponse();
        private TarjetaActivacionResponse respuestaTarjeta = new TarjetaActivacionResponse();
        private readonly IConexionApi conexionApi;
        private readonly IMapper mapper;
        private readonly IRepositoryReimpresion _reimpresionRepository;
        private readonly IRenovacionService _renovacionService;
        private readonly IMediator _mediator;

        public ProcesoServices(IRepositoryAbmCredito repositoryAbm,
                               ILogger<ProcesoServices> logger,
                               IConexionApi conexionApi,
                               IMapper _mapper,
                               IRepositoryActivacion repositoryActivacion,
                               IRepositoryReimpresion repositoryReimpresion,
                               IRenovacionService renovacionService,
                               IMediator mediator)
        {
            this._tarjetasCreditoRepository = repositoryAbm;
            this._logger = logger;
            this.conexionApi = conexionApi;
            mapper = _mapper;
            this._activacionRepository = repositoryActivacion;
            this._reimpresionRepository = repositoryReimpresion;
            this._renovacionService = renovacionService;
            _mediator = mediator;
        }
        /// <summary>
        /// Transmision de Abm cuentas y tarjetas de credito.
        /// </summary>
        /// <returns></returns>
        public ResponseAbmTarjeta AltaBajaModificacionTarjetacredito()
        {
            _logger.LogInformation("AbmTarjetasCreditoBepsa - Iniciamos consulta de transmiciones pendientes.");

            var AbmSwitch = _tarjetasCreditoRepository.ObtenerParametrica((int)EnumParametrica.ParametricaABM, (int)EnumParametrica.SecuenciaParametros).Result;

            if (AbmSwitch == "S")
                throw new ApiException($"AbmTarjetasCreditoBepsa - Servicio de transmicion apagada temporalmente",
                    Convert.ToInt32(RespuestaBepsa.Error));

            List<PendientesEnvio> pendientesEnvios = _tarjetasCreditoRepository.GetPendientesEnvio();
            if (pendientesEnvios.Count == 0)
            {
                pendientesEnvios = _tarjetasCreditoRepository.RealizarProceso();
            }
            if (pendientesEnvios.Count == 0 || pendientesEnvios[0].Nroproces == "0")
            {
                _logger.LogWarning("AbmTarjetasCreditoBepsa - No existe registros que procesar.");
                return new ResponseAbmTarjeta()
                {
                    IdSesion = 0,
                    CodRespuesta = "90",
                    MsgRespuesta = "No existe registros que procesar."
                };
            }

            double nroProc = double.Parse(pendientesEnvios[0].Nroproces);
            _logger.LogInformation("AbmTarjetasCreditoBepsa - Numero de proceso obtenido: {0}.", nroProc);

            RequestConexionServicioCredito request = requestConexionServicioCredito(nroProc);
            if (request.Tarjetas == null && request.Cuentas == null && request.Personas == null)
            {
                _logger.LogWarning("AbmTarjetasCreditoBepsa - No se proceso ninguna transmicion del el numero de proceso {0}.", nroProc);
                return new ResponseAbmTarjeta()
                {
                    IdSesion = 0,
                    CodRespuesta = "90",
                    MsgRespuesta = "No existe registros que procesar."
                };
            }
            
            if(request.Cuentas.Count > 0 || request.Tarjetas.Count > 0 || request.Personas.Count > 0) 
            {
                respuesta = ConexionAbmTarjetasCredito(request, KeyToken.SERVICIO);
                if(respuesta.CodRespuesta == "00")
                {
                    _logger.LogInformation("AbmTarjetasCreditoBepsa - Proceso de transmision exitoso AbmCredito idSesion: " + respuesta.IdSesion);
                    _tarjetasCreditoRepository.ActualizaEnvioLoteBepsa(nroProc, EstadoEnvio.EstadoExitoso, respuesta.CodRespuesta, respuesta.MsgRespuesta);
                    var datos = request.Cuentas;
                    foreach (var dato in datos)
                    {
                        _tarjetasCreditoRepository.ActualizaTransmisionCuenta(dato.NroCuenta,
                                                                              dato.CodigoAfinidad,
                                                                              respuesta.IdSesion.ToString(),
                                                                              nroProc);
                    }
                    var datosTarjeta = request.Tarjetas;
                    foreach (var item in datosTarjeta)
                    {
                        _tarjetasCreditoRepository.ActualizaTransmisionTarjeta(item.NroTarjeta, respuesta.IdSesion.ToString(), nroProc);
                    }
                }
                else 
                {
                    _logger.LogWarning("AbmTarjetasCreditoBepsa - Proceso de transmision erroneo AbmCredito CodRespuestaBepsa: " + respuesta.CodRespuesta);
                    _tarjetasCreditoRepository.ActualizaEnvioLoteBepsa(nroProc, EstadoEnvio.EstadoErroneo, respuesta.CodRespuesta, respuesta.MsgRespuesta);
                }
            }
            
            return respuesta;
        }
        /// <summary>
        /// Metodo de conexion para generacion de token.
        /// </summary>
        public string ConexionAutenticacion(KeyToken credenciales)
        {
            var resultado = conexionApi.ConexionAutenticacion(credenciales);
            return resultado.Result.Token;
        }
        /// <summary>
        /// Metodo de conexion con el servicio de abm.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public ResponseAbmTarjeta ConexionAbmTarjetasCredito(RequestConexionServicioCredito request, KeyToken credenciales)
        {
            RequestAbmCredito requestAbmCredito = new RequestAbmCredito();
            List<RequestPersonas> personas = mapper.Map<List<RequestPersonas>>(request.Personas);
            var request_ = mapper.Map<RequestAbmCredito>(request);
            _logger.LogInformation("AbmTarjetasCreditoBepsa - Cargamos el request principal.");
            requestAbmCredito.Personas = personas; 
            requestAbmCredito.Cuentas = request_.Cuentas;
            requestAbmCredito.Tarjetas = request_.Tarjetas;
            var resultado = conexionApi.EjecutarServicioCredito(requestAbmCredito, credenciales);
            return new ResponseAbmTarjeta
            {
                CodRespuesta = resultado.Result.CodRespuesta,
                IdSesion = resultado.Result.IdSesion,
                MsgRespuesta = resultado.Result.MsgRespuesta
            };
        }
        private RequestConexionServicioCredito requestConexionServicioCredito(double nroProc)
        {
            RequestConexionServicioCredito request = new RequestConexionServicioCredito();
            List<DatosCuentaCredito> datosCuentaCreditos;
            List<DatosTarejtaCredito> datosTarjetaCreditos;

            datosCuentaCreditos = _tarjetasCreditoRepository.GetDatosCuenta(nroProc);
            datosTarjetaCreditos = _tarjetasCreditoRepository.GetDatosTarjeta(nroProc);
            if (datosCuentaCreditos[0].ExisteRegistro == 0 && datosTarjetaCreditos[0].ExisteRegistro == 0)
            {
                _tarjetasCreditoRepository.EliminaProceso(nroProc);
                _logger.LogWarning("AbmTarjetasCreditoBepsa - No existe registros que procesar, eliminamos el Nro. proceso: {0}.", nroProc);
                return request;
            }
            request.Cuentas = datosCuentaCreditos;
            request.Tarjetas = datosTarjetaCreditos;
            request.Personas = new List<DatosPersonas>();
            foreach (var item in datosCuentaCreditos)
            {
                if (item.DatosPersona != null)
                    request.Personas.AddRange(item.DatosPersona);
            }
            foreach (var item in datosTarjetaCreditos)
            {
                if (item.DatosPersona != null)
                {
                    item.DatosPersona.ForEach(e =>
                    {
                        if (!request.Personas.Contains(e))
                            request.Personas.Add(e);
                    });
                }
            }
            return request;
        }
        /// <summary>
        /// Transmision de cuentas pedientes de activación.
        /// </summary>
        /// <returns></returns>
        public CuentaActivacionResponse ActivacionCuentaTarjetaCredito()
        {
            List<SecuenciasPendientes> pendientesEnvios = _activacionRepository.GetPendientesEnvio();
            if (pendientesEnvios.Count > 0)
            {
                RequestConexionServicioActivacion request = requestConexionServicioActivacion();
                if (request.Lote == null)
                {
                    return new CuentaActivacionResponse()
                    {
                        Codigo = "90",
                        Mensaje = "No existe registros que procesar.",
                        Lote = new List<LoteCuentaResponse>()
                    };
                }
                _logger.LogInformation("ActivaciónTC - Se encontraron " + request.Lote.Count + " registros pendientes a transmitir.");
                respuestaCuenta = ConexionActivacionCuentaTarjeta(request);
                if (respuestaCuenta.Codigo == CodigosRespuesta.Procesado)
                {
                    foreach (var pendientes in respuestaCuenta.Lote)
                    {
                        if (pendientes.Codigo == CodigosRespuesta.Procesado || pendientes.Codigo == CodigosRespuesta.CuentaYaActiva)
                        {
                            _logger.LogInformation("00 -Proceso de transmision de cuenta exitoso - ActivaciónTC: ");
                            _activacionRepository.EstadoCtaTarActivacion(double.Parse(pendientes.Cuenta), EstadoActivacion.EstadoPendienteActivacionTarjeta, pendientes.Codigo + "-" + pendientes.Descripcion);

                        }
                        else
                        {
                            _logger.LogWarning(pendientes.Codigo + " -Proceso de transmision de cuenta erroneo - ActivaciónTC CodRespuestaBepsa: " + pendientes.Codigo);
                            _activacionRepository.EstadoCtaTarActivacion(double.Parse(pendientes.Cuenta), EstadoActivacion.EstadoCanceladoReintentos, pendientes.Codigo + "-" + pendientes.Descripcion);

                        }
                    }
                }
                else
                {
                    _logger.LogWarning(respuestaCuenta.Codigo + " -Proceso de transmision de cuenta erroneo - ActivaciónTC CodRespuestaBepsa: " + respuesta.CodRespuesta);
                }
            }
             return respuestaCuenta;
        }

        public TarjetaActivacionResponse ActivacionTarjetasCreditos()
        {
            List<SecuenciasPendientes> pendientesEnvios = _activacionRepository.GetTarjetasPendientesEnvio();
            if (pendientesEnvios.Count > 0)
            {
                RequestConexionServicioActivacionTarjeta request = requestConexionServicioActivacionTar();
                if (request.Lote == null)
                {
                    return new TarjetaActivacionResponse()
                    {
                        Codigo = "90",
                        Mensaje = "No existe registros que procesar.",
                        Lote = new List<LoteTarjetaResponse>()
                    };
                }
                respuestaTarjeta = ConexionActivacionTarjetasCredito(request);
                if (respuestaTarjeta.Codigo == CodigosRespuesta.Procesado)
                {
                    var datosTarjeta = respuestaTarjeta.Lote;
                    foreach (var item in datosTarjeta)
                    {
                        List<SecuenciasPendientes> obtieneSecuencia = _activacionRepository.GetNumeroSecuencia(item.Tarjeta);
                        double nroSecuencia = double.Parse(obtieneSecuencia[0].Numero);
                        if (item.CodigoRespuesta == CodigosRespuesta.Procesado || item.CodigoRespuesta == CodigosRespuesta.CuentaYaActiva)
                        {
                            _logger.LogInformation("00 -Proceso de transmision de TC exitoso - ActivaciónTC: ");
                            _activacionRepository.SetEstadoNroRegistro(nroSecuencia, EstadoActivacion.EstadoTarjetaActivada, item.CodigoRespuesta + "-" + item.Descripcion);
                            string tarjeta = item.Tarjeta.Substring(0, 15);
                            string digitoVerificador = item.Tarjeta.Substring(15);
                            List<SucursalTarjeta> sucursal = _activacionRepository.GetSucursalActivacion(tarjeta, digitoVerificador);
                            string numeroSucursal = sucursal[0].Sucursal;
                            List<NumeroCuentaTarjeta> cuentaNumero = _activacionRepository.GetNumeroCuentaTarjeta(nroSecuencia);
                            string cuentaNumeroTarjeta = cuentaNumero[0].NumeroCuenta;
                            _activacionRepository.ConfirmaActivacion(tarjeta, digitoVerificador, cuentaNumeroTarjeta, numeroSucursal);
                            _activacionRepository.EnviaCorreos(item.Tarjeta, EstadoActivacion.TipoActivacionCorrecta, item.Descripcion, nroSecuencia);
                        }
                        else
                        {
                            _logger.LogWarning(" -Proceso de transmision de TC erroneo - ActivaciónTC CodRespuestaBepsa: " + item.CodigoRespuesta +" " + item.Descripcion);
                            _activacionRepository.SetEstadoNroRegistro(nroSecuencia, EstadoActivacion.EstadoCanceladoReintentos, item.CodigoRespuesta + "-" + item.Descripcion); 
                            _activacionRepository.EnviaCorreos(item.Tarjeta, EstadoActivacion.TipoActivacionError, item.Descripcion, nroSecuencia);
                        }
                    }
                }
                else
                {
                    _logger.LogWarning("ActivaciónTC - Error en transmision: " + respuestaTarjeta.Codigo + " " + respuestaTarjeta.Mensaje);
                }
            }
            return respuestaTarjeta;
        }

        private RequestConexionServicioActivacion requestConexionServicioActivacion()
        {
            RequestConexionServicioActivacion request = new RequestConexionServicioActivacion();
            List<CuentaTarjeta> datosCuentaTarjetaCredito;

            datosCuentaTarjetaCredito = _activacionRepository.GetDatosCuentaTarjetaCredito();
            if (datosCuentaTarjetaCredito.Count == 0)
            {
                _logger.LogWarning("90 -No existe registros que procesar.");
                return request;
            }
            request.Lote = datosCuentaTarjetaCredito;
            return request;
        }
        private RequestConexionServicioActivacionTarjeta requestConexionServicioActivacionTar()
        {
            RequestConexionServicioActivacionTarjeta request = new RequestConexionServicioActivacionTarjeta();
            List<DatosTarjeta> datosActTarjetaCredito;

            datosActTarjetaCredito = _activacionRepository.GetDatosTarjetaCredito();
            if (datosActTarjetaCredito.Count == 0)
            {
                _logger.LogWarning("90 -No existe registros que procesar.");
                return request;
            }
            request.Lote = datosActTarjetaCredito;
            return request;
        }
        /// <summary>
        /// Metodo de conexion con el servicio de activacion.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public CuentaActivacionResponse ConexionActivacionCuentaTarjeta(RequestConexionServicioActivacion request)
        {
            var resultado = conexionApi.ConexionActivacionCuentaTarjeta(request, KeyToken.SERVICIO);
            return new CuentaActivacionResponse
            {
                Codigo = resultado.Result.Codigo,
                Mensaje = resultado.Result.Mensaje,
                Lote = resultado.Result.Lote
            };
        }
        public TarjetaActivacionResponse ConexionActivacionTarjetasCredito(RequestConexionServicioActivacionTarjeta request)
        {
            var resultado = conexionApi.ConexionActivacionTarjetasCredito(request, KeyToken.SERVICIO);
            return new TarjetaActivacionResponse
            {
                Codigo = resultado.Result.Codigo,
                Mensaje = resultado.Result.Mensaje,
                Lote = resultado.Result.Lote
            };
        }
        public ResponseMovEspeciales ConexionMovimientosEspeciales(RequestEnvioMovEspeciales request)
        {
            var resultado = conexionApi.ConexionMovimientosEspeciales(request, KeyToken.SERVICIO);
            return new ResponseMovEspeciales
            {
                codRespuesta = resultado.Result.codRespuesta,
                loteRespuesta = resultado.Result.loteRespuesta,
                msgRespuesta = resultado.Result.msgRespuesta
            };
        }
        /// <summary>
        /// Metodo de transmision de movimientos especiales.
        /// </summary>
        /// <returns></returns>
        public ResponseMovEspeciales TransmisionMovimientosEspeciales()
        {
            RequestEnvioMovEspeciales requesTransmision = new RequestEnvioMovEspeciales();
            requesTransmision.Lote = _tarjetasCreditoRepository.GetLotesMovEspeciales();
            if (requesTransmision.Lote.Count == 0) 
            {
                _logger.LogWarning("MovimientosEspeciales - 99 No existe registros pendientes de transmision.");
                return new ResponseMovEspeciales()
                {
                    codRespuesta = "1",
                    msgRespuesta = "99",
                    loteRespuesta = new List<LoteRespuesta>()
                };
            }
            _logger.LogInformation("MovimientosEspeciales - Se encontraron "+ requesTransmision.Lote.Count +" registros pendientes a transmitir.");
            ResponseMovEspeciales respuestaTransmision = ConexionMovimientosEspeciales(requesTransmision);
            if (respuestaTransmision.codRespuesta == "00")
            {
                _logger.LogInformation("MovimientosEspeciales - " + respuestaTransmision.codRespuesta +" " + respuestaTransmision.msgRespuesta);
                foreach (var item in respuestaTransmision.loteRespuesta)
                {
                   _tarjetasCreditoRepository.ActualizaTransmisionMovEspeciales(item.Tarjeta, item.CodigoRespuesta, item.Descripcion);
                }
            }
            else
            {
                _logger.LogWarning("MovimientosEspeciales - Error en transmision: " + respuestaTransmision.codRespuesta + " " + respuestaTransmision.msgRespuesta);
            }
            return respuestaTransmision;
        }
        public ResponseReimpresion ConexionReimpresion(RequestReimpresion request)
        {
            var resultado = conexionApi.ConexionReimpresion(request, KeyToken.SERVICIO);
            return new ResponseReimpresion
            {
                Codigo = resultado.Result.Codigo,
                Lote = resultado.Result.Lote,
                Mensaje = resultado.Result.Mensaje
            };
        }
        /// <summary>
        /// Metodo de transmision de reimpresiones.
        /// </summary>
        /// <returns></returns>
        public ResponseReimpresion TransmisionReimpresion()
        {
            // Si es día de transmisión de Renovaciones, no realizamos las reimpresiones hasta la hora parametrizada
            if (_renovacionService.EsDiaDeRenovacion())
            {
                _logger.LogInformation("Reimpresion - Es día de renovaciones, no realizamos las reimpresiones según la hora parametrizada.");
                return new ResponseReimpresion()
                {
                    Codigo = "1",
                    Mensaje = "Es día de renovaciones, no realizamos las reimpresiones según la hora parametrizada.",
                    Lote = new List<LoteReimpresionRespuesta>()
                };
            }

            List<PendientesReimpresion> pendientesReenvios = _reimpresionRepository.GetPendientesReenvio();
            if (pendientesReenvios.Count == 0)
            {
              _reimpresionRepository.GetNuevoProcesoReimpresion();
               pendientesReenvios = _reimpresionRepository.GetPendientesReenvio();
            }
            if (pendientesReenvios.Count > 0)
            {
                double numeroProceso = double.Parse(pendientesReenvios[0].NumeroProceso);
                RequestReimpresion requesTransmision = new RequestReimpresion();
                requesTransmision.Lote = _reimpresionRepository.GetLotesReimpresion(numeroProceso);
                _logger.LogInformation("Reimpresion - Se encontraron " + requesTransmision.Lote.Count + " registros pendientes a transmitir.");
                ResponseReimpresion respuestaTransmision = ConexionReimpresion(requesTransmision);
                if (respuestaTransmision.Lote != null)
                {
                    foreach (var item in respuestaTransmision.Lote)
                    {
                        if (respuestaTransmision.Codigo == "00")
                        {
                            _logger.LogInformation("Reimpresion - " + respuestaTransmision.Codigo + " " + respuestaTransmision.Mensaje);
                            if (item.CodigoRespuesta == "00")
                            {
                                _reimpresionRepository.ActualizaTransmisionReimpresion(item.Tarjeta);
                            }
                        }
                        else
                        {
                            _logger.LogWarning("Reimpresion - Error en transmision: " + respuestaTransmision.Codigo + " " + respuestaTransmision.Mensaje);
                            _reimpresionRepository.ErrorTransmision(numeroProceso, respuestaTransmision.Mensaje);
                        }
                        _reimpresionRepository.ActualizaDatosEnvio(numeroProceso, item.CodigoRespuesta);
                        _reimpresionRepository.InsertaLogProceso(numeroProceso, requesTransmision.Lote.Count, item.Descripcion, item.CodigoRespuesta, item.Tarjeta);
                    }
                }
                return respuestaTransmision;
            }
            else
            {
                    _logger.LogWarning("Reimpresion - 99 No existe registros pendientes de transmision.");
                    return new ResponseReimpresion()
                    {
                        Codigo = "1",
                        Mensaje = "99",
                        Lote = new List<LoteReimpresionRespuesta>()
                    };
            }

            
        }

        public async Task<EstadoTransmisionesResponse> EstadoTransmisionAsync()
        {
            List<EstadoRegistrosPendientes> estadoTarjetasPendientes = await _tarjetasCreditoRepository.GetTarjetasPendientesEstadoAsync(TipoArchivo.Tarjeta);
            List<EstadoRegistrosPendientes> estadoCuentasPendientes = await _tarjetasCreditoRepository.GetTarjetasPendientesEstadoAsync(TipoArchivo.Cuenta);
            if (estadoTarjetasPendientes.Count == 0 && estadoCuentasPendientes.Count == 0)
                throw new ApiException("AbmEstadoTransmisionCredito - No existen registros que procesar.",
                                       Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                                       StatusCodes.Status200OK);

            if (estadoTarjetasPendientes.Count > 0)
                await ProcesaTarjetasEstadosTransmisionesAsync(estadoTarjetasPendientes);
            if (estadoCuentasPendientes.Count > 0)
                await ProcesaCuentasEstadosTransmisionesAsync(estadoCuentasPendientes);

            return new EstadoTransmisionesResponse()
            {
                Codigo = RespuestaBepsa.Aprobada,
                Mensaje = "Registros actualizados"
            };
        }

        public async Task ProcesaTarjetasEstadosTransmisionesAsync(List<EstadoRegistrosPendientes> pendientesEstados)
        {
            _logger.LogInformation("EstadoTarjetasDebitoBepsa - Se encontraron " + pendientesEstados.Count + " registros pendientes a transmitir.");
            foreach (var pendientes in pendientesEstados)
            {
                var requestAbmErroresTarjeta = new AbmEstadoErroresRequest()
                {
                    IdSesion = pendientes.IdSesion,
                    Cuenta = pendientes.NumeroTarjeta,
                    TipoArchivo = TipoArchivo.Tarjeta
                };

                if (!string.IsNullOrEmpty(requestAbmErroresTarjeta.Cuenta))
                    await ServicioAbmErroresAsync(requestAbmErroresTarjeta, pendientes);

                var requestAbmErroresPersona = new AbmEstadoErroresRequest()
                {
                    IdSesion = pendientes.IdSesion,
                    Cuenta = pendientes.Documento,
                    TipoArchivo = TipoArchivo.Persona
                };

                if (!string.IsNullOrEmpty(requestAbmErroresPersona.Cuenta))
                    await ServicioAbmErroresAsync(requestAbmErroresPersona, pendientes);
            }
        }

        public async Task ProcesaCuentasEstadosTransmisionesAsync(List<EstadoRegistrosPendientes> pendientesEstados)
        {
            _logger.LogInformation("EstadoTarjetasDebitoBepsa - Se encontraron " + pendientesEstados.Count + " registros pendientes a transmitir.");
            foreach (var pendientes in pendientesEstados)
            {
                var requestAbmErroresTarjeta = new AbmEstadoErroresRequest()
                {
                    IdSesion = pendientes.IdSesion,
                    Cuenta = pendientes.NumeroCuenta,
                    TipoArchivo = TipoArchivo.Cuenta
                };

                if (!string.IsNullOrEmpty(requestAbmErroresTarjeta.Cuenta))
                    await ServicioAbmErroresAsync(requestAbmErroresTarjeta, pendientes);
            }
        }

        public async Task ServicioAbmErroresAsync(AbmEstadoErroresRequest abmEstadoErroresRequest,
                                                  EstadoRegistrosPendientes pendientes)
        {
            _logger.LogInformation($"EstadoTarjetasDebitoBepsa - Se ejecuta servicio de Bepsa. IdSesion: {abmEstadoErroresRequest.IdSesion} Cuenta: {abmEstadoErroresRequest.Cuenta}");

            try
            {
                var resultado = await conexionApi.EjecutarServicioAbmErroresAsync(abmEstadoErroresRequest,
                                                                              KeyToken.SERVICIO);

                await ActualizarEstadosErroresAsync(resultado,
                                                    abmEstadoErroresRequest,
                                                    pendientes);
            }
            catch (ApiException ex)
            {
                _logger.LogError("Error al consultar el estado de la transmicion: " + abmEstadoErroresRequest.Cuenta + "Mensaje error: " + ex.Mensaje);
            }
            catch (Exception exc)
            {
                _logger.LogError("Error al consultar el estado de la transmicion: " + abmEstadoErroresRequest.Cuenta + "Mensaje error: " + exc.Message);
            }
        }

        public async Task ActualizarEstadosErroresAsync(EstadoTransmisionesResponse resultado,
                                                        AbmEstadoErroresRequest abmEstadoErroresRequest,
                                                        EstadoRegistrosPendientes pendientes)
        {
            if (resultado.Errores is null && !(resultado.Codigo is null))
                await EstadoSinErroresAsync(resultado, abmEstadoErroresRequest, pendientes);
            else
                await EstadoConErroresAsync(resultado, abmEstadoErroresRequest, pendientes);
        }

        public async Task EstadoSinErroresAsync(EstadoTransmisionesResponse resultado,
                                                AbmEstadoErroresRequest abmEstadoErroresRequest,
                                                EstadoRegistrosPendientes pendientes)
        {
            await _tarjetasCreditoRepository.ActualizaEstadoAsync(abmEstadoErroresRequest.IdSesion,
                                                                  resultado.Codigo,
                                                                  resultado.Mensaje,
                                                                  pendientes.LogKey,
                                                                  abmEstadoErroresRequest.TipoArchivo);
            _logger.LogInformation($"EstadoTarjetasDebitoBepsa - Registro actualizado con éxito. IdSesion: {abmEstadoErroresRequest.IdSesion} Cuenta: {abmEstadoErroresRequest.Cuenta}");
        }

        public async Task EstadoConErroresAsync(EstadoTransmisionesResponse resultado,
                                                AbmEstadoErroresRequest abmEstadoErroresRequest,
                                                EstadoRegistrosPendientes pendientes)
        {
            await _tarjetasCreditoRepository.ActualizaEstadoAsync(abmEstadoErroresRequest.IdSesion,
                                                                  resultado.Errores[0].Codigo,
                                                                  JsonConvert.SerializeObject(resultado.Errores),
                                                                  pendientes.LogKey,
                                                                  abmEstadoErroresRequest.TipoArchivo);
            _logger.LogInformation($"EstadoTarjetasDebitoBepsa - Registro actualizado con éxito. IdSesion: {abmEstadoErroresRequest.IdSesion} Cuenta: {abmEstadoErroresRequest.Cuenta}");
        }

        /// <summary>
        /// Metodo que prepara los datos de los registros a transmitir a Bepsa para pagos TC
        /// </summary>
        /// <returns>ResponsePagosTC</returns>
        public async Task<ResponsePagoTC> PagosTarjetaAsync()
        {
            var parametrosPago = JsonConvert.DeserializeObject<ParametricaPago>(await _tarjetasCreditoRepository.ObtenerParametrica((int)EnumParametrica.ParametricaPago, (int)EnumParametrica.SecuenciaParametros));
            if (parametrosPago.SwitchPagoV2)
            {
                await _mediator.Send(new PagoCommand(parametrosPago));
                return new ResponsePagoTC { CodigoRespuesta = "00", MensajeRespuesta = "PROCESADO CORRECTAMENTE V2" };
            }
            else
            {
                _logger.LogInformation("Iniciando PagosTarjetaAsync...");
                var estadoProceso = await _tarjetasCreditoRepository.ConsultarEstadoProceso();

                if (estadoProceso == EstadoProceso.Ocupado)
                    throw new ApiException("ServicioPagoTC - Servicio HangFire de Transmision de Pagos a Bepsa se encuentra Ocupado.",
                                         Convert.ToInt32(RespuestaBepsa.ExisteTransmisionesPendientes),
                                         StatusCodes.Status200OK);

                RequestPagoTC requesTransmision = new RequestPagoTC
                {
                    Lote = await _tarjetasCreditoRepository.GetLotesPagoTC()
                };

                if (requesTransmision.Lote.Count == 0)
                    throw new ApiException("ServicioPagoTC - No existe registros que procesar.",
                                         Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar),
                                         StatusCodes.Status200OK);

                //Ponemos el proceso como ocupado para evitar que se ejecute otro hilo
                this.ModificarEstadoProceso(EstadoProceso.Ocupado);

                var respuesta = await ProcesaPagosAsync(requesTransmision);

                return respuesta;
            }
        }

        /// <summary>
        /// Realiza la conexion y el envio del request al servicio de pagostc de bepsa.
        /// </summary>
        public async Task<ResponsePagoTC> ConexionPagoTCAsync(RequestPagoTC request)
        {
            var resultado =  await conexionApi.ConexionPagoTarjetaCreditoAsync(request, KeyToken.SERVICIO);
            return new ResponsePagoTC
            {
                CodigoRespuesta = resultado.CodigoRespuesta,
                LoteRespuesta = resultado.LoteRespuesta,
                MensajeRespuesta = resultado.MensajeRespuesta
            };
        }
        /// <summary>
        /// Metodo que procesa los registros transmitidos para pago a Bepsa
        /// </summary>
        public async Task<ResponsePagoTC> ProcesaPagosAsync(RequestPagoTC requestPago)
        {
            _logger.LogInformation("ServicioPagoTC - Se encontraron {cantidadPagos} registros pendientes a transmitir.", requestPago.Lote.Count);

            try
            {
                ResponsePagoTC responsePagoTC = await ConexionPagoTCAsync(requestPago);
                _logger.LogInformation("ServicioPagoTC - {codigoRespuesta} - {mensajeRespuesta}", responsePagoTC.CodigoRespuesta, responsePagoTC.MensajeRespuesta);

                if (responsePagoTC.CodigoRespuesta == RespuestaBepsa.Aprobada)
                {
                    foreach (var item in responsePagoTC.LoteRespuesta)
                    {
                        var monto = requestPago.Lote.Find(f => f.NumeroTarjeta.Equals(item.Tarjeta)).Importe.ToString();

                        try
                        {
                            await _tarjetasCreditoRepository.ActualizaPagosTcAsync(item.Tarjeta, item.CodigoRespuesta, item.Descripcion, monto);

                            _logger.LogInformation("ServicioPagoTC - Respuesta de Bepsa : Tarjeta: {TarjetaNumero} - Monto {ImportePago} -" +
                                " Respuesta : {CodigoRespuesta} - {DescripcionRespuesta} ",
                                item.Tarjeta,
                                monto,
                                item.CodigoRespuesta,
                                item.Descripcion);
                        }
                        catch
                        {
                            _logger.LogError("ServicioPagoTC - Error al procesar el pago: Tarjeta: {@PagoTarjetaConError} - Monto: {monto}",item,monto);
                        }
                    }
                    //Dejamos el Proceso disponible para que se pueda volver a ejecutar
                    this.ModificarEstadoProceso(EstadoProceso.Disponible);
                }
                else
                {
                    requestPago.Lote.ForEach(async x => await _tarjetasCreditoRepository.ActualizaPagosTcAsync(
                        x.NumeroTarjeta,
                        responsePagoTC.CodigoRespuesta,
                        responsePagoTC.MensajeRespuesta,
                        x.Importe.ToString()));

                    //Dejamos el Proceso disponible para que se pueda volver a ejecutar
                    this.ModificarEstadoProceso(EstadoProceso.Disponible);

                    _logger.LogWarning("ServicioPagoTC - Error en transmision de Pagos : {@ErrorTransmisionPagos}", responsePagoTC);
                }

                return responsePagoTC;
            }
            catch (Exception ex)
            {
                requestPago.Lote.ForEach(async x => await _tarjetasCreditoRepository.ActualizaPagosTcAsync(
                    x.NumeroTarjeta,
                    "99",
                    ex.Message,
                    x.Importe.ToString()));

                //Dejamos el Proceso disponible para que se pueda volver a ejecutar
                this.ModificarEstadoProceso(EstadoProceso.Disponible);
                throw;
            }
        }

        public void ModificarEstadoProceso(string estado)
        {
            _tarjetasCreditoRepository.ActualizaEstadoProceso(estado);
        }
    }
}
