﻿using Continental.API.Core.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Services
{
    public class ConexionApiPago : IConexionApiPago
    {
        private readonly IConfiguration _configuraciones;
        private readonly HttpClient _apiClient;

        public ConexionApiPago(IConfiguration configuraciones, IHttpClientFactory httpClientFactory, ILogger<ConexionApiPago> logger)
        {
            _configuraciones = configuraciones;
            int timeout = configuraciones.GetValue<int?>("HttpClientTimeoutFromSecondsPago") ?? 180;
            logger.LogInformation("HttpClientTimeoutPago: {timeout} seg.", timeout);
            _apiClient = httpClientFactory.CreateClient("ConexionApiPago");
            _apiClient.Timeout = TimeSpan.FromSeconds(timeout);
        }

        //Metodo para obtener las urls.
        public string EndPoint(EnumUrl Url, EnumMethods Methods, dynamic bodyParam)
        {

            //Obtenemos la url de la appsetting.
            var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key.ToUpper() == Url.ToString().ToUpper());
            var endpoint = credenciales.UrlServicio;

            //Completamos las urls.
            endpoint += Methods switch
            {
                EnumMethods.Default => string.Empty,
                EnumMethods.ConsultaPago => "/" + bodyParam,
                _ => "/"
            };
            return endpoint;
        }

        public async Task<HttpResponseMessage> InvocarServicios(EnumUrl url,
                                                                EnumMethods methods,
                                                                dynamic bodyParam,
                                                                HttpMethod httpMethod,
                                                                Dictionary<string, string> headers)
        {

            //Obtenemos los endpoints.
            var endpoint = EndPoint(url, methods, bodyParam);

            var requestMessage = new HttpRequestMessage(httpMethod, endpoint);

            if (headers != null)
            {
                foreach (var kvp in headers)
                {
                    requestMessage.Headers.Add(kvp.Key, kvp.Value);
                }
            }

            if (HttpMethod.Get == httpMethod || HttpMethod.Delete == httpMethod)
            {
                var response = await _apiClient.SendAsync(requestMessage);

                return response;
            }
            else
            {
                string typeBody = bodyParam.GetType().Name;

                requestMessage.Content = new StringContent(typeBody == "String" ? bodyParam.ToString() : JsonConvert.SerializeObject(bodyParam),
                                                Encoding.UTF8, "application/json");

                var response = await _apiClient.SendAsync(requestMessage);

                return response;
            }
        }
    }
}
