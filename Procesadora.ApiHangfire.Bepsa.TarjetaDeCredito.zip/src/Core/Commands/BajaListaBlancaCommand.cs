﻿using Continental.API.Core.Entities;
using Continental.API.Core.Interfaces;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.ListaBlanca;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands
{
    public class BajaListaBlancaCommand : IRequest{ }
    public class BajaListaBlancaCommandHandler : IRequestHandler<BajaListaBlancaCommand>
    {
        private readonly ILogger<BajaListaBlancaCommandHandler> _logger;
        private readonly IRepositoryListaBlanca _repositoryLista;
        private readonly IConexionApiPago _conexionApi;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuraciones;

        public BajaListaBlancaCommandHandler(ILogger<BajaListaBlancaCommandHandler> logger,
                                IRepositoryListaBlanca repositoryLista,
                                IConexionApiPago conexionApi,
                                IMemoryCache cache,
                                IConfiguration configuraciones)
        {
            _logger = logger;
            _repositoryLista = repositoryLista;
            _conexionApi = conexionApi;
            _cache = cache;
            _configuraciones = configuraciones;
        }
        public async Task<Unit> Handle(BajaListaBlancaCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var timer = Stopwatch.StartNew();

                _logger.LogInformation("ServicioBajaListaB - Iniciando BajaListaBlancaAsync... - time: {0} ms", timer.Elapsed.TotalMilliseconds);
                var parametricaListaBlanca = await ObtenerParametricaLB();

                if (!parametricaListaBlanca.Switch)
                    throw new ApiException.ApiException("ServicioBajaListaB - El servicio actualmente se encuentra apagado.", 99);

                var listaBajasPendientes = await ObtenerListaPendientes(parametricaListaBlanca);

                _logger.LogInformation("ServicioBajaListaB - Se encontraron {0} registros pendientes a transmitir. - time: {1} ms", listaBajasPendientes.Count, timer.Elapsed.TotalMilliseconds);

                _logger.LogInformation("ServicioBajaListaB - Iniciamos proceso de envio de Baja - time: {1} ms", timer.Elapsed.TotalMilliseconds);
                await ProcesarBajaLista(listaBajasPendientes, parametricaListaBlanca);

                _logger.LogInformation("ServicioBajaListaB - Finalizando BajaListaBlancaAsync... - time: {1} ms", timer.Elapsed.TotalMilliseconds);

                return Unit.Value;
            }
            catch (ApiException.ApiException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task<List<DatosListaBlanca>> ObtenerListaPendientes(ParametricaListaBlanca parametrica)
        {
            var pagosPendientes = await _repositoryLista.ObtenerListaPendientes(parametrica);

            if (pagosPendientes.Count == 0)
                throw new ApiException.ApiException("ServicioBajaListaB - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar));

            return pagosPendientes;
        }

        private async Task ConsultaEstadoProceso()
        {
            var consultaEstadoParam = await _repositoryLista.ObtenerParametrica((decimal)EnumParametrica.ParametricaEstadoLB, (decimal)EnumParametrica.SecuenciaBajaLB);
            if (consultaEstadoParam.Valor == EstadoProceso.Ocupado)
                throw new ApiException.ApiException("ServicioBajaListaB - Servicio de Transmision de Baja de lista a Bepsa se encuentra Ocupado.",
                    Convert.ToInt32(RespuestaBepsa.ExisteTransmisionesPendientes));
        }

        private async Task ProcesarBajaLista(List<DatosListaBlanca> DatosAltaLista, ParametricaListaBlanca param)
        {
            foreach (var tarjeta in DatosAltaLista)
            {
                await ActualizarBajaLista(tarjeta.IdTarjeta, param, tarjeta.Id);
            }
        }

        private async Task ActualizarBajaLista(decimal idTarjeta, ParametricaListaBlanca parametro, decimal idOperacion)
        {
            try
            {
                var listaPendiente = new DatosListaBlanca();
                var operacion = await _repositoryLista.ObtenerOperacionPendiente(idOperacion);
                var response = await TransmitirBajasListaBlanca(idTarjeta, operacion);
                _logger.LogInformation("ServicioBajaListaB - Bajas procesada, idTarjeta: {0}", idTarjeta);

                listaPendiente.estado = response.Codigo == "00" || response.Codigo == "33" ? (int)EnumEstadoListaBlanca.Procesado
                : response.Codigo != "00" && operacion.Intentos + 1 < parametro.Intento ? parametro.Estado : (int)EnumEstadoListaBlanca.Cancelado;
                listaPendiente.CodigoRetorno = response.Codigo;
                listaPendiente.MensajeRetorno = response.Mensaje;
                listaPendiente.FechaModificacion = DateTime.Now;
                listaPendiente.Id = idOperacion;
                listaPendiente.IdTarjeta = idTarjeta;
                listaPendiente.Intentos = operacion.Intentos + 1;

                await _repositoryLista.ActualizaEstadoListaBlanca(listaPendiente);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioBajaListaB - Baja de lista error al actualizar el idOp: {0}", idOperacion);
            }
        }
        private async Task<ListaBlancaResponse> TransmitirBajasListaBlanca(decimal idTarjeta, DatosListaBlanca request)
        {
            try
            {
                var procesarAltaListaB = new HttpResponseMessage();

                Dictionary<string, string> headers = new Dictionary<string, string>()
                {
                    { "Authorization", "Bearer " + await ObtenerTokenCache()
                    }
                };

                _logger.LogInformation("ServicioBajaListaB - transmision de baja de idTarjeta: {0}", idTarjeta);

                if (request.TipoMarca == EnumTipoMarca.Todos)
                {
                    var NumeroDocumento = await _repositoryLista.ObtenerNumeroDocumento(request.NumeroTarjeta[..15], request.NumeroTarjeta.Substring(15, 1));
                    request.NumeroDocumento = NumeroDocumento ?? await _repositoryLista.ObtenerNroDocumentoTd(request.NumeroTarjeta);
                    procesarAltaListaB = await _conexionApi.InvocarServicios(EnumUrl.ServicioListaBlanca,
                                                                             EnumMethods.ConsultaPago,
                                                                             request.NumeroTarjeta[..6] + "/" + request.NumeroTarjeta.Substring(12, 4) + "/" + request.NumeroDocumento.TrimStart('0'),
                                                                             HttpMethod.Delete,
                                                                             headers);
                }
                else
                {

                    procesarAltaListaB = await _conexionApi.InvocarServicios(EnumUrl.ServicioListaBlanca,
                                                                             EnumMethods.ConsultaPago,
                                                                             idTarjeta,
                                                                             HttpMethod.Delete,
                                                                             headers);
                }

                var jsonString = await procesarAltaListaB.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioBajaListaB - La api de baja de lista blanca respondio con el statuscode: {1}", (object)procesarAltaListaB.StatusCode);
                if (procesarAltaListaB.IsSuccessStatusCode)
                {
                    _logger.LogInformation("ServicioBajaListaB - respuesta del servicio de bepsa jsonString: {0}", jsonString);
                    return JsonConvert.DeserializeObject<ListaBlancaResponse>(jsonString);
                }
                else
                {
                    _logger.LogError("ServicioBajaListaB - Error al procesar baja lista blanca, respuesta obtenida: {0}", jsonString);
                    return JsonConvert.DeserializeObject<ListaBlancaResponse>(jsonString);
                }
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ServicioBajaListaB - Error en la solicitud HTTP en la baja lista blanca");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ServicioBajaListaB - Tiempo de espera de la solicitud agotado en el alta lista blanca");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioBajaListaB - Ocurrio un error al invocar el servicio de alta lista blanca");
                throw;
            }
        }
        private async Task<string> ObtenerTokenCache()
        {
            return await _cache.GetOrCreateAsync("TOKENAUTENTICACION", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
                p.Priority = CacheItemPriority.Normal;
                var valor = await ObtenerToken();
                return valor;
            });
        }
        //Generamos el token de autenticacion
        private async Task<string> ObtenerToken()
        {
            try
            {
                var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key == EnumUrl.AutenticacionPago.ToString().ToUpper());
                var requestToken = new TokenRequest { Usuario = credenciales.Usuario, Password = credenciales.Clave };

                _logger.LogInformation("ServicioBajaListaB - Iniciamos la consulta de token");

                var consultaToken = await _conexionApi.InvocarServicios(EnumUrl.AutenticacionPago,
                                                                            EnumMethods.Default,
                                                                            requestToken,
                                                                            HttpMethod.Post,
                                                                            null);
                var jsonString = await consultaToken.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioBajaListaB - La api de consulta de token respondio con el statuscode: {1}", consultaToken.StatusCode);

                if (consultaToken.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<TokenResponse>(jsonString);

                    return response.AccessToken;
                }
                else
                {
                    _logger.LogError("ServicioBajaListaB - Error al generar el token, respuesta obtenida: {0}", jsonString);
                    throw new ApiException.ApiException($"ServicioBajaListaB - No se pudo obtener el token.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ServicioBajaListaB - Error en la solicitud HTTP para el token");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ServicioBajaListaB - Tiempo de espera de la solicitud agotado para el token");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ServicioBajaListaB - Ocurrio un error al invocar el servicio de generar token");
                throw;
            }
        }

        private async Task<ParametricaListaBlanca> ObtenerParametricaLB()
        {
            var dtParametroFecha = await _repositoryLista.ObtenerParametrica((decimal)EnumParametrica.ParametricaLB,
                                                                             (decimal)EnumParametrica.SecuenciaBajaLB);
            return JsonConvert.DeserializeObject<ParametricaListaBlanca>(dtParametroFecha.Valor);
        }
    }
}
