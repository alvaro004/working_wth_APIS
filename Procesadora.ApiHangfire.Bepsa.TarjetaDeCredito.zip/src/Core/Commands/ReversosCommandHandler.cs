﻿using Continental.API.Core.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Reversos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands
{
    public class ReversoCommand : IRequest { };

    public class ReversosCommandHandler : IRequestHandler<ReversoCommand>
    {
        //aca constructor
        private readonly ILogger<ReversosCommandHandler> _logger;
        private readonly IRepositoryPagoDapper _repositoryPagoDapper;
        private readonly IRepositoryPagoEF _repositoryPagoEF;
        private readonly IConexionApiPago _conexionApiPago;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuraciones;

        public ReversosCommandHandler(ILogger<ReversosCommandHandler> logger,
                                 IRepositoryPagoDapper repositoryPagoDapper,
                                 IRepositoryPagoEF repositoryPagoEF,
                                 IConexionApiPago conexionApiPago,
                                 IMemoryCache cache,
                                 IConfiguration configuraciones)
        {
            _logger = logger;
            _repositoryPagoDapper = repositoryPagoDapper;
            _repositoryPagoEF = repositoryPagoEF;
            _conexionApiPago = conexionApiPago;
            _cache = cache;
            _configuraciones = configuraciones;
        }

        public async Task<Unit> Handle(ReversoCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var timer = Stopwatch.StartNew();
                _logger.LogInformation("ReversoPagoTC - Iniciando ReversosTarjetaAsync... - time: {0} ms", timer.Elapsed.TotalMilliseconds);

                var parametricaPago = await ObtenerParametricaPago();

                if (!parametricaPago.SwitchPagoV2)
                    throw new ApiException.ApiException($"ReversoPagoTC - Envio de reverso de pagos apagado",
                        Convert.ToInt32(RespuestaBepsa.Error));

                var reversosPendientes = await ObtenerPagosPendientes(parametricaPago);
                _logger.LogInformation("ReversoPagoTC - Se encontraron {0} registros pendientes a transmitir. - time: {1} ms", reversosPendientes.Count, timer.Elapsed.TotalMilliseconds);

                _logger.LogInformation("ReversoPagoTC - Iniciamos proceso de envio de reverso pagos - time: {1} ms", timer.Elapsed.TotalMilliseconds);
                await ProcesarReversos(reversosPendientes, parametricaPago);
                _logger.LogInformation("ReversoPagoTC - Finalizamos proceso de envio de reverso pagos - time: {1} ms", timer.Elapsed.TotalMilliseconds);

                return Unit.Value;
            }
            catch (ApiException.ApiException ex)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task<ParametricaPago> ObtenerParametricaPago()
        {
            var dtParametroFecha = await _repositoryPagoEF.ObtenerParametrica((decimal)EnumParametrica.ParametricaPago, (decimal)EnumParametrica.SecuenciaParamReversos);
            return JsonConvert.DeserializeObject<ParametricaPago>(dtParametroFecha.Valor);
        }

        private async Task<List<RequestReverso>> ObtenerPagosPendientes(ParametricaPago parametricaPago)
        {
            var pagosPendientes = await _repositoryPagoEF.ObtenerReversossPendientes(parametricaPago, DateTime.Today);
            
            if (pagosPendientes.Count == 0)
                throw new ApiException.ApiException("ReversoPagoTC - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar));

           
            var RequestReverso = pagosPendientes;

            return RequestReverso;
        }

        private async Task ProcesarReversos(List<RequestReverso> requestReverso, ParametricaPago param)
        {
            var tasks = new List<Task>();
            int count = 0;
            int giro = 0;

            requestReverso.ForEach(async comprobante =>
            {
                giro++;
                _logger.LogError("ReversoPagoTC - giro {0} - comprobante {1}", giro, comprobante.Comprobante);
                tasks.Add(Task.Run(() => ActualizarEstadoReverso(comprobante.Comprobante, param)));
                count++;
                if (count == param.Hilos)
                {
                    try
                    {
                        //Esperamos que se ejecuten todas las tareas.
                        await Task.WhenAll(tasks);
                    }
                    catch (AggregateException ae)
                    {
                        foreach (var ex in ae.Flatten().InnerExceptions)
                            _logger.LogError(ex, "ReversoPagoTC - Ocurrio una excepcion al enviar la peticion de reverso");
                    }
                    count = 0;
                    tasks = new List<Task>();
                }
            });

            if (tasks.Count > 0)
                await Task.WhenAll(tasks);
            _logger.LogInformation($"ReversoPagoTC - total de operaciones reversadas: {giro}.");
        }
        private async Task<ReversoResponse> TransmitirReversos(RequestReverso RequestReverso)
        {
            try
            {
                Dictionary<string, string> headers = new Dictionary<string, string>()
                {
                    { "Authorization", "Bearer " + await ObtenerTokenCache()
                    }
                };

                _logger.LogInformation("ReversoPagoTC - Inicamos el envio de reveso comprobante {0}", RequestReverso.Comprobante);

                var procesarReverso = await _conexionApiPago.InvocarServicios(EnumUrl.ServicioReverso,
                                                                           EnumMethods.Default,
                                                                           RequestReverso,
                                                                           HttpMethod.Post,
                                                                           headers);
                var jsonString = await procesarReverso.Content.ReadAsStringAsync();

                _logger.LogInformation("ReversoPagoTC - La api de reverso respondio con el statuscode: {1}", (object)procesarReverso.StatusCode);
                if (procesarReverso.IsSuccessStatusCode)
                {
                    _logger.LogError("ReversoPagoTC - Reverso ok, respuesta obtenida: {0} - RequestReverso: {1}", jsonString, RequestReverso);
                    return JsonConvert.DeserializeObject<ReversoResponse>(jsonString);
                }
                else
                {
                    _logger.LogError("ReversoPagoTC - Error al procesar el reverso, respuesta obtenida: {0} - RequestReverso: {1}", jsonString, RequestReverso);
                    throw new ApiException.ApiException("ReversoPagoTC - No se pudo realizar el reverso del pago.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ReversoPagoTC - Error en la solicitud HTTP en el reverso");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ReversoPagoTC - Tiempo de espera de la solicitud agotado en el reverso");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ReversoPagoTC - Ocurrio un error al invocar el servicio de reversos");
                throw;
            }
        }
        private async Task<string> ObtenerTokenCache()
        {
            return await _cache.GetOrCreateAsync("TOKENAUTENTICACION", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
                p.Priority = CacheItemPriority.Normal;
                var valor = await ObtenerToken();
                return valor;
            });
        }
        //Generamos el token de autenticacion
        private async Task<string> ObtenerToken()
        {
            try
            {
                var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key == EnumUrl.AutenticacionPago.ToString().ToUpper());
                var requestToken = new TokenRequest { Usuario = credenciales.Usuario, Password = credenciales.Clave };

                _logger.LogInformation("ReversoPagoTC - Iniciamos la consulta de token");

                var consultaToken = await _conexionApiPago.InvocarServicios(EnumUrl.AutenticacionPago,
                                                                            EnumMethods.Default,
                                                                            requestToken,
                                                                            HttpMethod.Post,
                                                                            null);
                var jsonString = await consultaToken.Content.ReadAsStringAsync();

                _logger.LogInformation("ReversoPagoTC - La api de consulta de token respondio con el statuscode: {1}", consultaToken.StatusCode);

                if (consultaToken.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<TokenResponse>(jsonString);

                    return response.AccessToken;
                }
                else
                {
                    _logger.LogError("ReversoPagoTC - Error al generar el token, respuesta obtenida: {0}", jsonString);
                    throw new ApiException.ApiException($"ReversoPagoTC - No se pudo obtener el token.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ReversoPagoTC - Error en la solicitud HTTP para el token");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ReversoPagoTC - Tiempo de espera de la solicitud agotado para el token");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ReversoPagoTC - Ocurrio un error al invocar el servicio de generar token");
                throw;
            }
        }

        private async Task ActualizarEstadoReverso(decimal comprobante, ParametricaPago parametro)
        {
            try
            {
                var request = new RequestReverso { Comprobante = comprobante };
                var response = await TransmitirReversos(request);
                _logger.LogInformation("ReversoPagoTC - Reverso procesado, Comprobante: {0}", request.Comprobante);

                var TaskPagoPendiente = await _repositoryPagoDapper.ObtenerPago(request.Comprobante);

                var reversoPendiente = new PagoEF
                {
                    EstadoPago = response.Codigo == "00" || response.Codigo == "52" ? (int)EnumEstadoPago.Reversado
                    : response.Codigo != "00" && TaskPagoPendiente.Intento + 1 < parametro.Intento ? parametro.EstadoPago : (int)EnumEstadoPago.ReversoCancelado,
                    CodigoResuesta = response.Codigo,
                    MensajeRespuesta = response.Mensaje,
                    FechaModificacion = DateTime.Now,
                    Comprobante = request.Comprobante,
                    Intento = TaskPagoPendiente.Intento + 1,
                    Reversado = response.Codigo == "00" || response.Codigo == "52" ? "SI" : "NO"
                };

                await _repositoryPagoEF.ActualizarEstadoReverso(reversoPendiente);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ReversoPagoTC - Pago aprobar error al actualizar el Comprobante: {0}", comprobante);
            }
        }
    }
}
