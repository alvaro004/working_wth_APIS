﻿using Continental.API.Core.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums.ListaBlanca;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Continental.API.Core.Interfaces;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands
{
    public class ListaBlancaCommand : IRequest { };
    public class ListaBlancaCommandHandler : IRequestHandler<ListaBlancaCommand>
    {
        private readonly ILogger<ListaBlancaCommandHandler> _logger;
        private readonly IRepositoryListaBlanca _repositoryLista;
        private readonly IConexionApiPago _conexionApi;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuraciones;
        public ListaBlancaCommandHandler(ILogger<ListaBlancaCommandHandler> logger,
                                 IRepositoryListaBlanca repositoryLista,
                                 IConexionApiPago conexionApi,
                                 IMemoryCache cache,
                                 IConfiguration configuraciones)
        {
            _logger = logger;
            _repositoryLista = repositoryLista;
            _conexionApi = conexionApi;
            _cache = cache;
            _configuraciones = configuraciones;
        }

        public async Task<Unit> Handle(ListaBlancaCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var timer = Stopwatch.StartNew();
                _logger.LogInformation("ServicioListaBlanca - Iniciando ListaBlancaAsync... - time: {0} ms", timer.Elapsed.TotalMilliseconds);
                var parametricaListaBlanca = await ObtenerParametricaLB();

                if (!parametricaListaBlanca.Switch)
                    throw new ApiException.ApiException("ServicioListaBlanca - El servicio actualmente se encuentra apagado.", 99);

                var listasPendientes = await ObtenerListaPendientes(parametricaListaBlanca);

                _logger.LogInformation("ServicioListaBlanca - Se encontraron {0} registros pendientes a transmitir. - time: {1} ms", listasPendientes.Count, timer.Elapsed.TotalMilliseconds);

                _logger.LogInformation("ServicioListaBlanca - Iniciamos proceso de envio de altas de lista blanca - time: {1} ms", timer.Elapsed.TotalMilliseconds);
                 await ProcesarAltaLista(listasPendientes, parametricaListaBlanca);
                _logger.LogInformation("ServicioListaBlanca - Finalizamos proceso de envio de de altas de lista blanca - time: {1} ms", timer.Elapsed.TotalMilliseconds);

                _logger.LogInformation("ServicioListaBlanca - Finalizando ListaBlancaAsync... - time: {1} ms", timer.Elapsed.TotalMilliseconds);

                return Unit.Value;
            }
            catch (ApiException.ApiException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        private async Task<List<DatosListaBlanca>> ObtenerListaPendientes(ParametricaListaBlanca parametrica)
        {
            var pagosPendientes = await _repositoryLista.ObtenerListaPendientes(parametrica);

            if (pagosPendientes.Count == 0)
                throw new ApiException.ApiException("ServicioListaBlanca - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar));

            return pagosPendientes;
        }

        private async Task ProcesarAltaLista(List<DatosListaBlanca> DatosAltaLista, ParametricaListaBlanca param)
        {
            var tasks = new List<Task>(); 
            int count = 0;
            int giro = 0;

            DatosAltaLista.ForEach(async item =>
            {
                giro++;
                // Crear un objeto ListaBlancaRequest
                var varRequest = new ListaBlancaUnitarioRequest
                {
                    BinAdquirente = item.BinAdquirente,
                    CodigoComercio = item.CodigoComercio,
                    Comercio = item.NombreComercio,
                    BinTarjeta = item.NumeroTarjeta.Substring(0, 6),
                    UltimosCuatroTarjeta = item.NumeroTarjeta.Substring(12, 4),
                    NumeroDocumento = await ObtenerNumeroDocumentoAsync(item.NumeroTarjeta),
                    Usuario = item.Usuario,
                    FechaInicio = item.FechaInicio.ToString(),
                    FechaFin = item.FechaFin.ToString(),
                    TipoMarca = item.TipoMarca,
                    IdOp = item.Id
                };
                tasks.Add(Task.Run(() => ActualizarEstadoLista(varRequest, param)));
                count++;
                if (count == param.Hilos)
                {
                    try
                    {
                        //Esperamos que se ejecuten todas las tareas.
                        await Task.WhenAll(tasks);
                    }
                    catch (AggregateException ae)
                    {
                        foreach (var ex in ae.Flatten().InnerExceptions)
                            _logger.LogError(ex, "ServicioListaBlanca - Ocurrio una excepcion al enviar la peticion de alta de lista");
                    }
                    count = 0;
                    tasks = new List<Task>();
                }
            });

            if (tasks.Count > 0)
                await Task.WhenAll(tasks);
            _logger.LogInformation($"ServicioListaBlanca - total de operaciones canceladas: {giro}.");
        }
        private async Task<AltaListaBlancaResponse> TransmitirAltasListaBlanca(ListaBlancaUnitarioRequest RequestLista)
        {
            try
            {
                var procesarAltaListaB = new HttpResponseMessage();

                Dictionary<string, string> headers = new Dictionary<string, string>()
                {
                    { "Authorization", "Bearer " + await ObtenerTokenCache()
                    }
                };

                _logger.LogInformation("ServicioListaBlanca - Inicamos el envio de Alta...");

                if (RequestLista.TipoMarca == EnumTipoMarca.Todos)
                {
                    var requestTodo = new ListaBlancaTodoRequest
                    {
                        BinTarjeta = RequestLista.BinTarjeta,
                        UltimosCuatroTarjeta = RequestLista.UltimosCuatroTarjeta,
                        NumeroDocumento = RequestLista.NumeroDocumento,
                        Usuario = RequestLista.Usuario,
                        FechaInicio = DateTime.Parse(RequestLista.FechaInicio).ToString("yyyyMMdd"),
                        FechaFin = DateTime.Parse(RequestLista.FechaFin).ToString("yyyyMMdd")
                    };


                    procesarAltaListaB = await _conexionApi.InvocarServicios(EnumUrl.ServicioListaBlanca,
                                                                          EnumMethods.Default,
                                                                          requestTodo,
                                                                          HttpMethod.Post,
                                                                          headers);
                    _logger.LogInformation("ServicioListaBlanca - Request enviado requestV2: {0}", JsonConvert.SerializeObject(requestTodo));
                }
                else
                {
                    RequestLista.FechaInicio = DateTime.Parse(RequestLista.FechaInicio).ToString("yyyyMMdd");
                    RequestLista.FechaFin = DateTime.Parse(RequestLista.FechaFin).ToString("yyyyMMdd");


                    procesarAltaListaB = await _conexionApi.InvocarServicios(EnumUrl.ServicioListaBlanca,
                                                                           EnumMethods.Default,
                                                                           RequestLista,
                                                                           HttpMethod.Post,
                                                                           headers);
                    _logger.LogInformation("ServicioListaBlanca - Request enviado RequestLista: {0}", JsonConvert.SerializeObject(RequestLista));
                }

                var jsonString = await procesarAltaListaB.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioListaBlanca - La api de alta de lista blanca respondio con el statuscode: {1}", (object)procesarAltaListaB.StatusCode);
                if (procesarAltaListaB.IsSuccessStatusCode)
                {
                    _logger.LogInformation("ServicioListaBlanca - Ok el alta lista blanca, respuesta obtenida: {0}", jsonString);
                    return JsonConvert.DeserializeObject<AltaListaBlancaResponse>(jsonString);
                }
                else
                {
                    _logger.LogError("ServicioListaBlanca - Error al procesar el alta lista blanca, respuesta obtenida: {0}", jsonString);
                    return JsonConvert.DeserializeObject<AltaListaBlancaResponse>(jsonString);
                }
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ServicioListaBlanca - Error en la solicitud HTTP en el alta lista blanca");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ServicioListaBlanca - Tiempo de espera de la solicitud agotado en el alta lista blanca");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioListaBlanca - Ocurrio un error al invocar el servicio de alta lista blanca");
                throw;
            }
        }
        private async Task<string> ObtenerTokenCache()
        {
            return await _cache.GetOrCreateAsync("TOKENAUTENTICACION", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
                p.Priority = CacheItemPriority.Normal;
                var valor = await ObtenerToken();
                return valor;
            });
        }
        //Generamos el token de autenticacion
        private async Task<string> ObtenerToken()
        {
            try
            {
                var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key == EnumUrl.AutenticacionPago.ToString().ToUpper());
                var requestToken = new TokenRequest { Usuario = credenciales.Usuario, Password = credenciales.Clave };

                _logger.LogInformation("ServicioListaBlanca - Iniciamos la consulta de token");

                var consultaToken = await _conexionApi.InvocarServicios(EnumUrl.AutenticacionPago,
                                                                            EnumMethods.Default,
                                                                            requestToken,
                                                                            HttpMethod.Post,
                                                                            null);
                var jsonString = await consultaToken.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioListaBlanca - La api de consulta de token respondio con el statuscode: {1}", consultaToken.StatusCode);

                if (consultaToken.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<TokenResponse>(jsonString);

                    return response.AccessToken;
                }
                else
                {
                    _logger.LogError("ServicioListaBlanca - Error al generar el token, respuesta obtenida: {0}", jsonString);
                    throw new ApiException.ApiException($"ServicioListaBlanca - No se pudo obtener el token.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ServicioListaBlanca - Error en la solicitud HTTP para el token");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ServicioListaBlanca - Tiempo de espera de la solicitud agotado para el token");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ServicioListaBlanca - Ocurrio un error al invocar el servicio de generar token");
                throw;
            }
        }

        private async Task ActualizarEstadoLista(ListaBlancaUnitarioRequest request, ParametricaListaBlanca parametro)
        {
            try
            {
                var listaPendiente = new DatosListaBlanca();
                var response = await TransmitirAltasListaBlanca(request);
                _logger.LogInformation("ServicioListaBlanca - Alta de lista procesado, UltimoCuatroTarjeta: {0}", request.UltimosCuatroTarjeta);

                var TaskListaPendiente = await _repositoryLista.ObtenerOperacionPendiente(request.IdOp);

                listaPendiente.estado = response.Codigo == "00" || response.Codigo == "31" ? (int)EnumEstadoListaBlanca.Procesado
                : response.Codigo != "00" && TaskListaPendiente.Intentos + 1 < parametro.Intento ? parametro.Estado : (int)EnumEstadoListaBlanca.Cancelado;
                listaPendiente.CodigoRetorno = response.Codigo;
                listaPendiente.MensajeRetorno = response.Mensaje;
                listaPendiente.FechaModificacion = DateTime.Now;
                listaPendiente.Id = request.IdOp;
                listaPendiente.IdTarjeta = response.IdTarjeta;
                listaPendiente.Intentos = TaskListaPendiente.Intentos + 1;

                await _repositoryLista.ActualizaEstadoListaBlanca(listaPendiente);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioListaBlanca - Alta de lista error al actualizar el id: {0}", request.IdOp);
            }
        }

        private async Task<ParametricaListaBlanca> ObtenerParametricaLB()
        {
            var dtParametroFecha = await _repositoryLista.ObtenerParametrica((decimal)EnumParametrica.ParametricaLB, (decimal)EnumParametrica.SecuenciaParamLB);
            return JsonConvert.DeserializeObject<ParametricaListaBlanca>(dtParametroFecha.Valor);
        }

        // Crear un método o función que maneje la lógica de obtención del número de documento
        private async Task<string> ObtenerNumeroDocumentoAsync(string numeroTarjeta)
        {
            var resultado = await _repositoryLista.ObtenerNumeroDocumento(numeroTarjeta[..15], numeroTarjeta.Substring(15, 1));
            return resultado?.TrimStart('0') ?? (await _repositoryLista.ObtenerNroDocumentoTd(numeroTarjeta)).TrimStart('0');
        }
    }
}
