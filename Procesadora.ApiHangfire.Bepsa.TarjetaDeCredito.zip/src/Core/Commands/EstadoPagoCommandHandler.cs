﻿using Continental.API.Core.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands
{
    public class EstadoPagoCommand : IRequest
    {
        public IEnumerable<string> Comprobantes { get; }

        public EstadoPagoCommand(IEnumerable<string> comprobantes) => Comprobantes = comprobantes;
    }
    
    public class EstadoPagoCommandHandler : IRequestHandler<EstadoPagoCommand>
    {
        private readonly ILogger<EstadoPagoCommandHandler> _logger;
        private readonly IRepositoryPagoDapper _repositoryPagoDapper;
        private readonly IRepositoryPagoEF _repositoryPagoEF;
        private readonly IConexionApiPago _conexionApiPago;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuraciones;

        public EstadoPagoCommandHandler(ILogger<EstadoPagoCommandHandler> logger,
                                          IRepositoryPagoDapper repositoryPagoDapper,
                                          IRepositoryPagoEF repositoryPagoEF,
                                          IConexionApiPago conexionApiPago,
                                          IMemoryCache cache,
                                          IConfiguration configuraciones)
        {
            _logger = logger;
            _repositoryPagoDapper = repositoryPagoDapper;
            _repositoryPagoEF = repositoryPagoEF;
            _conexionApiPago = conexionApiPago;
            _cache = cache;
            _configuraciones = configuraciones;
        }

        public async Task<Unit> Handle(EstadoPagoCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var timer = System.Diagnostics.Stopwatch.StartNew();
                _logger.LogInformation("ServicioEstadoPagoTC - Iniciando ConsultaEstadoPagosTarjetaAsync... - time: {0} ms", timer.Elapsed.TotalMilliseconds);
                var parametrica = await ObtenerParametricaServiceCode<ParametricaPagoRechazado>((int)EnumParametrica.ParametricaPago, (int)EnumParametrica.SecuenciaConsultaEstado);
                var paramtroCancelados = await ObtenerParametricaServiceCode<ParametroPagosCancelado>((int)EnumParametrica.ParametricaPago, (int)EnumParametrica.SecuenciaRechazo);

                var listaPagos = request.Comprobantes;

                var tasks = new List<Task>();
                int count = 0;
                int giro = 0;

                _logger.LogInformation("ServicioEstadoPagoTC - Cantidad de estados de pagos a actualizar: {0} - time: {1} ms.", listaPagos.Count(), timer.Elapsed.TotalMilliseconds);
                foreach (var comprobante in listaPagos)
                {
                    giro++;
                    tasks.Add(Task.Run(() => ConsultaEstado(decimal.Parse(comprobante), paramtroCancelados), cancellationToken));
                    count++;
                    if (count == parametrica.Hilos)
                    {
                        try
                        {
                            //Esperamos que se ejecuten todas las tareas.
                            await Task.WhenAll(tasks);
                        }
                        catch (AggregateException ae)
                        {
                            foreach (var ex in ae.Flatten().InnerExceptions)
                                _logger.LogError(ex, "ServicioEstadoPagoTC - Ocurrio una excepcion al consultar estados de pagos");
                        }
                        count = 0;
                        tasks = new List<Task>();
                    }
                }

                _logger.LogInformation($"ServicioEstadoPagoTC - total de operaciones: {giro}.");

                if (tasks.Count > 0)
                    await Task.WhenAll(tasks);
                timer.Stop();
                _logger.LogInformation("ServicioEstadoPagoTC - Finalizado ConsultaEstadoPagosTarjetaAsync... - time: {0} ms", timer.Elapsed.TotalMilliseconds);

                return Unit.Value;
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task<T> ObtenerParametricaServiceCode<T>(int id, int secuencia)
        {
            return await _cache.GetOrCreateAsync(id + secuencia, async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddHours(12);
                p.Priority = CacheItemPriority.Normal;
                var valor = await _repositoryPagoEF.ObtenerParametrica(id, secuencia);
                return JsonConvert.DeserializeObject<T>(valor.Valor);
            });
        }

        private async Task<string> ObtenerTokenCache()
        {
            return await _cache.GetOrCreateAsync("TOKENAUTENTICACION", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
                p.Priority = CacheItemPriority.Normal;
                var valor = await ObtenerToken();
                return valor;
            });
        }

        //Generamos el token de autenticacion
        private async Task<string> ObtenerToken()
        {
            try
            {
                var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key == EnumUrl.AutenticacionPago.ToString().ToUpper());
                var requestToken = new TokenRequest { Usuario = credenciales.Usuario, Password = credenciales.Clave };

                _logger.LogInformation("ServicioEstadoPagoTC - Iniciamos la consulta de token");

                var consultaToken = await _conexionApiPago.InvocarServicios(EnumUrl.AutenticacionPago,
                                                                            EnumMethods.Default,
                                                                            requestToken,
                                                                            HttpMethod.Post,
                                                                            null);
                var jsonString = await consultaToken.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioEstadoPagoTC - La api de consulta de token respondio con el statuscode: {1}", consultaToken.StatusCode);

                if (consultaToken.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<TokenResponse>(jsonString);

                    return response.AccessToken;
                }
                else
                {
                    _logger.LogError("ServicioEstadoPagoTC - Error al generar el token, respuesta obtenida: {0}", jsonString);
                    throw new ApiException.ApiException($"ServicioEstadoPagoTC - No se pudo obtener el token.", 99);
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ServicioEstadoPagoTC - Error en la solicitud HTTP para el token");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ServicioEstadoPagoTC - Tiempo de espera de la solicitud agotado para el token");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ServicioEstadoPagoTC - Ocurrio un error al invocar el servicio de generar token");
                throw;
            }
        }

        private async Task<Entities.Fechus> Fechus()
        {
            return await _cache.GetOrCreateAsync("FECHUS", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(1);
                p.Priority = CacheItemPriority.Normal;
                return await _repositoryPagoDapper.Fechus();
            });
        }

        private async Task ProcesarEstadoPagado(decimal comprobante, string motivo)
        {
            try
            {
                _logger.LogInformation("ServicioPagoTC - Pago aprobado, Comprobante: {0}", comprobante);
                var TaskPagoPendiente = _repositoryPagoDapper.ObtenerPago(comprobante);
                var TaskFechus = Fechus();
                await Task.WhenAll(TaskPagoPendiente, TaskFechus);
                var pagoPendiente = TaskPagoPendiente.Result; var fechus = TaskFechus.Result;

                pagoPendiente.EstadoPago = (int)EnumEstadoPago.Pagado;
                pagoPendiente.PagoProcesado = ConstanteDefault.PagoProcesado;
                pagoPendiente.Intento++;
                pagoPendiente.FechaDisponible = fechus.Fecha.ToString("yyyyMMdd");
                pagoPendiente.FechaExtracto = fechus.Fecha.ToString("yyyyMMdd");
                pagoPendiente.FechaPago = fechus.Fecha;
                pagoPendiente.CodigoResuesta = ConstanteDefault.CodigoRespuestaOk;
                pagoPendiente.MensajeRespuesta = motivo;
                pagoPendiente.FechaModificacion = DateTime.Now;

                var cajaDescEF = new CajaDescEF()
                {
                    Enviado = (int)EnumEstadoPago.Pagado,
                    FechaEnvio = fechus.Fecha,
                    HoraEnvio = DateTime.Now.ToString("HH:mm:ss"),
                    UsuarioEnvio = ConstanteDefault.UsuarioProceso,
                    UsuarioRegistro = pagoPendiente.UsuarioRegistro,
                    FechaRegistro = pagoPendiente.FechaRegistro,
                    Operacion = pagoPendiente.Tarjeta,
                    Comprobante = pagoPendiente.ComprobanteCajaDesc,
                    Recibo = pagoPendiente.Recibo,
                    Monto = pagoPendiente.Monto,
                    Efectivo = pagoPendiente.Monto
                };

                await Task.WhenAll(_repositoryPagoDapper.ActualizarEstadoPago(pagoPendiente), _repositoryPagoDapper.ActualizarCajaDesc(cajaDescEF));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioPagoTC - Pago aprobar error al actualizar el Comprobante: {0}", comprobante);
            }
        }

        private async Task ConsultaEstado(decimal comprobante, ParametroPagosCancelado parametricaCancelado)
        {
            try
            {

                Dictionary<string, string> headers = new Dictionary<string, string>
                {
                    { "Authorization", "Bearer " + await ObtenerTokenCache() }
                };

                _logger.LogInformation("ServicioEstadoPagoTC - Inicamos consulta de estado de pagos comprobante: {0}", comprobante);

                var procesarPago = await _conexionApiPago.InvocarServicios(EnumUrl.ServicioPago,
                                                                           EnumMethods.ConsultaPago,
                                                                           comprobante,
                                                                           HttpMethod.Get,
                                                                           headers);
                var jsonString = await procesarPago.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioEstadoPagoTC - La api de consulta estado de pago respondio con el statuscode: {0}", procesarPago.StatusCode);

                if (procesarPago.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<IEnumerable<EstadoPagoResponse>>(jsonString);

                    var ordenarLista = response.OrderByDescending(e => DateTime.Parse(e.FechaHoraProceso));
                    var ultimoEstado = ordenarLista.FirstOrDefault();

                    if (response.Any(e => e.Procesado == ConstanteDefault.ProcesadoCorrectamente))
                    {
                        await ProcesarEstadoPagado(comprobante, ultimoEstado.Motivo);
                    }
                    else
                    {
                        _logger.LogInformation("ServicioEstadoPagoTC - Pago rechazado comprobante: {0}", comprobante);
                        var pagoPendiente = await _repositoryPagoDapper.ObtenerPago(comprobante);

                        pagoPendiente.MensajeRespuesta = ultimoEstado.Motivo;
                        pagoPendiente.CodigoResuesta = ConstanteDefault.CodigoRespuestaError;
                        pagoPendiente.Intento++;
                        pagoPendiente.FechaModificacion = DateTime.Now;

                        //Verificamos si ya supero la cantidad de intentos a enviar.
                        if (pagoPendiente.Intento >= parametricaCancelado.CantidadIntento)
                        {
                            _logger.LogInformation("ServicioEstadoPagoTC - ya se supero la cantidad de intentos, pago cancelado, Comprobante: {0}", (object)comprobante);

                            //Preparamos el cuerpo del correo.
                            var body = parametricaCancelado.Body.Replace("v_id", pagoPendiente.Comprobante.ToString())
                                                                .Replace("v_comprobante", pagoPendiente.Comprobante.ToString())
                                                                .Replace("v_tarjeta", pagoPendiente.Tarjeta)
                                                                .Replace("v_monto", pagoPendiente.Monto.ToString())
                                                                .Replace("v_add_user", pagoPendiente.UsuarioRegistro)
                                                                .Replace("v_oper_sucur", "01")
                                                                .Replace("v_codigo", ConstanteDefault.CodigoRespuestaError)
                                                                .Replace("v_fecha", DateTime.Now.ToString())
                                                                .Replace("v_mensaje", ultimoEstado.Motivo);

                            //Enviamos el correo de alerta.
                            var taskCorreo = _repositoryPagoDapper.EnvioCorreo(parametricaCancelado.De,
                                                                               parametricaCancelado.EmailDestino,
                                                                               parametricaCancelado.Asunto,
                                                                               parametricaCancelado.EmailCopia,
                                                                               body,
                                                                               parametricaCancelado.EsHtml);

                            pagoPendiente.EstadoPago = (int)EnumEstadoPago.cancelado;
                            pagoPendiente.PagoProcesado = ConstanteDefault.PagoCancelado;
                            //Actualizamos el estado del pago a cancelado.
                            var taskEstadoPago = _repositoryPagoDapper.ActualizaEstadoPago(pagoPendiente);
                            await Task.WhenAll(taskCorreo, taskEstadoPago);
                        }
                        else
                        {
                            //Actualizamos el motivo de rechazo.
                            await _repositoryPagoDapper.ActualizaMotivoPago(pagoPendiente);
                        }
                    }

                    _logger.LogInformation("ServicioEstadoPagoTC - Se actualizo el estado del comprobante: {0} con el motivo: {1}", comprobante, ultimoEstado.Motivo);
                }
                else
                {
                    _logger.LogError("ServicioEstadoPagoTC - Error al consultar el estado del pago comprobante: {0}, respuesta obtenida: {1}", comprobante, jsonString);
                    throw new ApiException.ApiException($"ServicioEstadoPagoTC - No se pudo realizar la consulta del estado de pago.", 99);
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ServicioEstadoPagoTC - Error en la solicitud HTTP en la consulta de pago");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ServicioEstadoPagoTC - Tiempo de espera de la solicitud agotado en la consulta de pago");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ServicioEstadoPagoTC - Ocurrio un error al invocar el servicio de consulta de pagos");
                throw;
            }
        }
    }
}
