﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands
{
    public class TarjetaVirtualCommand : IRequest { };

    public class TarjetaVirtualCommandHandler : IRequestHandler<TarjetaVirtualCommand>
    {
        private readonly ILogger<TarjetaVirtualCommandHandler> _logger;
        private readonly IRepositoryTarjetaVirtualDapper _repositoryTarjetaVirtualDapper;
        private readonly IConexionApiTarjetaVirtual _conexionApiTarjetaVirtual;
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuraciones;
        private readonly IConexionApi _conexionApi;

        public TarjetaVirtualCommandHandler(ILogger<TarjetaVirtualCommandHandler> logger,
                                            IRepositoryTarjetaVirtualDapper repositoryTarjetaVirtualDapper,
                                            IConexionApiTarjetaVirtual conexionApiTarjetaVirtual,
                                            IMemoryCache cache,
                                            IConfiguration configuraciones,
                                            IConexionApi conexionApi)
        {
            _logger = logger;
            _repositoryTarjetaVirtualDapper = repositoryTarjetaVirtualDapper;
            _conexionApiTarjetaVirtual = conexionApiTarjetaVirtual;
            _cache = cache;
            _configuraciones = configuraciones;
            _conexionApi = conexionApi;
        }

        private async Task<List<TarjetaVirtualPendiente>> ObtenerTarjetaPendientes()
        {
            var tarjetasPendientes = await _repositoryTarjetaVirtualDapper.TarjetaVirtualPendiente();

            if (tarjetasPendientes is null || tarjetasPendientes.Count == 0)
                throw new ApiException.ApiException("ServicioTarjetaVirtual - No existe registros que procesar.",
                    Convert.ToInt32(RespuestaBepsa.NoExisteRegistrosAProcesar));

            return tarjetasPendientes;
        }

        //Generamos el token de autenticacion
        private async Task<string> ObtenerToken()
        {
            try
            {
                var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key == EnumUrl.AutenticacionPago.ToString().ToUpper());
                var requestToken = new TokenRequest { Usuario = credenciales.Usuario, Password = credenciales.Clave };

                _logger.LogInformation("ServicioTarjetaVirtual - Iniciamos la consulta de token");

                var consultaToken = await _conexionApiTarjetaVirtual.InvocarServicios(EnumUrl.AutenticacionPago,
                                                                            EnumMethods.Default,
                                                                            requestToken,
                                                                            HttpMethod.Post,
                                                                            null);
                var jsonString = await consultaToken.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioTarjetaVirtual - La api de consulta de token respondio con el statuscode: {1}", consultaToken.StatusCode);

                if (consultaToken.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<TokenResponse>(jsonString);

                    return response.AccessToken;
                }
                else
                {
                    _logger.LogError("ServicioTarjetaVirtual - Error al generar el token, respuesta obtenida: {0}", jsonString);
                    throw new ApiException.ApiException($"ServicioTarjetaVirtual - No se pudo obtener el token.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                //Manejar errores variantes
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                // Manejar errores relacionados con la solicitud HTTP (p. ej., problemas de red)
                _logger.LogError(ex, "ServicioTarjetaVirtual - Error en la solicitud HTTP para el token");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                // Manejar errores de tiempo de espera de la solicitud
                _logger.LogError(ex, "ServicioTarjetaVirtual - Tiempo de espera de la solicitud agotado para el token");
                throw;
            }
            catch (Exception ex)
            {
                // Manejar otras excepciones no relacionadas con HTTP
                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error al invocar el servicio de generar token");
                throw;
            }
        }

        private async Task<string> ObtenerTokenCache()
        {
            return await _cache.GetOrCreateAsync("TOKENAUTENTICACION", async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddMinutes(10);
                p.Priority = CacheItemPriority.Normal;
                var valor = await ObtenerToken();
                return valor;
            });
        }

        private async Task<bool> EstadoAlta(TarjetaVirtualPendiente tarjetaVirutalPendiente)
        {
            try
            {
                var apiKey = _configuraciones.GetSection("ApiKeyConsultaEstado").Get<string>();

                Dictionary<string, string> headers = new Dictionary<string, string>()
                {
                    { "Authorization", "Bearer " + await ObtenerTokenCache() },
                    { "apiKey", apiKey }
                };

                var estadoRequest = new ConsultaEstadoAltaRequest {
                    IdSession = tarjetaVirutalPendiente.IdSesionTarjeta,
                    Tarjeta = tarjetaVirutalPendiente.Tarjeta };

                var consultarEstado = await _conexionApiTarjetaVirtual.InvocarGetConBody(EnumUrl.ConsultaEstadoAlta,
                                                                                         EnumMethods.ConsultaEstado,
                                                                                         estadoRequest,
                                                                                         headers);
                var jsonString = await consultarEstado.Content.ReadAsStringAsync();

                _logger.LogInformation("ServicioTarjetaVirtual - La api de consulta de estado de alta de la tarjeta, cuenta: {0} respondio con el statuscode: {1}", tarjetaVirutalPendiente.Cuenta, (object)consultarEstado.StatusCode);

                if (consultarEstado.IsSuccessStatusCode)
                {
                    _logger.LogInformation("ServicioTarjetaVirtual - El alta de la cuenta/tarjeta se encuentra correctamente: {0}", tarjetaVirutalPendiente.Cuenta);
                    return true;
                }
                else
                {
                    _logger.LogError("ServicioTarjetaVirtual - Error al consultar el estado de la cuenta {0}," +
                        " respuesta obtenida: {1}", tarjetaVirutalPendiente.Cuenta, jsonString);
                    throw new ApiException.ApiException("ServicioTarjetaVirtual - No se pudo consultar el estado de la cuenta.",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Error en la solicitud HTTP en la consulta de estado de alta");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Tiempo de espera de la consulta de estado de alta");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error al invocar el servicio de consulta de estado");
                throw;
            }
        }

        private async Task VerificaEstadoAlta(TarjetaVirtualPendiente tarjetaVirutalPendiente)
        {
            try
            {
                _logger.LogInformation("ServicioTarjetaVirtual - Inicamos consulta de estado de alta...");

                var estadoTarjeta = await EstadoAlta(tarjetaVirutalPendiente);

                if (!estadoTarjeta)
                    throw new ApiException.ApiException($"ServicioTarjetaVirtual - hubo inconvenientes con el alta de la Tarjeta: {JsonConvert.SerializeObject(estadoTarjeta)}",
                        Convert.ToInt32(RespuestaBepsa.Error));
            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private async Task Activaciontarjeta(TarjetaVirtualPendiente tarjetaVirutalPendiente)
        {
            _logger.LogInformation("ServicioTarjetaVirtual - Inicamos la activacion de la cuenta/tarjeta...");

            var requestCuenta = new RequestConexionServicioActivacion();
            var requestTarjeta = new RequestConexionServicioActivacionTarjeta();
            var credenciales = _configuraciones.GetSection("Configuraciones:CredencialesToken").Get<CredencialesToken>().Credenciales
                        .FirstOrDefault(e => e.Key.ToUpper() == EnumUrl.Servicio.ToString().ToUpper());

            //Armamos el request de la cuenta
            requestCuenta.Usuario = credenciales.UsuarioActivacion;
            requestCuenta.Clave = credenciales.ClaveActivacion;
            requestCuenta.Lote = new List<CuentaTarjeta>();
            var cuentaTarjeta = new CuentaTarjeta
            {
                Cuenta = Int64.Parse(tarjetaVirutalPendiente.Cuenta),
                EstadoNuevo = ConstanteDefault.Activar,
                Observacion = ConstanteDefault.ObservacionActivacion,
                Usuario = ConstanteDefault.UsuarioProceso,
                MotivoBaja = 0
            };
            requestCuenta.Lote.Add(cuentaTarjeta);

            await ActivarCuenta(requestCuenta);

            //Armamos el request de la tarjeta
            requestTarjeta.Usuario = credenciales.UsuarioActivacion;
            requestTarjeta.Clave = credenciales.ClaveActivacion;
            requestTarjeta.Lote = new List<DatosTarjeta>();
            var tarjeta = new DatosTarjeta
            {
                Tarjeta = tarjetaVirutalPendiente.Tarjeta,
                EstadoNuevo = ConstanteDefault.Activar,
                Observacion = ConstanteDefault.ObservacionActivacion,
                Usuario = ConstanteDefault.UsuarioProceso,
                MotivoBaja = 0,
                Costo = "S",
                AfectaRelacionadaCombo = "N"
            };
            requestTarjeta.Lote.Add(tarjeta);

            await ActivarTarjeta(requestTarjeta);

        }

        private async Task ActivarTarjeta(RequestConexionServicioActivacionTarjeta activacionRequest)
        {
            try
            {
                _logger.LogInformation("ServicioTarjetaVirtual - Iniciamos la activacion de la tarjeta: {1}", activacionRequest.Lote.FirstOrDefault().Tarjeta);

                var activarTarjeta = await _conexionApiTarjetaVirtual.InvocarServicios(EnumUrl.ActivacionTarjeta,
                                                                                       EnumMethods.Default,
                                                                                       activacionRequest,
                                                                                       HttpMethod.Post,
                                                                                       null);
                var jsonString = await activarTarjeta.Content.ReadAsStringAsync();

                _logger.LogInformation($"ServicioTarjetaVirtual - La api de activacion respondio para la tarjeta: {activacionRequest.Lote.FirstOrDefault().Tarjeta}" +
                    $" con el statuscode: {(object)activarTarjeta.StatusCode}");

                if (activarTarjeta.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<CuentaActivacionResponse>(jsonString);

                    if (!response.Lote.FirstOrDefault().Codigo.Equals(CodigosRespuesta.Procesado) && !response.Lote.FirstOrDefault().Codigo.Equals(CodigosRespuesta.CuentaYaActiva))
                        throw new ApiException.ApiException($"ServicioTarjetaVirtual - Error al activar la tarjeta, respuesta obtenida: {jsonString}",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
                else
                    throw new ApiException.ApiException($"ServicioTarjetaVirtual - Error al activar la tarjeta, respuesta obtenida: {jsonString}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Error en la solicitud HTTP de la activacion de la tarjeta");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Tiempo de espera de la activacion de la tarjeta");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error al activar de la tarjeta");
                throw;
            }
        }

        private async Task ActivarCuenta(RequestConexionServicioActivacion activacionRequest)
        {
            try
            {
                _logger.LogInformation("ServicioTarjetaVirtual - Iniciamos la activacion de la cuenta: {1}", activacionRequest.Lote.FirstOrDefault().Cuenta);
                var activarTarjeta = await _conexionApiTarjetaVirtual.InvocarServicios(EnumUrl.ActivacionCuenta,
                                                                                       EnumMethods.Default,
                                                                                       activacionRequest,
                                                                                       HttpMethod.Post,
                                                                                       null);
                var jsonString = await activarTarjeta.Content.ReadAsStringAsync();

                _logger.LogInformation($"ServicioTarjetaVirtual - La api de activacion respondio para la cuenta: {activacionRequest.Lote.FirstOrDefault().Cuenta}" +
                    $" con el statuscode: {(object)activarTarjeta.StatusCode}");

                if (activarTarjeta.IsSuccessStatusCode)
                {
                    var response = JsonConvert.DeserializeObject<CuentaActivacionResponse>(jsonString);

                    if (!response.Lote.FirstOrDefault().Codigo.Equals(CodigosRespuesta.Procesado) && !response.Lote.FirstOrDefault().Codigo.Equals(CodigosRespuesta.CuentaYaActiva))
                        throw new ApiException.ApiException($"ServicioTarjetaVirtual - Error al activar la cuenta, respuesta obtenida: {jsonString}",
                        Convert.ToInt32(RespuestaBepsa.Error));
                }
                else
                    throw new ApiException.ApiException($"ServicioTarjetaVirtual - Error al activar la cuenta, respuesta obtenida: {jsonString}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            }
            catch (ApiException.ApiException ex)
            {
                throw ex;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Error en la solicitud HTTP de la activacion de la cuenta");
                throw;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Tiempo de espera de la activacion de la cuenta");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error al activar de la cuenta");
                throw;
            }
        }

        private async Task<string> GrabarContarje(TarjetaVirtualPendiente tarjetaVirutal)
        {
            _logger.LogInformation("ServicioTarjetaVirtual - Iniciamos la insercion en contarje de la cuenta: {0}", tarjetaVirutal.Cuenta);

            if (await _repositoryTarjetaVirtualDapper.VerificaContarje(tarjetaVirutal.Tarjeta))
                throw new ApiException.ApiException($"ServicioTarjetaVirtual - Ya existe el registro en contarje, cuenta: {tarjetaVirutal.Cuenta}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            var datosTarjeta = await _repositoryTarjetaVirtualDapper.DatosParaContarje(tarjetaVirutal.Tarjeta, tarjetaVirutal.Cuenta);

            if (datosTarjeta is null)
                throw new ApiException.ApiException($"ServicioTarjetaVirtual - No se pudo obtener los datos para contarje, cuenta: {tarjetaVirutal.Cuenta}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            await _repositoryTarjetaVirtualDapper.GrabarContarje(datosTarjeta);
            _logger.LogInformation("ServicioTarjetaVirtual - Finalizamos la insercion en contarje de la cuenta: {0}", tarjetaVirutal.Cuenta);

            return datosTarjeta.CodigoCliente;

        }

        private async Task<PbTarjeta> GrabarPbTarjeta(TarjetaVirtualPendiente tarjetaVirutal)
        {
            _logger.LogInformation("ServicioTarjetaVirtual - Iniciamos la insercion en pbTarjeta de la cuenta: {0}", tarjetaVirutal.Cuenta);

            if (await _repositoryTarjetaVirtualDapper.VerificaPbTarjeta(tarjetaVirutal.Tarjeta))
                throw new ApiException.ApiException($"ServicioTarjetaVirtual - Ya existe el registro en pbTarjeta, cuenta: {tarjetaVirutal.Cuenta}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            var datoPbTarjeta = await _repositoryTarjetaVirtualDapper.DatosParaPbTarjeta(tarjetaVirutal.Tarjeta, tarjetaVirutal.Cuenta);

            if (datoPbTarjeta is null)
                throw new ApiException.ApiException($"ServicioTarjetaVirtual - No se pudo obtener los datos para pbTarjeta, cuenta: {tarjetaVirutal.Cuenta}",
                        Convert.ToInt32(RespuestaBepsa.Error));

            var datoPersona = await _repositoryTarjetaVirtualDapper.DatosPersona(datoPbTarjeta.CodigoCliente);
            var parametricaMarcaTarjeta = JsonConvert.DeserializeObject<List<MarcaTarjeta>>(await _repositoryTarjetaVirtualDapper.ObtenerParametrica(121, 2));
            var datoMarcaTarjeta = parametricaMarcaTarjeta.FirstOrDefault(marca => marca.IdAfinidad == datoPbTarjeta.Afinidad);

            datoPbTarjeta.IdPersona = datoPersona.IdPersona;
            datoPbTarjeta.Documento = datoPersona.Documento;
            datoPbTarjeta.IdTipoDocumento = datoPersona.IdTipoDocumento;
            datoPbTarjeta.Marca = datoMarcaTarjeta?.Marca;
            datoPbTarjeta.CodigoProducto = datoMarcaTarjeta?.Producto;

            await _repositoryTarjetaVirtualDapper.GrabarPbtarjeta(datoPbTarjeta);

            _logger.LogInformation("ServicioTarjetaVirtual - Finalizamos la insercion en pbTarjeta de la cuenta: {0}", tarjetaVirutal.Cuenta);

            return datoPbTarjeta;
        }

        private async Task EnvioPush(string cuenta, string codigoCliente, string mensajePush)
        {
            await _repositoryTarjetaVirtualDapper.EnvioPush(codigoCliente, ConstanteDefault.TipoTransaccionPush, mensajePush);
            _logger.LogInformation("ServicioTarjetaVirtual - Se envio correctamente la notificacion push a la cuenta: {0}", cuenta);
        }

        private async Task AltaTarjetaVirtual(TarjetaVirtualPendiente tarjeta, string mensajePush)
        {
            try
            {
                //Verificamos que ya este Ok el alta de la cuenta/tarjeta
                await VerificaEstadoAlta(tarjeta);

                //Realizamos la activacion de la cuenta/tarjeta
                await Activaciontarjeta(tarjeta);

                //Damos de alta la tarjeta en contarje
                var codigoCliente = await GrabarContarje(tarjeta);

                //Damos de alta la tarjeta en pbTarjeta
                var datosTarjeta = await GrabarPbTarjeta(tarjeta);

                //Notificamos con un push al cliente
                _ = EnvioPush(tarjeta.Cuenta, codigoCliente, mensajePush);

                // Si es una tarjeta hibrida 
                if (await EsTarjetaDigitalHibrida(tarjeta.Tarjeta))
                {
                    _logger.LogInformation("ServicioTarjetaVirtual - La tarjeta es una tarjeta digital hibrida. Cuenta: {@cuenta}", tarjeta.Cuenta);
                    var parametrica = JsonConvert.DeserializeObject<ParametricaSwitch>(await _repositoryTarjetaVirtualDapper.ObtenerParametrica(16572, 1));

                    if (parametrica.Switch)
                        throw new ApiException.ApiException($"ServicioTarjetaVirtual - Servicio de emision de Tarjeta Digital Hibrida apagada temporalmente",
                            Convert.ToInt32(RespuestaBepsa.Error));

                    var parametricaRegrabacion = await ObtenerDatosRegrabacionParametrica();
                    var regrabacion = PrepararRegrabacion(codigoCliente, datosTarjeta, parametricaRegrabacion);
                    var resultado = await _conexionApi.ConexionReimpresion(regrabacion, KeyToken.SERVICIO);
                    var respuestaBepsa = resultado.Lote[0];

                    if (!respuestaBepsa.CodigoRespuesta.Equals(RespuestaBepsa.Aprobada))
                        throw new ApiException.ApiException($"ServicioTarjetaVirtual - Error al regrabar la tarjeta, respuesta obtenida de Bepsa: {resultado.Lote[0].Descripcion}",
                                                       Convert.ToInt32(RespuestaBepsa.Error));

                    _logger.LogInformation("ServicioTarjetaVirtual - Respuesta Bepsa OK. Respuesta: {@descripcion} Cuenta: {@cuenta}", respuestaBepsa.Descripcion, tarjeta.Cuenta);
                    var lote = regrabacion.Lote.FirstOrDefault();
                    var reimpresion = await CrearReimpresion(lote, parametricaRegrabacion);
                    _ = InsertarReImpresion(reimpresion, tarjeta.Cuenta);
                }
            }
            catch (ApiException.ApiException ex)
            {
                _logger.LogError(ex.Mensaje);
            }
            catch (Exception ee)
            {
                _logger.LogError(ee, "ServicioTarjetaVirtual - Error al procesar la cuenta: {0}", tarjeta.Cuenta);
            }
        }

        private async Task<DatosRegrabacion> ObtenerDatosRegrabacionParametrica()
        {
            const int idParametrica = 16572;
            const int secuencia = 2;
            return JsonConvert.DeserializeObject<DatosRegrabacion>(await ObtenerParametricas(idParametrica, secuencia));
        }
        private static RequestReimpresion PrepararRegrabacion(string codigoCliente, PbTarjeta pbTarjeta, DatosRegrabacion regrabacion)
        {
            regrabacion.CodigoCliente = codigoCliente;
            regrabacion.Tarjeta = pbTarjeta.Tarjeta + pbTarjeta.Digito;
            regrabacion.Vencido = pbTarjeta.ValeHasta;
            return CrearReGrabacion(regrabacion);
        }

        private static RequestReimpresion CrearReGrabacion(DatosRegrabacion datosRegrabacion)
        {
            return new RequestReimpresion
            {
                Lote = new List<LoteReimpresion>
                {
                    new LoteReimpresion
                    {
                        CodigoCliente = datosRegrabacion.CodigoCliente,
                        Tarjeta = datosRegrabacion.Tarjeta,
                        TarjetaNueva = datosRegrabacion.NuevaTarjetaCombo,
                        Novedad = datosRegrabacion.Novedad,
                        Motivo = datosRegrabacion.Motivo,
                        FechaVencimiento = ObtenerFechaVencimiento(datosRegrabacion.Vencido), 
                        Cobrar = datosRegrabacion.Cobrar,
                        Importe = datosRegrabacion.Importe,
                        TipoPlastico = datosRegrabacion.TipoPlastico,
                        NuevaTarjetaCombo = datosRegrabacion.NuevaTarjetaCombo,
                    }
                }
            };
        }

        private static string ObtenerFechaVencimiento(string fechaVencimiento)
        {
            fechaVencimiento += "01";

            // Parsear, añadir un mes y convertir a string en formato "yyyyMM"
            return DateTime.ParseExact(fechaVencimiento, "yyyyMMdd", CultureInfo.InvariantCulture)
                            .AddMonths(1)
                            .ToString("yyyyMM");
        }

        private Task<Reimpresion> CrearReimpresion(LoteReimpresion loteReimpresion, DatosRegrabacion reimpresionParametrica)
        {
            return Task.FromResult(new Reimpresion
            {
                Tarjeta = loteReimpresion.Tarjeta,
                TarjetaNuevo = loteReimpresion.NuevaTarjetaCombo,
                CodigoCliente = loteReimpresion.CodigoCliente,
                Motivo = loteReimpresion.Motivo,
                Importe = loteReimpresion.Importe,
                Costo = reimpresionParametrica.Costo,
                Vencimiento = loteReimpresion.FechaVencimiento[..6],
                FechaValidacion = loteReimpresion.FechaVencimiento,
                UsuarioProceso = reimpresionParametrica.Usuario,
                MotivoTransferencia = loteReimpresion.Motivo.ToString(),
                Ald = reimpresionParametrica.Ald,
                Ofac = reimpresionParametrica.Ofac,
                Onu = reimpresionParametrica.Onu,
                Clasbcp = reimpresionParametrica.ClasBcp,
                Mora = reimpresionParametrica.Mora,
                TarjetaVencida = reimpresionParametrica.TarjetaVencido,
                TarjetaBloqueada = reimpresionParametrica.TarjetaBloqueada,
                Observacion = reimpresionParametrica.Observacion,
                UsuarioRegistro = reimpresionParametrica.Usuario,
                FechaRegistro = DateTime.Now,
                SucursalRegistro = reimpresionParametrica.Sucursal,
                UsuarioAutorizo = reimpresionParametrica.Usuario,
                FechaAutorizo = DateTime.Now,
                SucursalAutorizo = reimpresionParametrica.SucursalAutoriza,
                Estado = reimpresionParametrica.Estado,
                Procesadora = reimpresionParametrica.Procesadora,
                Biblioteca = reimpresionParametrica.Biblioteca,
                Enviar = reimpresionParametrica.Enviar,
                Procesado = reimpresionParametrica.Procesado
            });
        }

        private async Task InsertarReImpresion(Reimpresion lote, string cuenta)
        {
            try
            {
                _logger.LogInformation("ServicioTarjetaVirtual - Iniciando el servicio de insercion de la regrabación: {@cuenta}", cuenta);
                lote.Id = await _repositoryTarjetaVirtualDapper.ObtenerNuevoIdRegrabacion();    
                _logger.LogInformation("ServicioTarjetaVirtual - Insertando regrabacion en la tabla reimpresion. 1/3. Cuenta: {@cuenta}", cuenta);
                await _repositoryTarjetaVirtualDapper.InsertarReGrabacionPrincipal(lote);
                _logger.LogInformation("ServicioTarjetaVirtual - Insertando regrabacion en la tabla logreimpresion. 2/3. Cuenta: {@cuenta}", cuenta);
                lote.LogKey = await _repositoryTarjetaVirtualDapper.ObtenerNuevoLogKey();
                lote.NumeroProceso = await _repositoryTarjetaVirtualDapper.ObtenerNumeroProceso();
                await _repositoryTarjetaVirtualDapper.InsertarReGrabacionPrincipalLog(lote);
                _logger.LogInformation("ServicioTarjetaVirtual - Insertando regrabacion en la tabla reimpresion_courier. 3/3. Cuenta: {@cuenta}", cuenta);
                await _repositoryTarjetaVirtualDapper.InsertarReGrabacionCourier(lote);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio un error al insertar la regrabacion");
                throw;
            }
        }

        public async Task<Unit> Handle(TarjetaVirtualCommand request, CancellationToken cancellationToken)
        {
            try
            {

                var parametrica = JsonConvert.DeserializeObject<ParametricaSwitch>(await _repositoryTarjetaVirtualDapper.ObtenerParametrica(121, 1));

                if (parametrica.Switch)
                    throw new ApiException.ApiException($"ServicioTarjetaVirtual - Alta de tarjeta Virtual Apagada temporalmente",
                        Convert.ToInt32(RespuestaBepsa.Error));

                var tarjetasPendientes = await ObtenerTarjetaPendientes();
                
                _logger.LogInformation($"ServicioTarjetaVirtual - Total de altas pendientes: {tarjetasPendientes.Count}");

                var tasks = new List<Task>();
                int count = 0;
                int giro = 0;

                foreach (var tarjeta in tarjetasPendientes)
                {
                    giro++;          
                    tasks.Add(Task.Run(() => AltaTarjetaVirtual(tarjeta, parametrica.MensajePush), cancellationToken));
                    count++;
                    if (count == parametrica.Hilo)
                    {
                        try
                        {
                            //Esperamos que se ejecuten todas las tareas.
                            await Task.WhenAll(tasks);
                        }
                        catch (AggregateException ae)
                        {
                            foreach (var ex in ae.Flatten().InnerExceptions)
                                _logger.LogError(ex, "ServicioTarjetaVirtual - Ocurrio una excepcion al dar de alta/cuenta virtual");
                        }
                        count = 0;
                        tasks = new List<Task>();
                    }
                }

                if (tasks.Count > 0)
                    await Task.WhenAll(tasks);
                _logger.LogInformation($"ServicioTarjetaVirtual - total de operaciones procesadas: {giro}.");

            }
            catch (Exception)
            {
                throw;
            }
            return Unit.Value;
        }

        private async Task<bool> EsTarjetaInternacional(string afinidad)
        {
            var esInternacional = await _repositoryTarjetaVirtualDapper.ValidarTarjetaInternacional(afinidad);
            return esInternacional.Equals(ConstanteDefault.MarcaInternacional);
        }

        private async Task<bool> EsTarjetaDigitalHibrida(string tarjeta)
        {
            var esTarjetaDigitalHibrida = await _repositoryTarjetaVirtualDapper.ValidarTarjetaDigitalHibrida(tarjeta);
            return esTarjetaDigitalHibrida;
        }

        public async Task<string> ObtenerParametricas(int idParametrica, int secuencia)
        {
            return await _cache.GetOrCreateAsync(idParametrica.ToString() + secuencia.ToString(), async p =>
            {
                p.AbsoluteExpiration = DateTime.Now.AddHours(10);
                p.Priority = CacheItemPriority.Normal;
                return await _repositoryTarjetaVirtualDapper.ObtenerParametrica(idParametrica, secuencia);
            });
        }

    }
}
