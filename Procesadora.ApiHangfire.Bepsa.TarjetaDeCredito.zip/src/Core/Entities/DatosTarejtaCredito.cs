﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosTarejtaCredito
    {
        public string Accion { get; set; }
        public string NroControl { get; set; }
        public string NroTarjeta { get; set; }
        public string NombreTarjeta { get; set; }
        public string CodigoAfinidad { get; set; }
        public string NroCuenta { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string TipoTarjeta { get; set; }
        public string NombrePlastico { get; set; }
        public string TipoPlastico { get; set; }
        public string Duracion { get; set; }
        public string SituacionTarjeta { get; set; }
        public string Renovar { get; set; }
        public string EmbozarPlastico { get; set; }
        public string Sucursal { get; set; }
        public string CampoReservado { get; set; }
        public string IdTipoDocPromotor { get; set; }
        public string NroDocPromotor { get; set; }
        public string OrdenEmbozado { get; set; }
        public string Usuario { get; set; }
        public int ExisteRegistro { get; set; }
        public List<DatosPersonas> DatosPersona { get; set; }
    }
}
