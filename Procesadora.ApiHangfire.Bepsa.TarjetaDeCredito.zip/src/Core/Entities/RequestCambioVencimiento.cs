﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class RequestCambioVencimiento
    {
        [JsonProperty("lote")]
        public List<LoteCambioVencimiento> Lote { get; set; }
    }

    public class LoteCambioVencimiento
    {
        [JsonIgnore]
        public int Id { get; set; }
        [JsonProperty("tipoUso")]
        public string TipoUso { get; set; }
        [JsonProperty("cuenta")]
        public string Cuenta { get; set; }
        [JsonProperty("adherente")]
        public string Adherente { get; set; }
        [JsonProperty("emision")]
        public string Emision { get; set; }
        [JsonProperty("estado")]
        public string Estado { get; set; }
        [JsonProperty("fechaEntrega")]
        public string FechaEntrega { get; set; }
        [JsonProperty("nroTarjeta")]
        public string Tarjeta { get; set; }
        [JsonProperty("observacion")]
        public string Observacion { get; set; }
        [JsonProperty("usuario")]
        public string Usuario { get; set;  }
    }
}
