﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class ResponseCambioVencimiento
    {
        [JsonProperty("codigoRetorno")]
        public string CodigoRetorno { get; set; }
        [JsonProperty("detalleRetorno")]
        public string DetalleRetorno { get; set; }
        [JsonProperty("idSeguimiento")]
        public string IdSeguimiento { get; set; }
        [JsonProperty("procesados")]

        public List<LoteCambioVencimientoResponse> Procesados { get; set; }
    }
}
