﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class EstadoTransmisionesResponse
    {
        [JsonProperty("codigo")]
        public string Codigo { get; set; }
        [JsonProperty("mensaje")]
        public string Mensaje { get; set; }
        [JsonProperty("errores")]
        public List<EstadoErroresResponse> Errores;
    }
}
