﻿using Continental.API.Core.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestConexionServicioCredito
    {
        public List<DatosPersonas> Personas { get; set; }
        public List<DatosCuentaCredito> Cuentas { get; set; }
        public List<DatosTarejtaCredito> Tarjetas { get; set; }

    }
}
