﻿namespace Continental.API.Core.Entities
{
    public class EstadoRegistrosPendientes
    {
        public float LogKey { get; set; }
        public float IdSesion { get; set; }
        public string NumeroTarjeta { get; set; }
        public string NumeroCuenta { get; set; }
        public string Documento { get; set; }
    }
}
