﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class DtParametrosFecha
    {
        public decimal Id { get; set; }
        public decimal Secuencia { get; set; }
        public string Valor { get; set; }
        public string Descripcion { get; set; }
        public string ValorDos { get; set; }
        public string ValorTres { get; set; }
        public string Tipo { get; set; }

    }
}
