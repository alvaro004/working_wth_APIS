﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class LoteTarjetaResponse
    {
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }
        [JsonProperty("codigoRespuesta")]
        public string CodigoRespuesta { get; set; }
        [JsonProperty("descripcion")]
        public string Descripcion { get; set; }
    }
}
