﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosPersonas
    {
        public string Accion { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string TipoPersona { get; set; }
        
        public string Nombre1 { get; set; }
        
        public string Nombre2 { get; set; }
        
        public string Apellido1 { get; set; }
        
        public string Apellido2 { get; set; }
        public string RUCPersonaFisica { get; set; }
        
        public string ValidarRUC { get; set; }
        
        public string RazonSocial { get; set; }
        
        public string DenominacionComercial { get; set; }
        
        public string TipoPersonaJuridica { get; set; }
        
        public string TipoFirma { get; set; }
       
        public string Sexo { get; set; }
       
        public string EstadoCivil { get; set; }
        
        public string FechaNacimiento { get; set; }
        
        public string Nacionalidad { get; set; }
        
        public string Ocupacion { get; set; }
        
        public string PaisResidencia { get; set; }
        
        public string Departamento { get; set; }
        
        public string Ciudad { get; set; }
       
        public string Barrio { get; set; }
        
        public string ZonaId { get; set; }
       
        public string Direccion { get; set; }
        
        public string Email { get; set; }
        
        public string Telefono { get; set; }
       
        public string NroSocio { get; set; }
       
        public string OficialCuenta { get; set; }
       
        public string Promotor { get; set; }
       
        public string Usuario {get; set;}
        public string IdOficial{ get; set; }
    }
}
