﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosTarjeta
    {
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }
        [JsonProperty("estadoNuevo")]
        public string EstadoNuevo { get; set; }
        [JsonProperty("observacion")]
        public string Observacion { get; set; }
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("motivoBaja")]
        public int MotivoBaja { get; set; }
        [JsonProperty("costo")]
        public string Costo { get; set; }
        [JsonProperty("afectaRelacionadaCombo")]
        public string AfectaRelacionadaCombo { get; set; }
    }
}
