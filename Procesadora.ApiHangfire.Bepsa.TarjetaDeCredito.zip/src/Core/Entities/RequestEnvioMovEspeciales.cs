﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class RequestEnvioMovEspeciales
    {
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("clave")]
        public string Clave { get; set; }
        [JsonProperty("lote")]
        public List<Lote> Lote { get; set; }
    }
}
