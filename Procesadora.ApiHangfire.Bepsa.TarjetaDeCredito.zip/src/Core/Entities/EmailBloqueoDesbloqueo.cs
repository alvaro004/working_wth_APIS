﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class EmailBloqueoDesbloqueo
    {
        public string TipoEmailBloqueo { get; set; }
        public string Accion { get; set; }
        public string MensajeRetorno { get; set; }
        public string Asunto { get; set; }
        public string EmailUsuario { get; set; }
        public string NumeroTarjeta { get; set; }
        public string NumeroIntento { get; set; }      
    }
}
