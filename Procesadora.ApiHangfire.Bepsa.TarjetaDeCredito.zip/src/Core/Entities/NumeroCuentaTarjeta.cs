﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class NumeroCuentaTarjeta
    {
        public string NumeroCuenta { get; set; }
    }
}
