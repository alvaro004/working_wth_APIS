﻿namespace Continental.API.Core.Entities
{
    public class Credenciales
    {
        public string Key { get; set; }
        public string Usuario { get; set; }
        public string Password { get; set; }
        public string UrlServicio { get; set; }
        public string UrlServicioCredito { get; set; }

        public string UrlServicioMovEspecial { get; set; }
        public string UsuarioServicioBepsa { get; set; }
        public string Clave { get; set; }
        public string UsuarioAbmCredito { get; set; }
        public string ClaveAbmCredito { get; set; }
        public string UrlServicioActivacion { get; set; }
        public string UsuarioActivacion { get; set; }
        public string ClaveActivacion { get; set; }
        public string UrlServicioCuentaActivacion { get; set; }
        public string UsuarioCuentaActivacion { get; set; }
        public string ClaveCuentaActivacion { get; set; }
        public string UrlServicioReimpresion { get; set; }
        public string UsuarioReimpresion { get; set; }
        public string ClaveReimpresion { get; set; }
        public string UrlServicioErrores { get; set; }
        public string UsuarioErrores { get; set; }
        public string ClaveErrores { get; set; }
        public string UrlServicioPago { get; set; }
        public string UsuarioServicioPago { get; set; }
        public string ClaveServicioPago { get; set; }
        public string UrlServicioBloqueoTC { get; set; }
        public string UsuarioServicioBloqueoTC { get; set; }
        public string ClaveServicioBloqueoTC { get; set; }
        public string UrlServicioDesbloqueoTC { get; set; }
        public string UsuarioServicioDesbloqueoTC { get; set; }
        public string ClaveServicioDesbloqueoTC { get; set; }
        public string UrlConsultaEstado { get; set; }
    }
}
