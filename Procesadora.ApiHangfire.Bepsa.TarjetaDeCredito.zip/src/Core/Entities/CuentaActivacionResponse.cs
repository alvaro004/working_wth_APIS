﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class CuentaActivacionResponse
    {
        [JsonProperty("codRespuesta")]
        public string Codigo { get; set; }
        [JsonProperty("msgRespuesta")]
        public string Mensaje { get; set; }
        [JsonProperty("loteRespuesta")]
        public List<LoteCuentaResponse> Lote { get; set; }
    }
}
