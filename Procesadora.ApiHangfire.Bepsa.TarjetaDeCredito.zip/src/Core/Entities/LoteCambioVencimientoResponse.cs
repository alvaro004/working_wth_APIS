﻿using Newtonsoft.Json;
namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class LoteCambioVencimientoResponse
    {
        [JsonProperty("tipoUso")]
        public string TipoUso { get; set;}
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set;}
        [JsonProperty("cuenta")]
        public string Cuenta { get; set;}
        [JsonProperty("adherente")]
        public string Adherente { get; set;}
        [JsonProperty("emision")]
        public string Emision { get; set;}
        [JsonProperty("codigo")]
        public string Codigo { get; set;}
        [JsonProperty("mensaje")]
        public string Mensaje { get; set; }
    }
}
