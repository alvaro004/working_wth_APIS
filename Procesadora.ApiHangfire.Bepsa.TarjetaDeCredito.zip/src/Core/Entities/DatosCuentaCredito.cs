﻿using Continental.API.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosCuentaCredito
    {
        public string Accion { get; set; }
        public string NroControl { get; set; }
        public string NroCuenta { get; set; }
        public string NombreCuenta { get; set; }
        public string CodigoAfinidad { get; set; }
        public string TipoCuenta { get; set; }
        public string RUCExtracto { get; set; }
        public string EstadoCuenta { get; set; }
        public string TipoCierre { get; set; }
        public string ClienteEntidad { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string Empresa { get; set; }
        public string Sucursal { get; set; }
        public string TipoDocumentoOficial { get; set; }
        public string NroDocumentoOficial { get; set; }
        public string MotivoRetencionExtracto { get; set; }
        public string MotivoNoImprimirExtracto { get; set; }
        public string TipoCargo { get; set; }
        public string AplicaSeguroVida { get; set; }
        public string Usuario { get; set; }
        public string PermiteTarjetaInnominada { get; set; }
        public int ExisteRegistro { get; set; }
        public List<Direcciones> Direcciones { get; set; }
        public List<Codeudores> Codeudores { get; set; }
        public List<DatosFinancieros> DatoFinanciero { get; set; }
        public List<LineaCredito> LineaCredito { get; set; }
        public List<TasaInteres> TasaInteres { get; set; }
        public List<CargoPersonalizado> CargoPersonalizado { get; set; }
        public List<DatosPersonas> DatosPersona { get; set; }
    }
}
