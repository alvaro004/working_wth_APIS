﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class SolicitudBloqueo : SolicitudDesbloqueo
    {
        /// <summary>
        /// El tipo de bloqueo (corresponden a los códigos de la tabla de tipo de bloqueo).
        /// </summary>
        public string TipoBloqueo { get; set; }

        /// <summary>
        /// Ámbito de bloqueo (L: local, I: internacional, A: Ambos).
        /// </summary>
        public string AmbitoBloqueo { get; set; }

        /// <summary>
        /// Forma bloqueo (D: definitivo, T: temporal).
        /// </summary>
        public string FormaBloqueo { get; set; }

        /// <summary>
        /// Administración del bloqueo (E: externo) En caso de que 
        /// no se envíe el valor de este parámetro toma por defecto
        /// el valor ‘E’.
        /// </summary>
        public string AdministracionBloqueo { get; set; }

        /// <summary>
        /// Región en donde aplica el bloqueo (Forma parte del bloqueo internacional).
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Son los meses de purga (Esto aplica solamente para el 
        /// bloqueo internacional, los meses de purga se envían solo
        /// para Mastercard).
        /// </summary>
        public int? MesesPurga { get; set; }

        /// <summary>
        /// Código de Retorno enviado a la marca. Los valores varían según la marca.
        /// </summary>
        public string CodigoRetorno { get; set; }

    }

}
