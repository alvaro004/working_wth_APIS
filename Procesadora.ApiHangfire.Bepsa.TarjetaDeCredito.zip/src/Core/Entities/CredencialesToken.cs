﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class CredencialesToken
    {
        public List<Credenciales> Credenciales { get; set; }
    }
}
