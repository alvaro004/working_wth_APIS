﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class DetalleBloqueo : DetalleDesbloqueo
    {
        /// <summary>
        /// El tipo de bloqueo (corresponden a los códigos de la tabla de tipo de bloqueo).
        /// </summary>
        [JsonProperty("tipoBloqueo", NullValueHandling = NullValueHandling.Ignore)]
        public string TipoBloqueo { get; set; }

        /// <summary>
        /// Ámbito de bloqueo (L: local, I: internacional, A: Ambos).
        /// </summary>
        [JsonProperty("ambitoBloqueo", NullValueHandling = NullValueHandling.Ignore)]
        public string AmbitoBloqueo { get; set; }

        /// <summary>
        /// Forma bloqueo (D: definitivo, T: temporal).
        /// </summary>
        [JsonProperty("formaBloqueo", NullValueHandling = NullValueHandling.Ignore)]
        public string FormaBloqueo { get; set; }

        /// <summary>
        /// Administración del bloqueo (E: externo) En caso de que 
        /// no se envíe el valor de este parámetro toma por defecto
        /// el valor ‘E’.
        /// </summary>
        [JsonProperty("administracionBloqueo", NullValueHandling = NullValueHandling.Ignore)]
        public string AdministracionBloqueo { get; set; }

        /// <summary>
        /// Región en donde aplica el bloqueo (Forma parte del bloqueo internacional).
        /// </summary>
        [JsonProperty("region", NullValueHandling = NullValueHandling.Ignore)]
        public string Region { get; set; }

        /// <summary>
        /// Son los meses de purga (Esto aplica solamente para el 
        /// bloqueo internacional, los meses de purga se envían solo
        /// para Mastercard).
        /// </summary>
        [JsonProperty("mesesPurga", NullValueHandling = NullValueHandling.Ignore)]
        public int? MesesPurga { get; set; }

        /// <summary>
        /// Código de Retorno enviado a la marca. Los valores varían según la marca.
        /// </summary>
        [JsonProperty("codigoRetorno", NullValueHandling = NullValueHandling.Ignore)]
        public string CodigoRetorno { get; set; }
    }
}
