﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class LoteCuentaResponse
    {
        [JsonProperty("codigorespuesta")]
        public string Codigo { get; set; }
        [JsonProperty("cuenta")]
        public string Cuenta { get; set; }
        [JsonProperty("descripcion")]
        public string Descripcion { get; set; }
    }
}
