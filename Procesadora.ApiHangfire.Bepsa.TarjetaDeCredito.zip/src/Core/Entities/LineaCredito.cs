﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class LineaCredito
    {
        [JsonProperty("moneda")]
        public string Moneda { get; set; }
        [JsonProperty("tipoLineaCredito")]
        public string TipoLineaCredito { get; set; }
        [JsonProperty("importeLC")]
        public string ImporteLC { get; set; }
    }
}
