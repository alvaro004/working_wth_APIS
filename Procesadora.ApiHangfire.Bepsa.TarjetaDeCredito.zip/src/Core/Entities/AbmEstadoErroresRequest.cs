﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class AbmEstadoErroresRequest
    {
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("clave")]
        public string Clave { get; set; }
        [JsonProperty("idSesion")]
        public float IdSesion { get; set; }
        [JsonProperty("tipoArchivo")]
        public string TipoArchivo { get; set; }
        [JsonProperty("clave1")]
        public string Cuenta { get; set; }
    }
}
