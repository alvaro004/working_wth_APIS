﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class ResponsePagoTC
    {
        [MaxLength(2)]
        [JsonProperty("CodRespuesta")]
        public string CodigoRespuesta { get; set; }

        [MaxLength(50)]
        [JsonProperty("MsgRespuesta")]
        public string MensajeRespuesta { get; set; }

        [JsonProperty("LoteRespuesta")]
        public List<LoteRespuestaPagoTC> LoteRespuesta { get; set; }
    }
}
