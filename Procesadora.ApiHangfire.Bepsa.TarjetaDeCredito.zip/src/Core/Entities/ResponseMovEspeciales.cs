﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class ResponseMovEspeciales
    {
        public string codRespuesta { get; set; }
        public string msgRespuesta { get; set; }
        public List<LoteRespuesta> loteRespuesta { get; set; }
    }
}
