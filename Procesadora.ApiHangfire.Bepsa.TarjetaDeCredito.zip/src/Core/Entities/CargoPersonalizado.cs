﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class CargoPersonalizado
    {
        [JsonProperty("moneda")]
        public string Moneda { get; set; }
        [JsonProperty("tipoCargoId")]
        public string TipoCargoId { get; set; }
        [JsonProperty("importeFijo")]
        public string ImporteFijo { get; set; }
        [JsonProperty("porcentaje")]
        public string Porcentaje { get; set; }
        [JsonProperty("fechaDesde")]
        public string FechaDesde { get; set; }
        [JsonProperty("fechaFin")]
        public string FechaFin { get; set; }
        [JsonProperty("aplicaImpuesto")]
        public string AplicaImpuesto { get; set; }
    }
}
