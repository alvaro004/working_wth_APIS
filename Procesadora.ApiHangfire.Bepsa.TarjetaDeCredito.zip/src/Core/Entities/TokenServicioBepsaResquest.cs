﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class TokenServicioBepsaResquest
    {
        [JsonProperty("usuario")]
        public string Usuario { get; set; }

        [JsonProperty("password")]
        public string Clave { get; set; }
    }
}
