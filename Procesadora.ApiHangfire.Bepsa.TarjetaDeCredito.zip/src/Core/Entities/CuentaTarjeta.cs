﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class CuentaTarjeta
    {
        [JsonProperty("cuenta")]
        public Int64 Cuenta { get; set; }
        [JsonProperty("estadoNuevo")]
        public string EstadoNuevo { get; set; }
        [JsonProperty("observacion")]
        public string Observacion { get; set; }
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("motivoBaja")]
        public int MotivoBaja { get; set; }
        
    }
}
