﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosFinancieros
    {
        [JsonProperty("moneda")]
        public string Moneda { get; set; }
        [JsonProperty("modoPago")]
        public string ModoPago { get; set; }
        [JsonProperty("tipoCtaBancaria")]
        public string TipoCtaBancaria { get; set; }
        [JsonProperty("nroCtaBancaria")]
        public string NroCtaBancaria { get; set; }
        [JsonProperty("tipoPago")]
        public string TipoPago { get; set; }
        [JsonProperty("tipoTasaFinanciacion")]
        public string TipoTasaFinanciacion { get; set; }
        [JsonProperty("personalizarPM")]
        public string PersonalizarPM { get; set; }
        [JsonProperty("porcentajePM")]
        public string PorcentajePM { get; set; }
        [JsonProperty("importeMinPM")]
        public string ImporteMinPM { get; set; }
        [JsonProperty("importeFijoPM")]
        public string ImporteFijoPM { get; set; }
        [JsonProperty("cargoGastoFinanciero")]
        public string CargoGastoFinanciero { get; set; }
    }
}
