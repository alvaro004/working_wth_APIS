﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Continental.API.Core.Entities
{
    public class WebToken
    {
        public string Token { get; set; }
    }
}
