﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class SucursalTarjeta
    {
        public string Sucursal { get; set; }
    }
}
