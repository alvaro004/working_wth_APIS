﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestToken
    {
        public string Usuario { get; set; }
        public string Password { get; set; }
    }
}
