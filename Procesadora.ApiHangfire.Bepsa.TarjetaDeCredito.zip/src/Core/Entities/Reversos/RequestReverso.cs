﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Reversos
{
    public class RequestReverso
    {
        [JsonProperty("numeroComprobante")]
        public decimal Comprobante { get; set; }

    }
}
