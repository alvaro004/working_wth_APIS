﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Reversos
{
    public class ReversoResponse
    {
        [JsonProperty("codigo")]
        public string Codigo { get; set; }
        [JsonProperty("mensaje")]
        public string Mensaje { get; set; }
    }
}
