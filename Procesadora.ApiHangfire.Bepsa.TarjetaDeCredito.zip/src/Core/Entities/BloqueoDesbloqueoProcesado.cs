﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class BloqueoDesbloqueoProcesado
    {
        /// <summary>
        ///  Número de la tarjeta, solo se visualiza si fue enviada en la petición
        /// </summary>
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }

        /// <summary>
        /// Número de cuenta, solo se visualiza si fue enviada en la petición
        /// </summary>
        [JsonProperty("cuenta")]
        public string Cuenta { get; set; }

        /// <summary>
        /// Número de adherente
        /// </summary>
        [JsonProperty("adherente")]
        public string Adherente { get; set; }

        /// <summary>
        /// Número de emisión
        /// </summary>
        [JsonProperty("emision")]
        public string Emision { get; set; }

        /// <summary>
        /// Detalle para bloqueo Nacional
        /// </summary>
        [JsonProperty("local")]
        public BloqueoDesbloqueoLocal Local {get;set;}

        /// <summary>
        /// Detalle para bloqueo Internacional
        /// </summary>
        [JsonProperty("internacional")]
        public BloqueoDesbloqueoInternacional Internacional { get; set; }
    }
}
