﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestPersonas
    {
        [Required(ErrorMessage = "REQUERIDO")]
        [MaxLength(1)]
        [JsonProperty("accion")]
        public string Accion { get; set; }
        [MaxLength(3)]
        [JsonProperty("tipoDocumento")]
        public string TipoDocumento { get; set; }
        [MaxLength(15)]
        [JsonProperty("nroDocumento")]
        public string NroDocumento { get; set; }
        [MaxLength(1)]
        [JsonProperty("tipoPersona")]
        public string TipoPersona { get; set; }
        [MaxLength(20)]
        [JsonProperty("nombre1")]
        public string Nombre1 { get; set; }
        [MaxLength(20)]
        [JsonProperty("nombre2")]
        public string Nombre2 { get; set; }
        [MaxLength(20)]
        [JsonProperty("apellido1")]
        public string Apellido1 { get; set; }
        [MaxLength(20)]
        [JsonProperty("apellido2")]
        public string Apellido2 { get; set; }
        [MaxLength(15)]
        [JsonProperty("RUCPersonaFisica")]
        public string RUCPersonaFisica { get; set; }
        [MaxLength(1)]
        [JsonProperty("validarRUC")]
        public string ValidarRUC { get; set; }
        [MaxLength(30)]
        [JsonProperty("razonSocial")]
        public string RazonSocial { get; set; }
        [MaxLength(60)]
        [JsonProperty("denominacionComercial")]
        public string DenominacionComercial { get; set; }
        [MaxLength(3)]
        [JsonProperty("tipoPersonaJuridica")]
        public string TipoPersonaJuridica { get; set; }
        [MaxLength(1)]
        [JsonProperty("tipoFirma")]
        public string TipoFirma { get; set; }
        [MaxLength(1)]
        [JsonProperty("sexo")]
        public string Sexo { get; set; }
        [MaxLength(1)]
        [JsonProperty("estadoCivil")]
        public string EstadoCivil { get; set; }
        [MaxLength(8)]
        [JsonProperty("fechaNacimiento")]
        public string FechaNacimiento { get; set; }
        [MaxLength(3)]
        [JsonProperty("nacionalidad")]
        public string Nacionalidad { get; set; }
        [MaxLength(5)]
        [JsonProperty("ocupacion")]
        public string Ocupacion { get; set; }
        [MaxLength(3)]
        [JsonProperty("paisResidencia")]
        public string PaisResidencia { get; set; }
        [MaxLength(3)]
        [JsonProperty("departamento")]
        public string Departamento { get; set; }
        [MaxLength(4)]
        [JsonProperty("ciudad")]
        public string Ciudad { get; set; }
        [MaxLength(4)]
        [JsonProperty("barrio")]
        public string Barrio { get; set; }
        [MaxLength(5)]
        [JsonProperty("zonaId")]
        public string ZonaId { get; set; }
        [MaxLength(50)]
        [JsonProperty("direccion")]
        public string Direccion { get; set; }
        [MaxLength(50)]
        [JsonProperty("email")]
        public string Email { get; set; }
        [MaxLength(20)]
        [JsonProperty("telefono")]
        public string Telefono { get; set; }
        [MaxLength(12)]
        [JsonProperty("nroSocio")]
        public string NroSocio { get; set; }
        [MaxLength(1)]
        [JsonProperty("oficialCuenta")]
        public string OficialCuenta { get; set; }
        [MaxLength(1)]
        [JsonProperty("promotor")]
        public string Promotor { get; set; }
        [MaxLength(10)]
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
    }
}
