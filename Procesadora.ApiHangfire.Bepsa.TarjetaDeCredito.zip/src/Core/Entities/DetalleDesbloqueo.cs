﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class DetalleDesbloqueo
    {
        /// <summary>
        /// Tipo de uso (D: debito, C: crédito).
        /// </summary>
        [JsonProperty("tipoUso")]
        public string TipoUso { get; set; }

        /// <summary>
        ///  Número de tarjeta actual (es opcional para las tarjetas de 
        ///  débito, es requerido para las tarjetas de crédito).
        /// </summary>
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }

        /// <summary>
        /// Número de cuenta (es requerido solo para las tarjetas de débito).
        /// </summary>
        [JsonProperty("cuenta")]
        public string Cuenta { get; set; }

        /// <summary>
        /// Número de adherente (es requerido solo para las tarjetas de débito).
        /// </summary>
        [JsonProperty("adherente")]
        public string Adherente { get; set; }

        /// <summary>
        /// Número de emisión (es requerido solo para las tarjetas de débito).
        /// </summary>
        [JsonProperty("emision")]
        public string Emision { get; set; }
    }
}
