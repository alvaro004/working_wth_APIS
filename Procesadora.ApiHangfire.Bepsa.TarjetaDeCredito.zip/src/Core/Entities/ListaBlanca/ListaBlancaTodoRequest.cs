﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class ListaBlancaTodoRequest
    {
       
        [JsonProperty("binTarjeta")]
        public string BinTarjeta { get; set; }

        [JsonProperty("ultimosCuatroTarjeta")]
        public string UltimosCuatroTarjeta { get; set; }

        [JsonProperty("nroDocumento")]
        public string NumeroDocumento { get; set; }

        [JsonProperty("usuario")]
        public string Usuario { get; set; }

        [JsonProperty("fechaInicio")]
        public string FechaInicio { get; set; }

        [JsonProperty("fechaFin")]
        public string FechaFin { get; set; }


    }
}
