﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class ListaBlancaResponse
    {
        [JsonProperty("codigo")]
        public string Codigo { get; set; }
        [JsonProperty("mensaje")]
        public string Mensaje { get; set; }
    }
}
