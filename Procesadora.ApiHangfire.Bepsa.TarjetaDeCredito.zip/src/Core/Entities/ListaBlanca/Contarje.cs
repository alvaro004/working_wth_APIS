﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class Contarje
    {
        public string NumeroDocumento { get; set; }
        public string NumeroTarjeta { get; set; }
        public string DigitoVerificador { get; set; }

    }
}
