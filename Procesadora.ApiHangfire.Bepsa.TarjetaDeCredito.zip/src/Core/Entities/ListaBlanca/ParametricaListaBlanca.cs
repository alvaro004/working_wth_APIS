﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class ParametricaListaBlanca
    {
        public bool Switch { get; set; }

        public int Estado { get; set; }

        public int Procesadora { get; set; }

        public string OperacionTipo { get; set; }

        public int Intento { get; set; }

        public int Cantidad { get; set; }

        public int Hilos { get; set; }

    }
}
