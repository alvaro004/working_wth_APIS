﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class AltaListaBlancaResponse : ListaBlancaResponse
    {
        [JsonProperty("idComercio")]
        public int IdComercio { get; set; }
        [JsonProperty("idTarjeta")]
        public int IdTarjeta { get; set; }
    }
}
