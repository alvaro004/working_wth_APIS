﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class Tartjtdebitos
    {
        public string NumeroDocumento { get; set; }
        public string NumeroTarjeta { get; set; }

    }
}
