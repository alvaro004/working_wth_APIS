﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class DatosListaBlanca
    {
        public decimal Id { get; set; }
        public string NumeroTarjeta { get; set; }
        public string? BinAdquirente { get; set; }
        public string? CodigoComercio { get; set; }
        public string? NombreComercio { get; set; }
        public string Usuario { get; set; }
        public DateTime? FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public int estado { get; set; } 
        public string TipoOperacion { get; set; }
        public string? CodigoRetorno { get; set; }
        public string? MensajeRetorno { get; set; }
        public int Intentos { get; set; }
        public string TipoMarca { get; set; }
        public string? NumeroDocumento { get; set; }
        public DateTime? FechaModificacion { get; set; }
        public decimal IdTarjeta { get; set; }
    }
}
