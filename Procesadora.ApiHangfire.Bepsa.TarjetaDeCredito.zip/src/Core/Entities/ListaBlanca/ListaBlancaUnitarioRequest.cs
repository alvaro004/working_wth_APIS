﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca
{
    public class ListaBlancaUnitarioRequest : ListaBlancaTodoRequest
    {
        [JsonProperty("binAdquirente")]
        public string BinAdquirente { get; set; }

        [JsonProperty("codigoComercio")]
        public string CodigoComercio { get; set; }

        [JsonProperty("nombreComercio")]
        public string Comercio { get; set; }

        public string TipoMarca { get; set; }

        public ParametricaListaBlanca ParametricaListaBlanca { get; set; }

        public decimal IdOp { get; set; }

    }
}
