﻿using Newtonsoft.Json;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestAbmCredito
    {
        [JsonProperty("autorizador")]
        public List<string> Autorizador { get; set; }
        [JsonProperty("personas")]
        public List<RequestPersonas> Personas { get; set; }
        [JsonProperty("cuentas")]
        public List<RequestCuenta> Cuentas { get; set; }
        [JsonProperty("tarjetas")]
        public List<RequestTarjeta> Tarjetas { get; set; }
    }
}
