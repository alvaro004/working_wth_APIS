﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class Direcciones
    {
        [JsonProperty("idDireccion")]
        public string IdDireccion { get; set; }
        [JsonProperty("tipoDireccion")]
        public string TipoDireccion { get; set; }
        [JsonProperty("valor1")]
        public string Valor1 { get; set; }
        [JsonProperty("valor2")]
        public string Valor2 { get; set; }
        [JsonProperty("valor3")]
        public string Valor3 { get; set; }
        [JsonProperty("descripcionReferencia")]
        public string DescripcionReferencia { get; set; }
        [JsonProperty("pais")]
        public string Pais { get; set; }
        [JsonProperty("departamento")]
        public string Departamento { get; set; }
        [JsonProperty("ciudad")]
        public string Ciudad { get; set; }
        [JsonProperty("barrio")]
        public string Barrio { get; set; }
        [JsonProperty("zona")]
        public string Zona { get; set; }
    }
}
