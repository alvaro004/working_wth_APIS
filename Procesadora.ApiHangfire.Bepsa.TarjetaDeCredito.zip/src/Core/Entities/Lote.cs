﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class Lote
    {
        [JsonProperty("nroTarjeta")]
        public string NumeroTarjeta { get; set; }
        [JsonProperty("moneda")]
        public int Moneda { get; set; }
        [JsonProperty("fechaMovimiento")]
        public string FechaMovimiento { get; set; }
        [JsonProperty("importe")]
        public decimal Importe { get; set; }
        [JsonProperty("tipoCargoId")]
        public int TipoCargoId { get; set; }
        [JsonProperty("informaExtracto")]
        public string InformaExtracto { get; set; }
        [JsonProperty("afectaDisponible")]
        public string AfectaDisponible { get; set; }
        [JsonProperty("idMovimientosTransaccional")]
        public int IdMovimientosTransaccional { get; set; }
        [JsonProperty("descripcionMovimiento")]
        public string DescripcionMovimiento { get; set; }
        [JsonProperty("tipoSaldoId")]
        public int TipoSaldoId { get; set; }
        [JsonProperty("impuestoId")]
        public int ImpuestoId { get; set; }
    }
}
