﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class Fechus
    {
        public DateTime Fecha { get; set; }
    }
}
