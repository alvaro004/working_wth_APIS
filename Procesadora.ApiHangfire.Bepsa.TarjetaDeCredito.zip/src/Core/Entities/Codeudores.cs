﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class Codeudores
    {
        [JsonProperty("tipoDocumento")]
        public string TipoDocumento { get; set; }
        [JsonProperty("nroDocumento")]
        public string NroDocumento { get; set; }
    }
}
