﻿using Continental.API.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
        public class ConfiguracionesCore
        {
            public CredencialesToken CredencialesToken { get; set; }
        }
}
