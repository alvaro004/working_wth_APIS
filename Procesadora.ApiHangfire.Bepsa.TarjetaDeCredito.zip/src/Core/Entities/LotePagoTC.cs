﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class LotePagoTC
    {
        [MaxLength(19)]
        [JsonProperty("nroTarjeta")]
        public string NumeroTarjeta { get; set; }

        [JsonProperty("moneda")]
        public int Moneda { get; set; }

        [MaxLength(8)]
        [JsonProperty("fechaAfectacion")]
        public string FechaAfectacion { get; set; }

        [JsonProperty("importe")]
        public decimal Importe { get; set; }

        [MaxLength(3)]
        [JsonProperty("tipoCargoId")]
        public int TipoCargoId { get; set; }

        [MaxLength(1)]
        [JsonProperty("informaExtracto")]
        public string InformaExtracto { get; set; }

        [MaxLength(1)]
        [JsonProperty("afectaDisponible")]
        public string AfectaDisponible { get; set; }

        [MaxLength(3)]
        [JsonProperty("origenMovimiento")]
        public string OrigenMovimiento { get; set; }

        [MaxLength(5)]
        [JsonProperty("dispositivoId")]
        public string DispositivoId { get; set; }
        
        [JsonProperty("campoReservado")]
        public int CampoReservado { get; set; }
    }
}
