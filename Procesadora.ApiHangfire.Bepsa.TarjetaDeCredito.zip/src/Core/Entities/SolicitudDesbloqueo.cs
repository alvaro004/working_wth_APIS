﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class SolicitudDesbloqueo
    {
        /// <summary>
        /// Codigo Identificador.
        /// </summary>
        public string Logkey { get; set; }
      
        /// <summary>
        /// Tipo de uso (D: debito, C: crédito).
        /// </summary>
        public string TipoUso { get; set; }

        /// <summary>
        /// Nro Proceso.
        /// </summary>
        public string NumeroProceso { get; set; }

        /// <summary>
        ///  Número de tarjeta actual (es opcional para las tarjetas de 
        ///  débito, es requerido para las tarjetas de crédito).
        /// </summary>
        public string Tarjeta { get; set; }

        /// <summary>
        /// Número de cuenta (es requerido solo para las tarjetas de débito).
        /// </summary>
        public string Cuenta { get; set; }

        /// <summary>
        /// Número de adherente (es requerido solo para las tarjetas de débito).
        /// </summary>
        public string Adherente { get; set; }

        /// <summary>
        /// Número de emisión (es requerido solo para las tarjetas de débito).
        /// </summary>
        public string Emision { get; set; }

        /// <summary>
        /// Email del Usuario que registro el bloqueo.
        /// </summary>
        public string UserCorreo { get; set; }
        public string EsWaled { get; set; }
    }
}
