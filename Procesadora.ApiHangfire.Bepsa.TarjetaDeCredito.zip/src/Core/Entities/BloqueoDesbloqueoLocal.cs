﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class BloqueoDesbloqueoLocal
    {
        /// <summary>
        /// Código de respuesta retornado del servicio.
        /// </summary>
        [JsonProperty("codigoRetornoLocal")]
        public string CodigoRetorno { get; set; }

        /// <summary>
        ///  Mensaje descriptivo del código de retorno del servicio.
        /// </summary>
        [JsonProperty("mensajeRetornoLocal")]
        public string MensajeRetorno { get; set; }
    }
}

