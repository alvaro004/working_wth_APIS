﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class EstadoErroresResponse
    {
        [JsonProperty("idSesion")]
        public int IdSesion { get; set; }
        [JsonProperty("tipoArchivo")]
        public string TipoArchivo { get; set; }
        [JsonProperty("nroLinea")]
        public int NumeroLinea { get; set; }
        [JsonProperty("agrupador")]
        public int Agrupador { get; set; }
        [JsonProperty("secuenciaAgrupador")]
        public int SecuenciaAgrupador { get; set; }
        [JsonProperty("secuenciaError")]
        public int SecuenciaError { get; set; }
        [JsonProperty("codigo")]
        public string Codigo { get; set; }
        [JsonProperty("mensaje")]
        public string Mensaje { get; set; }
    }
}
