﻿using Continental.API.Core.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestCuenta
    {
        [JsonProperty("accion")]
        public string Accion { get; set; }
        [JsonProperty("nroControl")]
        public string NroControl { get; set; }
        [JsonProperty("nroCuenta")]
        public string NroCuenta { get; set; }
        [JsonProperty("nombreCuenta")]
        public string NombreCuenta { get; set; }
        [JsonProperty("codigoAfinidad")]
        public string CodigoAfinidad { get; set; }
        [JsonProperty("tipoCuenta")]
        public string TipoCuenta { get; set; }
        [JsonProperty("RUCExtracto")]
        public string RUCExtracto { get; set; }
        [JsonProperty("estadoCuenta")]
        public string EstadoCuenta { get; set; }
        [JsonProperty("tipoCierre")]
        public string TipoCierre { get; set; }
        [JsonProperty("clienteEntidad")]
        public string ClienteEntidad { get; set; }
        [JsonProperty("tipoDocumento")]
        public string TipoDocumento { get; set; }
        [JsonProperty("nroDocumento")]
        public string NroDocumento { get; set; }
        [JsonProperty("empresa")]
        public string Empresa { get; set; }
        [JsonProperty("sucursal")]
        public string Sucursal { get; set; }
        [JsonProperty("tipoDocumentoOficial")]
        public string TipoDocumentoOficial { get; set; }
        [JsonProperty("nroDocumentoOficial")]
        public string NroDocumentoOficial { get; set; }
        [JsonProperty("motivoRetencionExtracto")]
        public string MotivoRetencionExtracto { get; set; }
        [JsonProperty("motivoNoImprimirExtracto")]
        public string MotivoNoImprimirExtracto { get; set; }
        [JsonProperty("tipoCargo")]
        public string TipoCargo { get; set; }
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("permiteTrjInnominada")]
        public string PermiteTarjetaInnominada { get; set; }
        [JsonProperty("direcciones")]
        public List<Direcciones> Direcciones { get; set; }
        [JsonProperty("codeudores")]
        public List<Codeudores> Codeudores { get; set; }
        [JsonProperty("datoFinanciero")]
        public List<DatosFinancieros> DatoFinanciero { get; set; }
        [JsonProperty("lineaCredito")]
        public List<LineaCredito> LineaCredito { get; set; }
        [JsonProperty("tasaInteres")]
        public List<TasaInteres> TasaInteres { get; set; }
        [JsonProperty("cargoPersonalizado")]
        public List<CargoPersonalizado> CargoPersonalizado { get; set; }
    }
}
