﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class ResponseReimpresion
    {
        [JsonProperty("codRespuesta")]
        public string Codigo { get; set; }
        [JsonProperty("msgRespuesta")]
        public string Mensaje { get; set; }
        [JsonProperty("loteRespuesta")]
        public List<LoteReimpresionRespuesta> Lote { get; set; }
    }
}
