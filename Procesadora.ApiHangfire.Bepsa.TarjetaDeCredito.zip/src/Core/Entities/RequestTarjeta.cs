﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class RequestTarjeta
    {
        [JsonProperty("accion")]
        public string Accion { get; set; }
        [JsonProperty("nroControl")]
        public string NroControl { get; set; }
        [JsonProperty("nroTarjeta")]
        public string NroTarjeta { get; set; }
        [JsonProperty("nombreTarjeta")]
        public string NombreTarjeta { get; set; }
        [JsonProperty("codigoAfinidad")]
        public string CodigoAfinidad { get; set; }
        [JsonProperty("nroCuenta")]
        public string NroCuenta { get; set; }
        [JsonProperty("tipoDocumento")]
        public string TipoDocumento { get; set; }
        [JsonProperty("nroDocumento")]
        public string NroDocumento { get; set; }
        [JsonProperty("tipoTarjeta")]
        public string TipoTarjeta { get; set; }
        [JsonProperty("nombrePlastico")]
        public string NombrePlastico { get; set; }
        [JsonProperty("tipoPlastico")]
        public string TipoPlastico { get; set; }
        [JsonProperty("duracion")]
        public string Duracion { get; set; }
        [JsonProperty("situacionTarjeta")]
        public string SituacionTarjeta { get; set; }
        [JsonProperty("renovar")]
        public string Renovar { get; set; }
        [JsonProperty("embozarPlastico")]
        public string EmbozarPlastico { get; set; }
        [JsonProperty("sucursal")]
        public string Sucursal { get; set; }
        [JsonProperty("campoReservado")]
        public string CampoReservado { get; set; }
        [JsonProperty("idTipoDocPromotor")]
        public string IdTipoDocPromotor { get; set; }
        [JsonProperty("nroDocPromotor")]
        public string NroDocPromotor { get; set; }
        [JsonProperty("ordenEmbozado")]
        public string OrdenEmbozado { get; set; }
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
    }
}
