﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class BloqueoDesbloqueoRequest
    {
        /// <summary>
        /// Lista con los datos de las tarjetas a bloquear.
        /// </summary>
        [JsonProperty("tarjetas")]
        public List<DetalleBloqueo> Tarjetas;
    }
}
