﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class LoteRespuestaPagoTC
    {
        [MaxLength(2)]
        public string CodigoRespuesta { get; set; }

        [MaxLength(100)]
        public string Descripcion { get; set; }

        [MaxLength(19)]
        public string Tarjeta { get; set; }
    }
}
