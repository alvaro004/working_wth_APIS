﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
   public class BloqueoDesbloqueoInternacional
    {
        /// <summary>
        /// Código de respuesta retornado del servicio.
        /// </summary>
        [JsonProperty("codigoRetornoInternacional")]
        public string CodigoRetorno { get; set; }

        /// <summary>
        ///  Mensaje descriptivo del código de retorno del servicio.
        /// </summary>
        [JsonProperty("mensajeRetornoInternacional")]
        public string MensajeRetorno { get; set; }
    }
}
