﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class Reimpresion : LoteReimpresion
    {
        public int Costo { get; set; }
        public string SucursalRegistro { get; set; }
        public string SucursalAutorizo { get; set; }

        public string Observacion { get; set; }
        public int Estado { get; set; }
        public int Procesadora { get; set; }
        public string UsuarioProceso { get; set; }
        public string UsuarioRegistro { get; set; }
        public string UsuarioAutorizo { get; set; }
        public int Id { get; set; }
        public string Biblioteca { get; set; }
        public string NuevaTarjeta { get; set; }
        public string Ald { get; set; }
        public string Ofac { get; set; }
        public string Onu { get; set; }
        public string TarjetaNuevo { get; set; }
        public string Vencimiento { get; set; }
        public string FechaValidacion { get; set; }
        public string MotivoTransferencia { get; set; }
        public int Clasbcp { get; set; }
        public string Mora { get; set; }
        public string TarjetaVencida { get; set; }
        public string TarjetaBloqueada { get; set; }
        public DateTime FechaRegistro { get; set; }
        public DateTime FechaAutorizo { get; set; }
        public int LogKey { get; set; }
        public int NumeroProceso { get; set; }
        public int Enviar { get; set; } 
        public string Procesado { get; set; }
    }
}
