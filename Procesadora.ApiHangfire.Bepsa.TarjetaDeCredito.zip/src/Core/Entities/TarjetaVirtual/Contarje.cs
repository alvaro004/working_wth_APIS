﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class Contarje
    {
        public string Cuenta { get; set; }

        public string Tarjeta { get; set; }

        public string Digito { get; set; }

        public string FechaEmision { get; set; }

        public string Linea { get; set; }

        public string Tasa { get; set; }

        public string Vencimiento { get; set; }

        public string Saldo { get; set; }

        public string Situacion { get; set; }

        public string Cedula { get; set; }

        public string CodigoCliente { get; set; }

        public string Sucursal { get; set; }

        public string EsPrincipal { get; set; }

        public string MontoMora { get; set; }

        public string DiaMora { get; set; }

        public string NombrePlastico { get; set; }

        public string Direccion { get; set; }

        public string Telefono { get; set; }

        public string Judicial { get; set; }

        public string Estado { get; set; }

        public string FechaUltimoPago { get; set; }

        public string SaldoUltimoExtracto { get; set; }

        public string PagoMinimo { get; set; }

        public string PagoAcumuladoMes { get; set; }

        public DateTime FechaEmisionCompleto { get; set; }

        public string MontoLineaCuota { get; set; }

        public string MontoDeudaCuota { get; set; }

        public string IndicadorEstado { get; set; }

        public string Codeudor { get; set; }

        public string DocumentoCodeudor { get; set; }

        public string Renovacion { get; set; }

    }
}
