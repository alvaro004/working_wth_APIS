﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class EstadoTransmicion
    {
        [JsonProperty("ESTADO")]
        public string Estado { get; set; }

        [JsonProperty("NROTARJETA")]
        public string NumeroTarjeta { get; set; }
    }
}
