﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class DatosPersona
    {
        public string IdPersona { get; set; }

        public string Documento { get; set; }

        public string IdTipoDocumento { get; set; }
    }
}
