﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class ConsultaEstadoResponse
    {
        public EstadoTransmicion EstadoTransmicion { get; set; }
    }
}
