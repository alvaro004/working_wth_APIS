﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class PbTarjeta
    {
        public string NumeroTarjeta { get; set; }
        public string Tarjeta { get; set; }
        public string Digito { get; set; }
        public string NombreTarjeta { get; set; }
        public string CodigoEntidad { get; set; }
        public string Afinidad { get; set; }
        public string Marca { get; set; }
        public string CodigoProducto { get; set; }
        public string Cuenta { get; set; }
        public string IdPersona { get; set; }
        public string Documento { get; set; }
        public string TipoTarjeta { get; set; }
        public string NombrePlastico { get; set; }
        public string ValeDesde { get; set; }
        public string Duracion { get; set; }
        public string ValeHasta { get; set; }
        public string ValeHastaEmbozado { get; set; }
        public string Personalizada { get; set; }
        public string Renovar { get; set; }
        public string TipoPlastico { get; set; }
        public string IdTipoDocumento { get; set; }
        public string NombreBandaMagnetica { get; set; }
        public DateTime FechaRecibo { get; set; }
        public DateTime FechaEmbozado { get; set; }
        public DateTime FechaPin { get; set; }
        public DateTime FechaEmision { get; set; }
        public string TipoUltimoEmbozado { get; set; }
        public string CobrarFraude { get; set; }
        public string Recuperada { get; set; }
        public string Vencida { get; set; }
        public string IdTipoBloqueo { get; set; }
        public string SituacionTarjeta { get; set; }
        public string Reservado1 { get; set; }
        public string UserAdd { get; set; }
        public DateTime FechaAdd { get; set; }
        public string ModificacionUsuario { get; set; }
        public string FechaModificacion { get; set; }
        public DateTime FechaSituacion { get; set; }
        public string ObservacionSituacion { get; set; }
        public string EmbozarPlastico { get; set; }
        public string Reservado2 { get; set; }
        public string Reservado3 { get; set; }
        public string Reservado4 { get; set; }
        public string Reservado5 { get; set; }
        public string Reservado6 { get; set; }
        public string Reservado7 { get; set; }
        public string IdMotivoNovedad { get; set; }
        public string IdMotivoEntidad { get; set; }
        public string IdFormatoRecibo { get; set; }
        public string IdFormatoPin { get; set; }
        public string IdPromotor { get; set; }
        public string IdMotivoNovedad2 { get; set; }
        public string IdMotivoEntidad2 { get; set; }
        public string ObservacionMotivoTarjeta { get; set; }
        public string DisenhoDataCard { get; set; }
        public string CodigoCliente { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string UsuarioCreacion { get; set; }
        public DateTime FechaModificacionPb { get; set; }
        public string UsuarioModificacion { get; set; }
        public string Firma { get; set; }
        public string Reservado8 { get; set; }
        public string Reservado9 { get; set; }
        public string FormaBloqueo { get; set; }
    }
}
