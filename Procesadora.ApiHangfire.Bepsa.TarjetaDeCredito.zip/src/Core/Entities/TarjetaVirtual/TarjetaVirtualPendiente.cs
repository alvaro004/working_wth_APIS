﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class TarjetaVirtualPendiente
    {
        public string IdSesionTarjeta { get; set; }

        public string Cuenta { get; set; }

        public string Tarjeta { get; set; }
    }
}
