﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class MarcaTarjeta
    {
        public string Marca { get; set; }

        public string Producto { get; set; }

        public string IdAfinidad { get; set; }
    }
}
