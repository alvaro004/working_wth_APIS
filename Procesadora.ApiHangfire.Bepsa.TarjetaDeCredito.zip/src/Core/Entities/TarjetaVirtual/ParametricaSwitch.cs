﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class ParametricaSwitch
    {
        public bool Switch { get; set; }

        public int Hilo { get; set; }

        public string MensajePush { get; set; }
    }
}
