﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class ConsultaEstadoAltaRequest
    {
        [JsonProperty("idSession")]
        public string IdSession { get; set; }

        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }
    }
}
