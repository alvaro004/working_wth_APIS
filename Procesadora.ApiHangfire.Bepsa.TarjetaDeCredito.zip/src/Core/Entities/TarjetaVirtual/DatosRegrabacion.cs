﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual
{
    public class DatosRegrabacion
    {
        public string Novedad { get; set;  }
        public int Motivo {get; set; }
        public string Cobrar {get; set; }
        public int Importe {get; set; }
        public string TipoPlastico {get; set; }
        public string NuevaTarjetaCombo {get; set; }
        public string CodigoCliente { get; set; }
        public string Tarjeta { get; set; }
        public int Costo { get; set; }
        public string Biblioteca { get; set; }
        public int Estado { get; set; }
        public string Usuario { get; set; }
        public int Procesadora { get; set; }
        public string Observacion { get; set; }
        public string Sucursal { get; set; }
        public string Ofac { get; set; }
        public string Ald { get; set; }
        public string Onu { get; set; }
        public string Mora { get; set; }
        public int ClasBcp { get; set; }
        public string Vencido { get; set; }
        public string TarjetaVencido { get; set; }
        public string SucursalAutoriza { get; set; }
        public string TarjetaBloqueada { get; set; }
        public int Enviar { get; set; }
        public string Procesado { get; set; }
    }
}
