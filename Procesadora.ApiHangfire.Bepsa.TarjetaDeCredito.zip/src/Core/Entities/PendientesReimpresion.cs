﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class PendientesReimpresion
    {
        public string NumeroProceso { get; set; }
    }
}
