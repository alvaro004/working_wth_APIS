﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class DefaultResponse
    {
        public string Codigo { get; set; }
        public string Mensaje { get; set; }
    }
}
