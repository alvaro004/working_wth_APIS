﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class LoteConsultaRenovacionBepsaResponse
    {
        [JsonProperty("tarjetaActual")]
        public string TarjetaActual;

        [JsonProperty("tarjetaNueva")]
        public string TarjetaNueva;

        [JsonProperty("nuevaFechaVencimiento")]
        public string NuevaFechaVencimiento;

        [JsonProperty("idEstado")]
        public string IdEstado;

        [JsonProperty("estado")]
        public string Estado;

    }
}
