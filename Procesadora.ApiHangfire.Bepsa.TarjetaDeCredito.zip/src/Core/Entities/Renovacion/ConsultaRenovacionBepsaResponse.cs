﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Continental.API.Core.Entities
{
    public class ConsultaRenovacionBepsaResponse
    {
        public string CodigoRespuesta { get; set; }

        public string MensajeRespuesta { get; set; }

        public List<LoteConsultaRenovacionBepsaResponse> Lote { get; set; }
    }
}
