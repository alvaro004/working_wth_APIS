﻿using System;

namespace Continental.API.Core.Entities
{
    public class EnviadorReimpresionBepsaEF
    {
        public decimal NumeroProceso { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaEnvio { get; set; }
        public int Estado { get; set; }
        public int CantidadIntento { get; set; }
        public string Maquina { get; set; }
        public decimal? IdSeguimiento { get; set; }
        public decimal CantidadIntentoSeguimiento { get; set; }
    }
}
