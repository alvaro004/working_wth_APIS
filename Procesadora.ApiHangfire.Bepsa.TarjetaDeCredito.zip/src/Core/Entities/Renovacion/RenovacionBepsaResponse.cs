﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class RenovacionBepsaResponse
    {
        [JsonProperty("idSeguimiento")]
        public decimal IdSeguimiento { get; set; }
        public string CodigoRespuesta { get; set; }
        public string MensajeRespuesta { get; set; }
    }
}
