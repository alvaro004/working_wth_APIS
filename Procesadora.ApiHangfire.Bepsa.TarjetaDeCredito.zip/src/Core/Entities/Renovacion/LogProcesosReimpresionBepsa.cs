﻿
using System;

namespace Continental.API.Core.Entities
{
    public class LogProcesosReimpresionBepsa
    {
        public decimal Id { get; set; }
        public decimal NumeroProceso { get; set; }
        public string UsuarioBase { get; set; }
        public string UsuarioBancard { get; set; }
        public decimal CantidadEnviado { get; set; }
        public string MensajeResultado { get; set; }
        public DateTime Fecha { get; set; }
        public string NumeroTarjeta { get; set; }
        public string CodigoRetorno { get; set; }
        public decimal? IdSeguimiento { get; set; }
    }
}
