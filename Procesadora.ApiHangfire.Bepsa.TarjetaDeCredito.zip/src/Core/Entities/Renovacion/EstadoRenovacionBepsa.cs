﻿
namespace Continental.API.Core.Entities
{
    public class EstadoRenovacionBepsa
    {
        public string IdEstado;
        public string Estado;
    }
}
