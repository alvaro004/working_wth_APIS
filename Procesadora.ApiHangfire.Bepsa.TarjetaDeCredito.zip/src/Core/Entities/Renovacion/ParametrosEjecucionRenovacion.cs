﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion
{
    public class ParametrosEjecucionRenovacion
    {
        public string Renovacion { get; set; }
        public string ConsultaRenovacion { get; set; }
    }
}
