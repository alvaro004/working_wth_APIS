﻿
using System;

namespace Continental.API.Core.Entities
{
    public class LogReimpresionPrincipalEF
    {
        public decimal LogKey { get; set; }
        public decimal Id { get; set; }
        public string NumeroTarjetaViejo { get; set; }
        public string NumeroTarjetaNuevo { get; set; }
        public decimal ImporteDebitar { get; set; }
        public string CobrarCosto { get; set; }
        public string Vencimiento { get; set; }
        public string FechaValidacion { get; set; }
        public string UsuarioProceso { get; set; }
        public string MotivoTransferencia { get; set; }
        public decimal NumeroProceso { get; set; }
        public string Procesado { get; set; }
        public decimal Enviar { get; set; }
        public int Procesadora { get; set; }
    }
}
