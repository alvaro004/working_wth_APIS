﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class LoteRenovacionBepsaRequest
    {
        [JsonProperty("tarjetaActual")]
        public string TarjetaActual { get; set; }

        [JsonProperty("tarjetaNueva")]
        public string TarjetaNueva { get; set; }

        [JsonProperty("nuevaFechaVencimiento")]
        public string NuevaFechaVencimiento { get; set; }
    }
}