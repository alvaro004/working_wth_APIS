﻿
namespace Continental.API.Core.Entities
{
    public class SeguimientoRenovacion
    {
        public decimal Id { get; set; }
        public decimal NumeroProceso { get; set; }
        public int CantidadIntentos { get; set; }
    }
}
