﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion
{
    public class ParametrosRenovacion
    { 
        public int MaxIntentos { get; set; }
        public bool HabilitaHoraEjecucionRenovacion { get; set; }
        public int HoraRenovacion { get; set; }
        public int MinutoRenovacion { get; set; }
        public bool HabilitaHoraEjecucionConsulta { get; set; }
        public int HoraConsulta { get; set; }
        public int MinutoConsulta { get; set; }

    }
}
