﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Continental.API.Core.Entities
{
    public class RenovacionBepsaRequest
    {
        [JsonProperty("lote")]
        public List<LoteRenovacionBepsaRequest> Lote { get; set; }
    }
}
