﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion
{
    public class TarjetasEntregadasPendientes
    {
        public int Id { get; set; }
        public string FechaEntregada { get; set; }
        public string Tarjeta { get; set; }
        public string Cuenta { get; set; }
    }
}
