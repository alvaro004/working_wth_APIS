﻿namespace Continental.API.Core.Entities
{
    public class PendienteRenovacion
    {
        public decimal NumeroProceso { get; set; }
    }
}
