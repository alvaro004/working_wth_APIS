﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class TarjetaActivacionResponse
    {
        [JsonProperty("codRespuesta")]
        public string Codigo { get; set; }
        [JsonProperty("msgRespuesta")]
        public string Mensaje{ get; set; }
        [JsonProperty("loteRespuesta")]
        public List<LoteTarjetaResponse> Lote { get; set; }
    }
}
