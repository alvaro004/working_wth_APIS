﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class RequestReimpresion
    {
        [JsonProperty("usuario")]
        public string Usuario { get; set; }
        [JsonProperty("clave")]
        public string Clave { get; set; }
        [JsonProperty("lote")]
        public List<LoteReimpresion> Lote { get; set; }
    }
}
