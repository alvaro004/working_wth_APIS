﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class LoteReimpresionRespuesta
    {
        [JsonProperty("codigoRespuesta")]
        public string CodigoRespuesta { get; set; }
        public string Descripcion { get; set; }
        public string Tarjeta { get; set; }
    }
}
