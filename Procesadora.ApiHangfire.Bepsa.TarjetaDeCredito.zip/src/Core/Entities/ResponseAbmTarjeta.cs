﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class ResponseAbmTarjeta
    {
        public int IdSesion { get; set; }
        public string CodRespuesta { get; set; }
        public string MsgRespuesta { get; set; }
    }
}
