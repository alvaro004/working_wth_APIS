﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class TasaInteres
    {
        [JsonProperty("moneda")]
        public string Moneda { get; set; }
        [JsonProperty("tipoTTI")]
        public string TipoTTI { get; set; }
        [JsonProperty("periodoAfectacion")]
        public string PeriodoAfectacion { get; set; }
        [JsonProperty("tasaInteres")]
        public string tasaInteres { get; set; }
    }
}
