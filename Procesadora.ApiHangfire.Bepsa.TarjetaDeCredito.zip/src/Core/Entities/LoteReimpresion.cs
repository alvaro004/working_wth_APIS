﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities
{
    public class LoteReimpresion
    {
        [JsonProperty("tarjeta")]
        public string Tarjeta { get; set; }
        [JsonProperty("tarjetaNueva")]
        public string TarjetaNueva { get; set; }
        [JsonProperty("novedad")]
        public string Novedad { get; set; }
        [JsonProperty("motivo")]
        public int Motivo { get; set; }
        [JsonProperty("fechaVencimiento")]
        public string FechaVencimiento { get; set; }
        [JsonProperty("cobrar")]
        public string Cobrar { get; set; }
        [JsonProperty("importe")]
        public int Importe { get; set; }
        [JsonProperty("tipoPlastico")]
        public string TipoPlastico { get; set; }
        [JsonProperty("nvoTarjetaCmb")]
        public string NuevaTarjetaCombo { get; set; }
        public string CodigoCliente { get; set; }
    }
}
