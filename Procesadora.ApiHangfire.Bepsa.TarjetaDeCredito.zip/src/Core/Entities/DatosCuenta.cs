﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class DatosCuenta
    {
        public string Accion { get; set; }
        public string NroControl { get; set; }
        public string NroCuenta { get; set; }
        public string NombreCuenta { get; set; }
        public string CodigoAfinidad { get; set; }
        public string TipoCuenta { get; set; }
        public string RUCExtracto { get; set; }
        public string EstadoCuenta { get; set; }
        public string TipoCierre { get; set; }
        public string ClienteEntidad { get; set; }
        public string TipoDocumento { get; set; }
        public string NroDocumento { get; set; }
        public string Empresa { get; set; }
        public string Sucursal { get; set; }
        public string TipoDocumentoOficial { get; set; }
        public string NroDocumentoOficial { get; set; }
        public string MotivoRetencionExtracto { get; set; }
        public string MotivoNoImprimirExtracto { get; set; }
        public string TipoCargo { get; set; }
        public string AplicaSeguroVida { get; set; }
        public string Usuario { get; set; }
        public string Valor1 { get; set; }
        public string Valor2 { get; set; }
        public string Valor3 { get; set; }
        public string DescripcionReferencia { get; set; }
        public string Pais { get; set; }
        public string Departamento { get; set; }
        public string Ciudad { get; set; }
        public string Zona { get; set; }
        public string Email { get; set; }
        public string PermiteTrjInnominada { get; set; }
    }
}
