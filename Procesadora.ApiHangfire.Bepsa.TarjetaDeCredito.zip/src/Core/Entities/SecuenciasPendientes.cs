﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Core.Entities
{
    public class SecuenciasPendientes
    {
        public string Numero { get; set; }
    }
}
