﻿using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class ParametricaPagoRechazado : ParametricaPago
    {
        public List<int> Estados { get; set; }

        public string CodigoRespuesta { get; set; }
    }
}
