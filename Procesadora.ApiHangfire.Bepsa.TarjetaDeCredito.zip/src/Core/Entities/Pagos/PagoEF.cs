﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class PagoEF
    {
        public decimal Comprobante { get; set; }

        public string Tarjeta { get; set; }

        public decimal Monto { get; set; }

        public int EstadoPago { get; set; }

        public int Intento { get; set; }

        public int Procesadora { get; set; }

        public string PagoProcesado { get; set; }

        public string OperacionTipo { get; set; }

        public string? FechaDisponible { get; set; }

        public string? FechaExtracto { get; set; }

        public DateTime? FechaPago { get; set; }

        public string? CodigoResuesta { get; set; }

        public string? MensajeRespuesta { get; set; }

        public DateTime? FechaModificacion { get; set; }

        public string? UsuarioRegistro { get; set; }

        public DateTime? FechaRegistro { get; set; }

        public string? Recibo { get; set; }

        public decimal ComprobanteCajaDesc { get; set; }
        
        public string? Reversado { get; set; }
    }
}
