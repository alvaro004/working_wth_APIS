﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class ParametroPagosCancelado
    {
        public int CantidadIntento { get; set; }

        public string De { get; set; }

        public string Asunto { get; set; }

        public string EsHtml { get; set; }

        public string EmailDestino { get; set; }

        public string EmailCopia { get; set; }

        public string Body { get; set; }
    }
}
