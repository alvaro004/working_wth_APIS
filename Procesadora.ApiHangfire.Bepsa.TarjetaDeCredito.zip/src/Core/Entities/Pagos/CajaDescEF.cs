﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class CajaDescEF
    {
        public int Enviado { get; set; }

        public DateTime FechaEnvio { get; set; }

        public string HoraEnvio { get; set; }

        public string UsuarioEnvio { get; set; }

        public string UsuarioRegistro { get; set; }

        public DateTime? FechaRegistro { get; set; }

        public string Operacion { get; set; }

        public decimal Comprobante { get; set; }

        public string Recibo { get; set; }

        public decimal Monto { get; set; }

        public decimal Efectivo { get; set; }

        public int Cheque { get; set; }

        public int Cheque24 { get; set; }

        public int Cheque48 { get; set; }
}
}
