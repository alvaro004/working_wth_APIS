﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class PagoResponse
    {
        [JsonProperty("idSeguimiento")]
        public string IdSeguimiento { get; set; }

        [JsonProperty("procesados")]
        public PagoProcesado Procesados { get; set; }

        [JsonProperty("rechazados")]
        public PagoRechazado Rechazados { get; set; }
    }

    public class PagoProcesado
    {
        [JsonProperty("cantidad")]
        public int Cantidad { get; set; }

        [JsonProperty("nroComprobanteEntidad")]
        public List<string> NumeroCombrobante { get; set; }
    }

    public class PagoRechazado
    {
        [JsonProperty("cantidad")]
        public int Cantidad { get; set; }

        [JsonProperty("nroComprobanteEntidad")]
        public List<string> NumeroCombrobante { get; set; }
    }
}
