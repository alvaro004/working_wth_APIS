﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    internal class EstadoPagoResponse : LotePago
    {
        [JsonProperty("tipoCargoId")]
        public string TipoCargoId { get; set; }

        [JsonProperty("procesado")]
        public string Procesado { get; set; }

        [JsonProperty("motivo")]
        public string Motivo { get; set; }

        [JsonProperty("fechaHoraProceso")]
        public string FechaHoraProceso { get; set; }
    }
}
