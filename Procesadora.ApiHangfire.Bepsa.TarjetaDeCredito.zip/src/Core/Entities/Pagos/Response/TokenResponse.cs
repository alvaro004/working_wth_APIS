﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class TokenResponse
    {
        public string AccessToken { get; set; }
    }
}
