﻿using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class ActualizarPago
    {
        public decimal Comprobante { get; set; }

        public int EstadoPago { get; set; }

        public string PagoProcesado { get; set; }

        public int Intento { get; set; }

        public DateTime FechaDisponible { get; set; }

        public DateTime FechaExtracto { get; set; }

        public DateTime FechaPago { get; set; }

        public DateTime FechaModificacion { get; set; }

        public string CodigoResuesta { get; set; }

        public string MensajeRespuesta { get; set; }
    }
}
