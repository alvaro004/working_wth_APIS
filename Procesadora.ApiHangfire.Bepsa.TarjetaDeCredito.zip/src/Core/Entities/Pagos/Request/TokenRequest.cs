﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class TokenRequest
    {
        [JsonProperty("usuario")]
        public string Usuario { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
