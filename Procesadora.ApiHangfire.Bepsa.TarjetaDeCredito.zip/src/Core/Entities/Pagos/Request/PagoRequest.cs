﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class PagoRequest
    {
        [JsonProperty("lote")]
        public List<LotePago> Lote { get; set; }
    }
}
