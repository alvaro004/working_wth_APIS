﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class ParametricaPago
    {
        public int EstadoPago { get; set; }

        public string PagoProceso { get; set; }

        public int Procesadora { get; set; }

        public string OperacionTipo { get; set; }

        public int Intento { get; set; }

        public int Cantidad { get; set; }

        public int Hilos { get; set; }

        public bool SwitchPagoV2 { get; set; }
    }
}
