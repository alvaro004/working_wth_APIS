﻿using Newtonsoft.Json;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos
{
    public class LotePago
    {
        [JsonProperty("nroComprobanteEntidad")]
        public string Comprobante { get; set; }

        [JsonProperty("nroTarjeta")]
        public string NumeroTarjeta { get; set; }

        [JsonProperty("moneda")]
        public int Moneda { get; set; }

        [JsonProperty("importe")]
        public decimal Importe { get; set; }
    }
}
