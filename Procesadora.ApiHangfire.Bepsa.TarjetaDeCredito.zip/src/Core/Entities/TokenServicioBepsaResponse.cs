﻿using Newtonsoft.Json;

namespace Continental.API.Core.Entities
{
    public class TokenServicioBepsaResponse
    {
        [JsonProperty("accessToken")]
        public string Token { get; set; }
    }
}
