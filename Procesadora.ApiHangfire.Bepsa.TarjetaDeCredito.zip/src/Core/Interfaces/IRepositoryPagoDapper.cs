﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IRepositoryPagoDapper
    {
        Task<string> ConsultarEstadoProceso();

        Task ActualizaEstadoProceso(string estadoProceso);

        Task<PagoEF> ObtenerPago(decimal comprobante);

        Task ActualizarEstadoPago(PagoEF pagoEF);

        Task ActualizarCajaDesc(CajaDescEF cajaDescEF);

        Task<Fechus> Fechus();

        Task EnvioCorreo(string de, string para, string asunto, string copia, string body, string esHtml);

        Task ActualizaMotivoPago(PagoEF pago);

        Task ActualizaEstadoPago(PagoEF pago);
    }
}
