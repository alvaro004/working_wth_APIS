﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IRepositoryTarjetaVirtualDapper
    {
        Task<List<TarjetaVirtualPendiente>> TarjetaVirtualPendiente();

        Task<Contarje> DatosParaContarje(string tarjeta, string cuenta);

        Task GrabarContarje(Contarje contarje);

        Task<PbTarjeta> DatosParaPbTarjeta(string tarjeta, string cuenta);

        Task GrabarPbtarjeta(PbTarjeta pbTarjeta);

        Task<DatosPersona> DatosPersona(string codigoCliente);

        Task<bool> VerificaContarje(string tarjeta);

        Task<bool> VerificaPbTarjeta(string tarjeta);

        Task<string> ObtenerParametrica(int idParametrica, int secuencia);

        Task EnvioPush(string codigCliente, string tipoNotificacion, string mensaje);
        Task InsertarReGrabacionPrincipal(Reimpresion reimpresion);
        Task InsertarReGrabacionPrincipalLog(Reimpresion reimpresion);
        Task InsertarReGrabacionCourier(Reimpresion reimpresion);
        Task<int> ObtenerNuevoIdRegrabacion();
        Task<int> ObtenerNuevoLogKey();
        Task<int> ObtenerNumeroProceso();
        Task<string> ValidarTarjetaInternacional(string afinidad);
        Task<bool> ValidarTarjetaDigitalHibrida(string numeroTarjeta);

    }
}
