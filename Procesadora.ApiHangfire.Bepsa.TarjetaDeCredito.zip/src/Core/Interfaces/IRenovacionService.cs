﻿
using System.Threading;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRenovacionService
    {
        void Renovacion();
        void ConsultaRenovacion();
        void EnviaMail(string nombreProceso, string mensaje, string observacion, string estado, string numeroProceso, string idSeguimiento);
        bool EsDiaDeRenovacion();
        bool ValidarEjecucionServicio(string nombreProceso);
        Task TransmicionCambioVencimiento();
    }
}
