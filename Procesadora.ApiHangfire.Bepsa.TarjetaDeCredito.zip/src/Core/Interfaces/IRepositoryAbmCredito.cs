﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRepositoryAbmCredito
    {
        public List<PendientesEnvio> GetPendientesEnvio();
        public List<DatosCuentaCredito> GetDatosCuenta(double nroProc);
        public List<DatosTarejtaCredito> GetDatosTarjeta(double nroProc);
        List<PendientesEnvio> RealizarProceso();
        public void ActualizaTransmisionCuenta(string idcta, string codaficta, string idsesion, double numeroProceso);
        public void ActualizaTransmisionTarjeta(string nrotarjeta, string idsesion, double numeroProceso);
        public void ActualizaEnvioLoteBepsa(double nroProceso, EstadoEnvio estado, string codigoRespuesta, string mensajeRespuesta);
        public List<Lote> GetLotesMovEspeciales();
        public void ActualizaTransmisionMovEspeciales(string numeroTarjeta, string codRespuesta, string msjRespuesta);
        Task<List<EstadoRegistrosPendientes>> GetTarjetasPendientesEstadoAsync(string tipo);
        Task ActualizaEstadoAsync(float IdSesion,
                                  string Codigo,
                                  string Mensaje,
                                  float LogKey,
                                  string tipoCredito);
        Task<List<LotePagoTC>> GetLotesPagoTC();
        Task ActualizaPagosTcAsync(string numeroTarjeta, string codigoRespuesta, string mensaje, string monto);
        Task<string> ConsultarEstadoProceso();
        Task ActualizaEstadoProceso(string estadoProceso);
        public void EliminaProceso(double nroProceso);

        Task<string> ObtenerParametrica(int idParametrica, int secuencia);
    }
}
