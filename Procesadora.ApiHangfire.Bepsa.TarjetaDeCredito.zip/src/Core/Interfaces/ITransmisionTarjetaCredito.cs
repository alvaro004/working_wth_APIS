﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface ITransmisionTarjetaCredito
    {
        public ResponseAbmTarjeta AltaBajaModificacionTarjetacredito();
        public string ConexionAutenticacion(KeyToken credenciales);
        public ResponseAbmTarjeta ConexionAbmTarjetasCredito(RequestConexionServicioCredito request, KeyToken credenciales);
        public ResponseMovEspeciales ConexionMovimientosEspeciales(RequestEnvioMovEspeciales request);
        public ResponseMovEspeciales TransmisionMovimientosEspeciales();
        public CuentaActivacionResponse ActivacionCuentaTarjetaCredito();
        public CuentaActivacionResponse ConexionActivacionCuentaTarjeta(RequestConexionServicioActivacion request);
        public TarjetaActivacionResponse ActivacionTarjetasCreditos();
        public TarjetaActivacionResponse ConexionActivacionTarjetasCredito(RequestConexionServicioActivacionTarjeta request);
        public ResponseReimpresion ConexionReimpresion(RequestReimpresion request);
        public ResponseReimpresion TransmisionReimpresion();
        Task<EstadoTransmisionesResponse> EstadoTransmisionAsync();
        public Task<ResponsePagoTC> PagosTarjetaAsync();
        public void ModificarEstadoProceso(string estadoProceso);
    }
}
