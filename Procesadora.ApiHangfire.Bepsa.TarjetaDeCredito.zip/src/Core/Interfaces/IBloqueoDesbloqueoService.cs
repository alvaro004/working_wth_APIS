﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IBloqueoDesbloqueoService
    {
        Task<DefaultResponse> BloqueosAsync();
        Task<DefaultResponse> DesbloqueosAsync();
        Task<DefaultResponse> BloqueosWaledAsync();
        Task<DefaultResponse> DesbloqueosWaledAsync();
    }
}
