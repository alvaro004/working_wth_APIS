﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Reversos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IRepositoryPagoEF
    {
        Task<List<LotePago>> ObtenerPagosPendientes(ParametricaPago parametricaPago);

        Task<PagoEF> ObtenerPago(decimal comprobante);

        Task ActualizarEstadoPago(PagoEF pagoEF);

        Task<Fechus> Fechus();

        Task ActualizarCajaDesc(CajaDescEF cajaDescEF);

        Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia);

        Task<IEnumerable<decimal>> PagosRechazados(ParametricaPagoRechazado parametricaPagoRechazado);

        Task<List<RequestReverso>> ObtenerReversossPendientes(ParametricaPago parametricaPago, DateTime fecha);

        Task ActualizarEstadoReverso(PagoEF pagoEF);
    }
}
