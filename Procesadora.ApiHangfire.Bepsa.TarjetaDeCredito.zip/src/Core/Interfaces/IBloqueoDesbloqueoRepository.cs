﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IBloqueoDesbloqueoRepository
   {
        Task<List<SolicitudBloqueo>> GetBloqueosPendientesAsync();
        Task InsertarLogEnvioAsync(string numeroProceso, string usuarioBepsa, string mensajeRetorno);
        Task ActualizarRegistroBloqueoAsync(string numeroProceso, string codigoRetorno);
        void EnviarEmailBloqueo(EmailBloqueoDesbloqueo emailBloqueo);
        string GetCantidadIntentos(string nroProceso);
        Task ActualizarEstadoBloqueoAsync(string numeroProceso, decimal estado);
        Task<List<SolicitudDesbloqueo>> GetDesbloqueosPendientesAsync();
        Task<List<SolicitudDesbloqueo>> GetDesbloqueosPendientesWaledAsync();
        Task<List<SolicitudBloqueo>> GetBloqueosPendientesWaledAsync();
        Task<bool> EsWaledAsync(string numeroTarjeta);
        string EnmascararTarjeta(string numeroTarjeta);
        string CapitalizarPrimeraLetra(string texto);
    }
}
