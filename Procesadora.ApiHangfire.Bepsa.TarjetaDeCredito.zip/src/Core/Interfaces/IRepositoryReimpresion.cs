﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRepositoryReimpresion
    {
        public List<PendientesReimpresion> GetPendientesReenvio();
        public List<LoteReimpresion> GetLotesReimpresion(double numeroProceso);
        public void ActualizaTransmisionReimpresion(string tarjetaActual);
        public void GetNuevoProcesoReimpresion();
        public void InsertaLogProceso(double numeroProceso,double cantidadRegistros,string mensajeResultado,string codigoResultado,string numeroTarjeta);
        public void ActualizaDatosEnvio(double numeroProceso, string estadoEnvio);
        public void ErrorTransmision(double numeroProceso, string mensajeResultado);
    }
}
