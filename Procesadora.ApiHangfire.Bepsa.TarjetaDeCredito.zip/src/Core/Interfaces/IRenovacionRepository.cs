﻿using Continental.API.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRenovacionRepository
    {
        string GetEsDiaDeRenovacion();
        List<PendienteRenovacion> GetNumeroProcesoPendientesReenvio();
        void GetNuevoProcesoRenovacion();
        List<LoteRenovacionBepsaRequest> GetLotesReimpresion(decimal numeroProceso);
        void ActualizaTransmisionReimpresion(string tarjetaActual);
        void GeneraMail(string asuntoMail, string cuerpoMail);
        void ActualizaDatosEnvio(decimal numeroProceso, decimal idSeguimiento, string estadoEnvio);
        void InsertaLogProceso(decimal numeroProceso, decimal idSeguimiento, decimal cantidadRegistros, string codigoResultado, string mensajeResultado, string numeroTarjeta);
        Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia, string switchParametro);
        Task<List<SeguimientoRenovacion>> GetSeguimientosPendientes(int maxIntentos);
        void ActualizarCantidadIntento(decimal idSeguimiento);
        Task<List<TarjetasEntregadasPendientes>> ObtenerTarjetasEntregadas();
        Task ActualizarTarjetaEntregada(LoteCambioVencimiento loteCambioVencimiento);
    }
}
