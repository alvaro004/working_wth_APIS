﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRepositoryActivacion
    {
        public List<SecuenciasPendientes> GetPendientesEnvio();
        public List<SecuenciasPendientes> GetTarjetasPendientesEnvio();
        public List<CuentaTarjeta> GetDatosCuentaTarjetaCredito();
        public List<DatosTarjeta> GetDatosTarjetaCredito();
        public void EstadoCtaTarActivacion(double numeroCuenta, EstadoActivacion estado, string mensaje);
        public void SetEstadoNroRegistro(double secuencia, EstadoActivacion estado, string webServiceMensaje);
        public List<SucursalTarjeta> GetSucursalActivacion(string tarjeta, string digitoVerificador);
        public void ConfirmaActivacion(string numeroTarjeta, string digitoVerificador, string numeroCuenta, string sucursal);
        public void EnviaCorreos(string numeroTarjeta, EstadoActivacion tipoCorreo, string mensajeResp, double nroSecuen);
        public List<NumeroCuentaTarjeta> GetNumeroCuentaTarjeta(double nroProc);
        public List<SecuenciasPendientes> GetNumeroSecuencia(string tarjeta);
    }
}
