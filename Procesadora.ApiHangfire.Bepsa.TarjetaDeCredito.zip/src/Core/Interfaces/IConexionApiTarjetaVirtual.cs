﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IConexionApiTarjetaVirtual
    {
        Task<HttpResponseMessage> InvocarServicios(EnumUrl url,
                                                   EnumMethods methods,
                                                   dynamic bodyParam,
                                                   HttpMethod httpMethod,
                                                   Dictionary<string, string> headers);

        Task<HttpResponseMessage> InvocarGetConBody(EnumUrl url,
                                                    EnumMethods methods,
                                                    dynamic bodyParam,
                                                    Dictionary<string, string> headers);
    }
}
