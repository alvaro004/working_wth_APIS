﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces
{
    public interface IConexionApi
    {
        public Task<WebToken> ConexionAutenticacion(KeyToken credenciales);
        public Task<ResponseAbmTarjeta> ConexionAbmTarjetasCredito(RequestConexionServicioCredito request, string token, KeyToken credenciales);
        public Task<ResponseMovEspeciales> ConexionMovimientosEspeciales(RequestEnvioMovEspeciales request, KeyToken credenciales);
        public Task<ResponseAbmTarjeta> EjecutarServicioCredito(RequestAbmCredito parametrosBepsa, KeyToken credenciales);
        public Task<CuentaActivacionResponse> ConexionActivacionCuentaTarjeta(RequestConexionServicioActivacion request, KeyToken credenciales);
        public Task<TarjetaActivacionResponse> ConexionActivacionTarjetasCredito(RequestConexionServicioActivacionTarjeta request, KeyToken credenciales);
        public Task<ResponseReimpresion> ConexionReimpresion(RequestReimpresion request, KeyToken credenciales);
        Task<EstadoTransmisionesResponse> EjecutarServicioAbmErroresAsync(AbmEstadoErroresRequest requestAbmErrores, KeyToken credenciales);
        Task<ResponsePagoTC> ConexionPagoTarjetaCreditoAsync(RequestPagoTC request, KeyToken credenciales);
        public Task<BloqueoDesbloqueoResponse> EjecutarServicioBloqueoTCAsync(BloqueoDesbloqueoRequest requestBloqueoTD, KeyToken credenciales);
        public Task<BloqueoDesbloqueoResponse> EjecutarServicioDesbloqueoTCAsync(BloqueoDesbloqueoRequest desbloqueoRequest, KeyToken credenciales);
        public Task<RenovacionBepsaResponse> TransmisionRenovacionBepsa(RenovacionBepsaRequest request);
        public Task<string> ConexionObtenerTokenServicioBepsaAsync(string nombreProcesoService, KeyToken credenciales);
        public Task<RenovacionBepsaResponse> ConexionTransmisionRenovacionBepsaAsync(string TokenServicioBepsa, RenovacionBepsaRequest request);
        public Task<ConsultaRenovacionBepsaResponse> ConsultaRenovacionBepsa(decimal idSeguimiento);
        public Task<ConsultaRenovacionBepsaResponse> ConexionConsultaRenovacionBepsaAsync(string TokenServicioBepsa, decimal IdSeguimiento);
        public Task<ResponseCambioVencimiento> ConexionCambioVencimiento(RequestCambioVencimiento request, KeyToken credenciales);

    }
}
