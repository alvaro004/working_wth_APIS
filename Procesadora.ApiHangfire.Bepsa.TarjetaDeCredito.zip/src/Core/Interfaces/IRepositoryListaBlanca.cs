﻿using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Continental.API.Core.Interfaces
{
    public interface IRepositoryListaBlanca
    {
        Task<List<DatosListaBlanca>> ObtenerListaPendientes(ParametricaListaBlanca parametrica);
        Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia);
        Task<string> ObtenerNumeroDocumento(string NumeroTarjeta, string digito);
        Task<string> ObtenerNroDocumentoTd(string NumeroTarjeta);
        Task ActualizaEstadoListaBlanca(DatosListaBlanca dato);
        Task<DatosListaBlanca> ObtenerOperacionPendiente(decimal id);
    }
}
