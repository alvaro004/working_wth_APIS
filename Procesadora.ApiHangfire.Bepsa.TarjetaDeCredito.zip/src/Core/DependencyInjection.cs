﻿using Continental.API.Core.Interfaces;
using Continental.API.Core.Services;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Commands;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Services;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Workers;
using System;
using System.Net.Http;

namespace Continental.API.Core
{
    public static class DependencyInjection
    {
        public static IServiceCollection AgregarCore(this IServiceCollection services)
        {
            services.AddTransient<ProcesoServices>();
            services.AddTransient<PagoCommandHandler>();
            services.AddTransient<EstadoPagoCommandHandler>();
            services.AddTransient<TarjetaVirtualCommandHandler>();
            services.AddTransient<ReversosCommandHandler>();
            services.AddTransient<ListaBlancaCommandHandler>();
            services.AddTransient<BajaListaBlancaCommand>();
            services.AddTransient<ITransmisionTarjetaCredito, ProcesoServices>();
            services.AddTransient<IBloqueoDesbloqueoService, BloqueoDesbloqueoService>();
            services.AddTransient<IConexionApiPago, ConexionApiPago>();
            services.AddTransient<IConexionApiTarjetaVirtual, ConexionApiTarjetaVirtual>();
            services.AddTransient<IRenovacionService, RenovacionService>();
            services.AddScoped<IScopedProcessingService, ScopedProccessingService>();
            services.AddMediatR(AppDomain.CurrentDomain.GetAssemblies());
            services.AddHttpClient("ConexionApiPago")
                    .ConfigurePrimaryHttpMessageHandler(h =>
                    {
                        var handler = new HttpClientHandler
                        {
                            ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
                        };
                        return handler;
                    });
            services.AddHttpClient("TarjetaVirtual")
                    .ConfigurePrimaryHttpMessageHandler(h =>
                    {
                        var handler = new HttpClientHandler
                        {
                            ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
                        };
                        return handler;
                    });
            return services;
        }
    }
}
