﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Continental.API.Core.Entities;
using Continental.API.Core.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Continental.API.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/EnviosTarjetaCredito")]
    public class AbmCreditoController : BaseApiController 
    {
        private readonly IMapper mapper;
        private readonly ILogger<AbmCreditoController> _logger;
        private readonly ProcesoServices jobsServices;
        public AbmCreditoController(ILogger<AbmCreditoController> logger, ProcesoServices service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Alta, Baja y Modificación de Tarjetas de Crédito
        /// </summary>
        /// <returns>Finalización del proceso</returns>
        [HttpPost]
        public IActionResult JobsAbmTarjetaCredito()
        {
            try 
            {
                _logger.LogInformation("Inicio de conexion a servicio Abm Jobs credito Bepsa {0}");
                ResponseAbmTarjeta respuesta = jobsServices.AltaBajaModificacionTarjetacredito();
                return Ok("00");
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "Ocurrio un error al ejecuta transmision de abm creditos.");

                return BadRequest($"Ocurrio un error: {ex.Message}");
            }
        }

    }
}
