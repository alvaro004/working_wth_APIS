﻿using Continental.API.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.WebApi.Controllers.V1
{

    [Route("v{version:apiVersion}/api/bepsa/tarjetas/credito/transmision/")]
    public class BloqueoDesbloqueoController : BaseApiController
    {
        private readonly ILogger<BloqueoDesbloqueoController> _logger;
        private readonly IBloqueoDesbloqueoService jobsServices;
        public BloqueoDesbloqueoController(ILogger<BloqueoDesbloqueoController> logger, IBloqueoDesbloqueoService service)
        {
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Proceso para transmitir el bloqueo de tarjetas de crédito Bepsa.
        /// </summary>
        /// <returns>Respuesta de finalización del proceso</returns>
        [HttpPost("bloqueo")]

        public async Task<IActionResult> JobTransmisionBloqueo()
        {
            try
            {
                _logger.LogInformation("BloqueoBepsaTC - Inicio de conexion a servicio de Transmision de Bloqueos de Tarjetas Bepsa");
                DefaultResponse respuesta = await jobsServices.BloqueosAsync();

                _logger.LogInformation("BloqueoBepsaTC - Fin de conexion a servicio de Transmision de Bloqueos de Tarjetas Bepsa. Respuesta : {@respuestaBloqueoTC}",
                                      respuesta);
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };
                if (ex.StatusCode == 200)
                {
                    _logger.LogInformation(ex, "BloqueoBepsaTC - {@responseBloqueoTC} ", response);                  
                }
                else
                { 
                    _logger.LogError(ex, "BloqueoBepsaTC - Ocurrio un error al transmitir los Bloqueos de Tarjetas Bepsa, intente nuevamente. {@ErrorResponseBloqueoTC} ", response);
                }
                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = 99,
                    Mensaje = "BloqueoBepsaTC - Error Interno."
                };
                _logger.LogError(ex, "BloqueoBepsaTC - Ocurrió un error de sistema. Response: {@ErrorResponseBloqueoTC}", response);
                return StatusCode(500, response);
            }
        }

        /// <summary>
        /// Proceso de Bloqueo para tarjetas E-club
        /// </summary>
        /// <returns>Finalización del proceso</returns>
        [HttpPost("bloqueoWaled")]

        public async Task<IActionResult> JobTransmisionBloqueoWaled()
        {
            try
            {
                _logger.LogInformation("BloqueoWaledTC - Inicio de conexion a servicio de Transmision de Bloqueos de Tarjetas E-club");
                DefaultResponse respuesta = await jobsServices.BloqueosWaledAsync();

                _logger.LogInformation("BloqueoWaledTC - Fin de conexion a servicio de Transmision de Bloqueos de Tarjetas E-club. Respuesta : {@respuestaBloqueoTC}",
                                      respuesta);
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };
                if (ex.StatusCode == 200)
                {
                    _logger.LogInformation(ex, "BloqueoWaledTC - {@responseBloqueoTC} ", response);
                }
                else
                {
                    _logger.LogWarning(ex, "BloqueoWaledTC - Ocurrio un error al transmitir los Bloqueos de Tarjetas Bepsa, intente nuevamente. {@ErrorResponseBloqueoTC} ", response);
                }
                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = 99,
                    Mensaje = "BloqueoWaledTC - Error Interno."
                };
                _logger.LogError(ex, "BloqueoWaledTC- Ocurrió un error de sistema. Response: {@ErrorResponseBloqueoTC}", response);
                return StatusCode(500, response);
            }
        }

        /// <summary>
        /// Proceso de transmisión de desbloqueo para tarjetas de crédito Bepsa
        /// </summary>
        /// <returns>Finalización del proceso de transmisión</returns>
        [HttpPost("desbloqueo")]

        public async Task<IActionResult> JobTransmisionDesbloqueo()
        {
            try
            {
                _logger.LogInformation("DesbloqueoBepsaTC - Inicio de conexion a servicio de Transmision de Desbloqueos de Tarjetas Bepsa");
                DefaultResponse respuesta = await jobsServices.DesbloqueosAsync();

                _logger.LogInformation("DesbloqueoBepsaTC - Fin de conexion a servicio de Transmision de Desbloqueos de Tarjetas Bepsa. Respuesta : {@respuestaDesbloqueoTC}",
                                      respuesta);
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };
                if (ex.StatusCode == 200)
                {
                    _logger.LogInformation(ex, "DesbloqueoBepsaTC - {@responseDesbloqueoTC} ", response);
                }
                else
                {
                    _logger.LogError(ex, "DesbloqueoBepsaTC - Ocurrio un error al transmitir los Desbloqueos de Tarjetas Bepsa, intente nuevamente. {@ErrorResponseDesbloqueoTC} ", response);
                }
                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = 99,
                    Mensaje = "DesbloqueoBepsaTC - Error Interno."
                };
                _logger.LogError(ex, "DesbloqueoBepsaTC - Ocurrió un error de sistema. Response: {@ErrorResponseDesbloqueoTC}", response);
                return StatusCode(500, response);
            }
        }

        /// <summary>
        /// Proceso de  transmisión de desbloqueo para tarjetas E-club
        /// </summary>
        /// <returns>Finalización del proceso de transmisión</returns>
        [HttpPost("desbloqueoWaled")]

        public async Task<IActionResult> JobTransmisionDesbloqueoWaled()
        {
            try
            {
                _logger.LogInformation("DesbloqueoWaledTC - Inicio de conexion a servicio de Transmision de Desbloqueos de Tarjetas E-club");
                DefaultResponse respuesta = await jobsServices.DesbloqueosWaledAsync();

                _logger.LogInformation("DesbloqueoWaledTC - Fin de conexion a servicio de Transmision de Desbloqueos de Tarjetas E-club. Respuesta : {@respuestaDesbloqueoTC}",
                                      respuesta);
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };
                if (ex.StatusCode == 200)
                {
                    _logger.LogInformation(ex, "DesbloqueoWaledTC - {@responseDesbloqueoTC} ", response);
                }
                else
                {
                    _logger.LogWarning(ex, "DesbloqueoWaledTC - Ocurrio un error al transmitir los Desbloqueos de Tarjetas E-club, intente nuevamente. {@ErrorResponseDesbloqueoTC} ", response);
                }
                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = 99,
                    Mensaje = "DesbloqueoWaledTC - Error Interno."
                };
                _logger.LogError(ex, "DesbloqueoWaledTC - Ocurrió un error de sistema. Response: {@ErrorResponseDesbloqueoTC}", response);
                return StatusCode(500, response);
            }
        }
    }
}
