﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Continental.API.Core.Entities;
using Continental.API.Core.Interfaces;
using Continental.API.Core.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Continental.API.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/tarjeta/credito/")]
    public class ActivacionController : BaseApiController 
    {
        private readonly IMapper mapper;
        private readonly ILogger<ActivacionController> _logger;
        private readonly ITransmisionTarjetaCredito jobsServices;
        public ActivacionController(ILogger<ActivacionController> logger, ITransmisionTarjetaCredito service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Activación de cuenta Tarjeta Crédito.
        /// </summary>
        /// <returns>Finalización de proceso</returns>
        [HttpPost("cuenta/activacion")]
        public IActionResult JobsActivacionCuentaTarjetaCredito()
        {
            try 
            {
                _logger.LogInformation("Inicio de conexion a servicio Activación Cuenta de Tarjeta Crédito Bepsa {0}");
                CuentaActivacionResponse respuesta = jobsServices.ActivacionCuentaTarjetaCredito();
                _logger.LogInformation("Fin de conexion a servicio Activación Cuenta de Tarjeta Crédito Bepsa {0}");
                return Ok(new
                {
                    Codigo = 0,
                    Mensaje = "Activacion de cuentas procesadas correctamente."
                } );
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "Ocurrio un error al ejecutar transmision de Activación de Cuenta de Tarjeta Crédito.");

                return BadRequest(new
                {
                    Codigo = 99,
                    Mensaje = "Error interno de la API de Activacion de Cuentas."
                });
            }
        }

        /// <summary>
        /// Activación de Tarjetas de Crédito.
        /// </summary>
        /// <returns>Finalización del proceso</returns>
        [HttpPost("activacion")]
        public IActionResult JobsActivacionTarjetaCredito()
        {
            try
            {
                _logger.LogInformation("Inicio de conexion a servicio Activación de Tarjeta Crédito Bepsa {0}");
                TarjetaActivacionResponse respuesta = jobsServices.ActivacionTarjetasCreditos();
                _logger.LogInformation("Fin de conexion a servicio Activación Cuenta de Tarjeta Crédito Bepsa {0}");
                return Ok(new
                {
                    Codigo = 0,
                    Mensaje = "Activacion de tarjetas procesadas correctamente."
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ocurrio un error al ejecutar transmision de Activación de Tarjeta Crédito.");

                return BadRequest(new
                {
                    Codigo = 99,
                    Mensaje = "Error interno de la API de Activacion de Tarjetas de Credito."
                });
            }
        }
    }
}
