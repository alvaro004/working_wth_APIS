﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Continental.API.Core.Services;
using Continental.API.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/tarjeta/credito/movimientoEspecial/transmision")]
    public class MovimientoEspecialController : BaseApiController
    {
        private readonly IMapper mapper;
        private readonly ILogger<MovimientoEspecialController> _logger;
        private readonly ProcesoServices jobsServices;
        public MovimientoEspecialController(ILogger<MovimientoEspecialController> logger, ProcesoServices service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Transmisión de movimientos especiales.
        /// </summary>
        /// <returns>finalización de la transmisión</returns>
        [HttpPost]
        public IActionResult TransmisionMovimientoEspecial()
        {
            try
            {
                _logger.LogInformation("MovimientosEspeciales - Inicio de conexion a servicio movimientos especiales Bepsa {0}");
                ResponseMovEspeciales respuesta = jobsServices.TransmisionMovimientosEspeciales();
                return Ok("00");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "MovimientosEspeciales - Ocurrio un error al ejecuta transmision de abm creditos.");

                return BadRequest($"Ocurrio un error");
            }
        }
    }
}
