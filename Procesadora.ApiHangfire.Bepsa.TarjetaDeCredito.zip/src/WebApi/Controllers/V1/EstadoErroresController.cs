﻿using AutoMapper;
using Continental.API.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using System;
using System.Threading.Tasks;

namespace Continental.API.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/transmisiones/credito/")]
    public class EstadoErroresController : BaseApiController 
    {
        private readonly IMapper mapper;
        private readonly ILogger<AbmCreditoController> _logger;
        private readonly ITransmisionTarjetaCredito jobsServices;
        public EstadoErroresController(ILogger<AbmCreditoController> logger, ITransmisionTarjetaCredito service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Metodo que actualiza los estados de las transmisiones de TC.
        /// </summary>
        /// <returns>Retorna Codigo y Mensaje de respuesta.</returns>
        [HttpPost("estado")]
        [ProducesResponseType(typeof(EstadoTransmisionesResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> JobsEstado()
        {
            try 
            {
                _logger.LogInformation("Inicio de conexion a servicio AbmErrores de Tarjeta Crédito y Cuenta Crédito Bepsa");
                EstadoTransmisionesResponse respuesta = await jobsServices.EstadoTransmisionAsync();
                _logger.LogInformation("Fin de conexion a servicio AbmErrores de Tarjeta Crédito Bepsa");
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };
                _logger.LogError(ex, "Ocurrio un error al ejecutar el servicio, intente nuevamente. {@response} ", response);
                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ocurrio un error al ejecutar el servicio AbmErrores de Tarjeta Crédito Bepsa.");
                return StatusCode(500, new ErrorResponse
                {
                    ErrorType = ErrorType.error_interno_servidor,
                    ErrorDescription = "Ocurrio un error al momento de ejecutar el servicio AbmErrores de Tarjeta Crédito Bepsa."
                });
            }
        }

    }
}
