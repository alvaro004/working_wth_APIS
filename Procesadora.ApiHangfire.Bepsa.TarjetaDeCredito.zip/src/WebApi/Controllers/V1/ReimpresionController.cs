﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Continental.API.Core.Entities;
using Continental.API.Core.Interfaces;
using Continental.API.Core.Services;
using Continental.API.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;

namespace Continental.API.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/tarjeta/credito/")]
    public class ReimpresionController : BaseApiController
    {
        private readonly IMapper mapper;
        private readonly ILogger<ReimpresionController> _logger;
        private readonly ITransmisionTarjetaCredito jobsServices;
        public ReimpresionController(ILogger<ReimpresionController> logger, ITransmisionTarjetaCredito service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Proceso de reimpresión de tarjetas de crédito.
        /// </summary>
        /// <returns>Finalización del proceso</returns>
        [HttpPost("reimpresion")]
        public IActionResult JobsReimpresionTarjetaCredito()
        {
            try
            {
                _logger.LogInformation("Inicio de conexion a servicio Reimpresión de Tarjeta Crédito Bepsa {0}");
                ResponseReimpresion respuesta = jobsServices.TransmisionReimpresion();
                _logger.LogInformation("Fin de conexion a servicio Reimpresión de Tarjeta Crédito Bepsa {0}");
                return Ok(new
                {
                    Codigo = 0,
                    Mensaje = "Reimpresión de tarjetas de crédito procesadas correctamente."
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ocurrio un error al ejecutar transmision de Reimpresión de Tarjeta Crédito.");

                return BadRequest(new
                {
                    Codigo = 99,
                    Mensaje = "Error interno de la API de Reimpresión de Tarjetas de Crédito."
                });
            }
        }
    }
}