﻿using AutoMapper;
using Continental.API.Core.Interfaces;
using Continental.API.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.ApiException;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using System;
using System.Threading.Tasks;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.WebApi.Controllers.V1
{
    [Route("v{version:apiVersion}/api/bepsa/")]
    public class PagosTarjetaController : BaseApiController
    {
        private readonly IMapper mapper;
        private readonly ILogger<MovimientoEspecialController> _logger;
        private readonly ITransmisionTarjetaCredito jobsServices;
        public PagosTarjetaController(ILogger<MovimientoEspecialController> logger, ITransmisionTarjetaCredito service, IMapper _mapper)
        {
            mapper = _mapper;
            _logger = logger;
            jobsServices = service;
        }

        /// <summary>
        /// Proceso de transmisión de pago de tarjetas.
        /// </summary>
        /// <returns>Finalización del proceso</returns>
        [HttpPost("PagosTarjeta")]

        public async Task<IActionResult> JobsTransmision ()
        {
            try
            {
                _logger.LogInformation("ServicioPagoTC - Inicio de conexion a servicio de Pagos TC Bepsa");
                ResponsePagoTC respuesta = await jobsServices.PagosTarjetaAsync();

                _logger.LogInformation("Fin de conexion a servicio de Pagos TC Bepsa. Respuesta : {@respuesta}",
                                      respuesta);
                return Ok(respuesta);
            }
            catch (ApiException ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = ex.CodigoError,
                    Mensaje = ex.Mensaje
                };

                if (ex.StatusCode != 200)
                {
                    //Si por A O B motivo, exploto la api de bepsa o algo similar, vamos a liberar el servicio para que no quede pegado con estado ocupado
                    jobsServices.ModificarEstadoProceso(EstadoProceso.Disponible);
                    _logger.LogError(ex, "Ocurrio un error al transmitir los Pagos de TC, intente nuevamente. {@response} ", response);
                }

                _logger.LogInformation(ex, "ServicioPagoTC - {@response} ", response);

                return StatusCode(ex.StatusCode, response);
            }
            catch (Exception ex)
            {
                var response = new ApiBepsaError
                {
                    Codigo = 99,
                    Mensaje = "ServicioPagoTC - Error Interno."
                };

                //Si por A O B motivo, exploto la api de bepsa o algo similar, vamos a liberar el servicio para que no quede pegado con estado ocupado
                jobsServices.ModificarEstadoProceso(EstadoProceso.Disponible);

                _logger.LogError(ex, "ServicioPagoTC - Ocurrió un error de sistema. Response: {@response}", response);
                return StatusCode(500, response);
            }
        }
    }
}
