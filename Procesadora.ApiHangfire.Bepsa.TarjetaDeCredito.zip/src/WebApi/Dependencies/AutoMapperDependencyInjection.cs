﻿using System;
using AutoMapper;
using Continental.API.Core.Entities;
using Microsoft.Extensions.DependencyInjection;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;

namespace Continental.API.WebApi.Dependencies
{
    public static class AutoMapperDependencyInjection
    {
        public static IServiceCollection AgregarAutoMapper(this IServiceCollection services)
        {
            // Auto Mapper Configurations
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            var mapper = mappingConfig.CreateMapper();

            return services.AddSingleton(mapper);
        }
    }
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<RequestAbmCredito, RequestConexionServicioCredito>().ReverseMap();
            CreateMap<RequestPersonas, DatosPersonas>().ReverseMap();
            CreateMap<RequestCuenta, DatosCuentaCredito>().ReverseMap();
            CreateMap<RequestTarjeta, DatosTarejtaCredito>().ReverseMap();
            CreateMap<DetalleBloqueo, SolicitudBloqueo>().ReverseMap();
            CreateMap<SolicitudBloqueo, DetalleBloqueo>().ReverseMap();
            CreateMap<DetalleDesbloqueo, SolicitudDesbloqueo>().ReverseMap();
            CreateMap<SolicitudDesbloqueo, DetalleDesbloqueo>().ReverseMap();
            CreateMap<SolicitudDesbloqueo, DetalleBloqueo>().ReverseMap();
        }
    }
}
