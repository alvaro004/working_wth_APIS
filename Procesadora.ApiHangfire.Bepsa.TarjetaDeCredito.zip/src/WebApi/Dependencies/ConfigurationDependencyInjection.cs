﻿using Continental.API.Core.Interfaces;
using Continental.API.Core.Services;
using Continental.API.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Services;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories;

namespace Continental.API.WebApi.Dependencies
{
    public static class ConfigurationDependencyInjection
    {
        public static IServiceCollection AgregarConfiguraciones(this IServiceCollection services, IConfiguration configuration)
        {
            // mapeo de configuracion a objeto -> capa Infraestructura
            services.Configure<Infrastructure.Settings.Configuraciones>(configuration.GetSection("Configuraciones"));

            // mapeo de configuracion a objeto -> capa Infraestructura
            services.Configure<Core.Entities.ConfiguracionesCore>(configuration.GetSection("Configuraciones"));

            services.AddHttpClient<IRepositoryAbmCredito, RepositoryAbmCredito>();
            services.AddHttpClient<ProcesoServices>();
            services.AddHttpClient<IRepositoryActivacion, RepositoryActivacion>();
            services.AddHttpClient<IRepositoryReimpresion, RepositoryReimpresion>();
            services.AddHttpClient<IConexionApi, ConexionApi>();
            services.AddHttpClient<IRenovacionRepository, RenovacionRepository>();
            services.AddHttpClient<IRepositoryListaBlanca, RepositoryListaBlanca>();
            return services;
        }
    }
}