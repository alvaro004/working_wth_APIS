using System;
using System.Collections.Generic;
using Continental.API.Core.Interfaces;
using Continental.API.Core.Enums;
using Hangfire;
using Hangfire.MemoryStorage;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Continental.API.WebApi.Dependencies
{
    public static class HangFireDependencyInjection
    {
        private const string ConfigSection = "HangFire";

        public static IServiceCollection AgregarHangFire(this IServiceCollection services)
        {
            services.AddHangfire(config =>
                config.SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseDefaultTypeSerializer()
                .UseMemoryStorage())
                .AddHangfireServer(op => op.SchedulePollingInterval = System.TimeSpan.FromMilliseconds(50000));
            
            return services;
        }

        public static void AgregarTareaRecurrente(this IApplicationBuilder app, IConfiguration configuration)
        {
            using var scope = app.ApplicationServices.CreateScope();
            var recurringJobManager = scope.ServiceProvider.GetService<IRecurringJobManager>();
            var serviceProvider = scope.ServiceProvider.GetRequiredService<IRenovacionService>();
            var hangFireConfigList = new List<HangFireOption>();
            configuration.GetSection(ConfigSection).Bind(hangFireConfigList);

            foreach (var HangItems in hangFireConfigList)
            {
                if (HangItems.Estado)
                {
                    if (HangItems.Key == TareasRecurrentes.Renovacion.ToString())
                    {

                        recurringJobManager.AddOrUpdate(
                            HangItems.Descripcion,
                            () => serviceProvider.Renovacion(),
                            HangItems.Cron,
                            TimeZoneInfo.Local);
                    }
                    else if (HangItems.Key == TareasRecurrentes.ConsultaRenovacion.ToString())
                    {
                        if (HangItems.Estado)
                        {
                            recurringJobManager.AddOrUpdate(
                                HangItems.Descripcion,
                                () => serviceProvider.ConsultaRenovacion(),
                                HangItems.Cron,
                                TimeZoneInfo.Local);
                        }
                        else
                        {
                            recurringJobManager.RemoveIfExists(HangItems.Descripcion);
                        }
                    }
                    else if (HangItems.Key == TareasRecurrentes.CambioVencimiento.ToString())
                    {
                        if (HangItems.Estado)
                        {
                            recurringJobManager.AddOrUpdate(
                                HangItems.Descripcion,
                                () => serviceProvider.TransmicionCambioVencimiento(),
                                HangItems.Cron,
                                TimeZoneInfo.Local);
                        }
                        else
                        {
                            recurringJobManager.RemoveIfExists(HangItems.Descripcion);
                        }
                    }
                }
                else
                {
                    recurringJobManager.RemoveIfExists(HangItems.Descripcion);
                }
            }
        }
    }
    public class HangFireOption
    {
        public string? Key { get; set; }

        public string? Descripcion { get; set; }

        public string? Cron { get; set; }

        public bool Estado { get; set; }        

    }
}