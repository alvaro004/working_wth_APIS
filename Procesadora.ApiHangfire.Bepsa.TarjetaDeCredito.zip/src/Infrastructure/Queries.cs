﻿namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure
{
    public static class Queries
    {
        public static string ActualizaTransmisionMovimiento =>
            @"update tarjeta.logmovesp_bpsa c
                set c.cod_rpta_transmision = :codigoRespuesta,
                c.msj_rpta_transmision = :mensajeRespuesta,
                c.log_procsa = 'S'
                where c.log_numtar || c.log_digveri = :nroTarjeta 
                and c.log_procsa = 'N'
                and c.log_intentos > 0";

        public static string ListaTransmisionPagos =>
          @"select *
                    from (select p.tarjeta NumeroTarjeta,
                                 600 Moneda,
                                 trim(to_char(p.fecha_registro, 'YYYYMMDD')) FechaAfectacion,
                                 decode(sign(p.monto), -1, abs(p.monto), 1, -abs(p.monto), 0) Importe,
                                 39 TipoCargoId,
                                 'S' InformaExtracto,
                                 'S' AfectaDisponible,
                                 'ENT' OrigenMovimiento,
                                 'APP' DispositivoId,
                                 0 CampoReservado
                         from tarjeta.tarcrd_pagos_online p
                            where p.id = ( select min(t.id)
                                    from tarjeta.tarcrd_pagos_online t
                                   where t.pago_estado = 0
                                        and t.pagado = 'NO'
                                        and nvl(t.tar_procesadora, 1) = 3
                                        and t.tipooperacion = 'P'
                                        and t.tarjeta = p.tarjeta
                                        and t.pago_intento <
                                                            (select pr.dt_valor
                                                                from wilson1.dt_parametros_fecha pr
                                                             where pr.dt_id = 50399
                                                             and pr.dt_secuencia = 1))
                        order by p.id asc) pagospendientes
            where rownum < (select pr.dt_valor
                            from wilson1.dt_parametros_fecha pr
                            where pr.dt_id = 50399
                            and pr.dt_secuencia = 2)";

        public static string ActualizaEstadoProcesoPagos =>
            @"update  wilson1.dt_parametros_fecha pr
                      set pr.dt_valor = :estadoProceso
                   where pr.dt_id = 50399
                      and pr.dt_secuencia = 3";

        public static string ConsultaEstadoProcesoPagos =>
            @"select trim(pr.dt_valor)
                 from wilson1.dt_parametros_fecha pr
                    where pr.dt_id = 50399
                    and pr.dt_secuencia = 3";

        public static string ObtenerCantidadIntentos =>
            @"select e.log_intento
                from tarjeta.enviotjtbloqueodesb e
             where e.nroproces = :numeroProceso";

        public static string ObtenerParametrica =>
            @"select c.dt_valor
                 from wilson1.dt_parametros_fecha c
               where c.dt_id = :idParametrica
                 and c.dt_secuencia = :secuencia";

        public static string EsWaled =>
            @"select count(1)
              from wilson1.dt_parametros_fecha i
             where i.dt_id = 1005
               and i.Dt_Valor = substr(:pi_tarjeta, 0, 8)";

        public static string ActualizaMensajePago =>
            @"update tarjeta.tarcrd_pagos_online t
                 set t.resp_msgretorno = :MensajeRespuesta,
                     t.resp_codretorno = :CodigoResuesta,
                     t.pago_intento = :Intento,
                     t.fecha_modificado = :FechaModificacion
               where t.id = :Comprobante";

        public static string ActualizaEstadoPago =>
            @"update tarjeta.tarcrd_pagos_online t
                 set t.pago_estado = :EstadoPago,
                     t.pagado = :PagoProcesado,
                     t.resp_msgretorno = :MensajeRespuesta,
                     t.resp_codretorno = :CodigoResuesta,
                     t.pago_intento = :Intento,
                     t.fecha_modificado = :FechaModificacion
               where t.id = :Comprobante";

        public static string ObtenerPago =>
            @"select t.id           comprobante,
                     t.pago_intento intento,
                     t.add_user     UsuarioRegistro,
                     t.add_fecha    FechaRegistro,
                     t.tarjeta      Tarjeta,
                     t.comprobante  ComprobanteCajaDesc,
                     t.nro_recibo   Recibo,
                     t.monto        Monto
                from tarjeta.tarcrd_pagos_online t
               where t.id = :comprobante";

        public static string ActualizaPagoProcesado =>
            @"update tarjeta.tarcrd_pagos_online p
                 set p.pago_estado        = :EstadoPago,
                     p.pagado             = :PagoProcesado,
                     p.pago_intento       = :Intento,
                     p.resp_fechaafecdisp = :FechaDisponible,
                     p.resp_fecha_ext     = :FechaExtracto,
                     p.resp_fecha         = :FechaPago,
                     p.resp_codretorno    = :CodigoResuesta,
                     p.resp_msgretorno    = :MensajeRespuesta,
                     p.fecha_modificado   = sysdate
               where p.id = :Comprobante";

        public static string ActualizaPagoProcesadoCajaDesc =>
            @"update wilson1.cajadesc t
                 set t.movi_enviado = :Enviado,
                     t.movi_envdate = :FechaEnvio,
                     t.movi_envtime = :HoraEnvio,
                     t.movi_envuser = :UsuarioEnvio
               where t.movi_cajer = :UsuarioRegistro
                 and t.movi_date = :FechaRegistro
                 and t.movi_opera = :Operacion
                 and t.movi_comprobante = :Comprobante
                 and t.movi_recib = :Recibo
                 and t.movi_monto = :Monto
                 and t.movi_efect = :Efectivo
                 and t.movi_chequ = :Cheque
                 and t.movi_ch24 = :Cheque24
                 and t.movi_ch48 = :Cheque48";
        public static string Fechus =>
            @"select t.par_date fecha from wilson1.credpara t";
        public static string TarjetaVirualPendiente =>
            @"select t.tar_id_sesion idSesionTarjeta,
                     t.tar_nrocta Cuenta,
                     t.tar_nrotar || t.tar_nro Tarjeta
                from tarjeta.logtarjebancard_v2 t
               where t.tar_procesadora = :procesadora
                 and t.tar_enviar = :enviar
                 and t.tar_proces = :proceso
                 and t.tar_tipomov = :movimiento
                 and t.tar_id_sesion is not null
                 and t.tar_emboza = :embozar
                 and not exists
                (select 1
                   from wilson1.contarje c
                  where c.t_ntar || c.t_nro = t.tar_nrotar || t.tar_nro)";
        public static string ObtenerDatoParaContarje =>
            @"select c.cta_nrocta Cuenta,
                     t.tar_nrotar Tarjeta,
                     t.tar_nro Digito,
                     to_char(t.tar_fecalta, 'DD/MM/YY') FechaEmision,
                     case when t.tar_tiptar = 'P' then
                       c.cta_lineacrednormal
                     else
                       0 end Linea,
                     16 Tasa,
                     substr(t.tar_venci, 1, 2) || '/' || substr(t.tar_venci, 3, 2) Vencimiento,
                     0 Saldo,
                     0 Situacion,
                     (select l.clie_cedul
                        from wilson1.credclie l
                       where l.clie_key = t.tar_cliekey) Cedula,
                     t.tar_cliekey CodigoCliente,
                     c.cta_nrosuc Sucursal,
                     case when t.tar_tiptar = 'P' then
                       '0'
                     else
                       '1' end EsPrincipal,
                     0 MontoMora,
                     0 DiaMora,
                     t.tar_nomplas NombrePlastico,
                     c.cta_dirext1 Direccion,
                     c.cta_nrotel Telefono,
                     0 Judicial,
                     1 Estado,
                     to_char(sysdate, 'DD/MM/YY') FechaUltimoPago,
                     0 SaldoUltimoExtracto,
                     0 PagoMinimo,
                     0 PagoAcumuladoMes,
                     trunc(t.tar_fecalta) FechaEmisionCompleto,
                     0 MontoLineaCuota,
                     0 MontoDeudaCuota,
                     ' ' IndicadorEstado,
                     '' Codeudor,
                     '' DocumentoCodeudor,
                     '' Renovacion
                from tarjeta.tarctabancard_v2 c, tarjeta.tarjebancard_v2 t
               where c.cta_nrocta = t.tar_nrocta
                 and t.tar_nrotar || t.tar_nro = :tarjeta
                 and c.cta_nrocta = :cuenta";
        public static string InsertarContarje =>
            @"insert into wilson1.contarje (t_ncta,t_ntar,t_nro,t_emis,t_linea,t_tasa,t_venci,t_saldo,t_situa,t_cedu,t_client,t_suc,t_princi,
                monmor,diamor,t_nombre,t_direcc,t_tele,t_judi,t_sittar,t_fulpag,t_saulre,t_pmifai,t_acpgme,t_femis,t_licocu,sacupe,t_boleti,
                t_code,t_ceduco,t_renova)values(
                :Cuenta,
                :Tarjeta,
                :Digito,
                :FechaEmision,
                :Linea,
                :Tasa,
                :Vencimiento,
                :Saldo,
                :Situacion,
                :Cedula,
                :CodigoCliente,
                :Sucursal,
                :EsPrincipal,
                :MontoMora,
                :DiaMora,
                :NombrePlastico,
                :Direccion,
                :Telefono,
                :Judicial,
                :Estado,
                :FechaUltimoPago,
                :SaldoUltimoExtracto,
                :PagoMinimo,
                :PagoAcumuladoMes,
                :FechaEmisionCompleto,
                :MontoLineaCuota,
                :MontoDeudaCuota,
                :IndicadorEstado,
                :Codeudor,
                :DocumentoCodeudor,
                :Renovacion)";
        public static string ObtenerDatoParaPbTarjeta =>
            @"select t.tar_nrotar || t.tar_nro NumeroTarjeta,
                     t.tar_nrotar Tarjeta,
                     t.tar_nro Digito,
                     t.tar_nomplas NombreTarjeta,
                     '21' CodigoEntidad,
                     t.tar_codafinidad Afinidad,
                     '' Marca,
                     '' CodigoProducto,
                     t.tar_nrocta Cuenta,
                     '' IdPersona,
                     '' Documento,
                     t.tar_tiptar TipoTarjeta,
                     t.tar_nomplas NombrePlastico,
                     to_char(sysdate, 'YYYYMMDD') ValeDesde,
                     t.tar_duracion Duracion,
                     substr(to_char(sysdate, 'YYYY'), 1, 2) || substr(t.tar_venci, 3, 2) || substr(t.tar_venci, 1, 2) ValeHasta,
                     '0' ValeHastaEmbozado,
                     'N' Personalizada,
                     'S' Renovar,
                     t.tar_tipoplastico TipoPlastico,
                     '' IdTipoDocumento,
                     t.tar_nomplas NombreBandaMagnetica,
                     trunc(sysdate) FechaRecibo,
                     trunc(sysdate) FechaEmbozado,
                     trunc(sysdate) FechaPin,
                     trunc(sysdate) FechaEmision,
                     'E' TipoUltimoEmbozado,
                     'N' CobrarFraude,
                     'N' Recuperada,
                     'N' Vencida,
                     '' IdTipoBloqueo,
                     'A' SituacionTarjeta,
                     '0' Reservado1,
                     'TAR' UserAdd,
                     trunc(sysdate) FechaAdd,
                     '' ModificacionUsuario,
                     '' FechaModificacion,
                     trunc(sysdate) FechaSituacion,
                     'Activa' ObservacionSituacion,
                     'N' EmbozarPlastico,
                     '0' Reservado2,
                     '0' Reservado3,
                     '' Reservado4,
                     '0' Reservado5,
                     '0' Reservado6,
                     '0' Reservado7,
                     '0' IdMotivoNovedad,
                     '' IdMotivoEntidad,
                     '1' IdFormatoRecibo,
                     '8' IdFormatoPin,
                     '0' IdPromotor,
                     '0' IdMotivoNovedad2,
                     '0' IdMotivoEntidad2,
                     '' ObservacionMotivoTarjeta,
                     '' DisenhoDataCard,
                     t.tar_cliekey CodigoCliente,
                     sysdate FechaCreacion,
                     'TAR' UsuarioCreacion,
                     sysdate FechaModificacionPb,
                     'TAR' UsuarioModificacion,
                     user Firma,
                     '' Reservado8,
                     '' Reservado9,
                     '' FormaBloqueo
                from tarjeta.tarctabancard_v2 c, tarjeta.tarjebancard_v2 t
               where c.cta_nrocta = t.tar_nrocta
                 and t.tar_nrotar || t.tar_nro = :tarjeta
                 and c.cta_nrocta = :cuenta";
        public static string DatosPersona =>
            @"select t.tper_codigo IdPersona,
                     trim(substr(t.tper_nrodoc, 2)) Documento,
                     t.tper_tipdoc IdTipoDocumento
                from tarjeta.tarpersonas t
               where t.tper_cliekey = :codigoCliente";
        public static string InsertarPbTarjeta =>
            @"insert into tarjeta.bpsa_pbtarjeta(
                  nro_tarjeta,tar_nro,tar_digito,nombre_tarjeta,cod_entidad,id_afinidad,cod_marca,cod_producto_marca,id_cuenta,id_persona_fisica,
                  nro_documento,tipo_tarjeta,nombre_plastico,vale_desde,duracion,vale_hasta,vale_hasta_embozado,personalizada,renovar_automaticamente,
                  tipo_plastico,id_tipo_documento,nom_banda_magnetica,fecha_recibo,fecha_embozado,fecha_pin,fecha_emision,tipo_ult_embozado,cobrar_scfraude,
                  recuperada,vencida,id_tipo_bloqueo,situacion_tarjeta,reservado1,ex_add_user,ex_add_fecha,ex_mod_user,ex_mod_fecha,fecha_sit_tarjeta,
                  obs_sit_tarjeta,embozar_plastico,reservado2,reservado3,reservado4,reservado5,reservado6,reservado7,id_motivo_novedad_tar,
                  id_motivo_entidad,id_formato_recibo,id_formato_pin,id_promotor,id_motivo_novedad_tar2,id_motivo_entidad2,obs_motivo_tarjeta,
                  id_diseno_datacard,cliekey,add_fecha,add_user_ora,mod_fecha,mod_user_ora,firma,reservado8,reservado9,forma_bloqueo)VALUES
                  (:NumeroTarjeta,
                  :Tarjeta,
                  :Digito,
                  :NombreTarjeta,
                  :CodigoEntidad,
                  :Afinidad,
                  :Marca,
                  :CodigoProducto,
                  :Cuenta,
                  :IdPersona,
                  :Documento,
                  :TipoTarjeta,
                  :NombrePlastico,
                  :ValeDesde,
                  :Duracion,
                  :ValeHasta,
                  :ValeHastaEmbozado,
                  :Personalizada,
                  :Renovar,
                  :TipoPlastico,
                  :IdTipoDocumento,
                  :NombreBandaMagnetica,
                  :FechaRecibo,
                  :FechaEmbozado,
                  :FechaPin,
                  :FechaEmision,
                  :TipoUltimoEmbozado,
                  :CobrarFraude,
                  :Recuperada,
                  :Vencida,
                  :IdTipoBloqueo,
                  :SituacionTarjeta,
                  :Reservado1,
                  :UserAdd,
                  :FechaAdd,
                  :ModificacionUsuario,
                  :FechaModificacion,
                  :FechaSituacion,
                  :ObservacionSituacion,
                  :EmbozarPlastico,
                  :Reservado2,
                  :Reservado3,
                  :Reservado4,
                  :Reservado5,
                  :Reservado6,
                  :Reservado7,
                  :IdMotivoNovedad,
                  :IdMotivoEntidad,
                  :IdFormatoRecibo,
                  :IdFormatoPin,
                  :IdPromotor,
                  :IdMotivoNovedad2,
                  :IdMotivoEntidad2,
                  :ObservacionMotivoTarjeta,
                  :DisenhoDataCard,
                  :CodigoCliente,
                  :FechaCreacion,
                  :UsuarioCreacion,
                  :FechaModificacionPb,
                  :UsuarioModificacion,
                  :Firma,
                  :Reservado8,
                  :Reservado9,
                  :FormaBloqueo)";
        public static string VerificaContarje =>
            @"select count(*) from wilson1.contarje t where t.t_ntar || t.t_nro = :tarjeta";
        public static string VerificaPbTarjeta =>
            @"select count(*) from tarjeta.bpsa_pbtarjeta t where t.nro_tarjeta = :tarjeta";

        public static string InsertarReImpresionPrincipal =>
            @"insert into tarjeta.reimp_principal
              (r_id,
               r_nrotarjeta_viejo,
               r_nrotarjeta_nuevo,
               r_cliekey,
               r_motivo_cod,
               r_importe_debitar,
               r_cobrar_costo,
               r_vencimiento,
               r_fecha_validacion,
               r_user_proceso,
               r_motivo_transf,
               r_ald,
               r_ofac,
               r_onu,
               r_clasbcp,
               r_mora,
               r_tjtvencido,
               r_tjtbloqueado,
               r_observaciones,
               r_user_registro,
               r_fecha_registro,
               r_suc_registro,
               r_user_autorizo,
               r_fecha_autorizo,
               r_suc_autorizo,
               r_estado,
               r_procesadora)
            values
              (:Id,
               :Tarjeta,
               :TarjetaNuevo,
               :CodigoCliente,
               :Motivo,
               :Importe,
               :Costo,
               :Vencimiento,
               :FechaValidacion,
               :UsuarioProceso,
               :MotivoTransferencia,
               :Ald,
               :Ofac,
               :Onu,
               :Clasbcp,
               :Mora,
               :TarjetaVencida,
               :TarjetaBloqueada,
               :Observacion,
               :UsuarioRegistro,
               :FechaRegistro,
               :SucursalRegistro,
               :UsuarioAutorizo,
               :FechaAutorizo,
               :SucursalAutorizo,
               :Estado,
               :Procesadora)";

        public static string InsertarReImpresionPrincipalLog =>
            @"insert into tarjeta.logreimp_principal
                  (log_logkey,
                   log_id,
                   log_nrotarjeta_viejo,
                   log_nrotarjeta_nuevo,
                   log_importe_debitar,
                   log_cobrar_costo,
                   log_vencimiento,
                   log_fecha_validacion,
                   log_user_proceso,
                   log_motivo_transf,
                   log_nroproceso,
                   log_procsa,
                   log_enviar,
                   log_procesadora)
                values
                  (:LogKey,
                   :Id,
                   :Tarjeta,
                   :TarjetaNuevo,
                   :Importe,
                   :Costo,
                   :Vencimiento,
                   :FechaValidacion,
                   :UsuarioProceso,
                   :MotivoTransferencia,
                   :NumeroProceso,
                   :Procesado,
                   :Enviar,
                   :Procesadora)";
        public static string InsertarReImpresionCourier =>
            @"insert into tarjeta.reimp_principal_encourrier 
              (r_id,
               r_nrotarjeta_viejo,
               r_nrotarjeta_nuevo,
               r_cliekey,
               r_biblioteca,
               r_estado,
               r_user_registro,
               r_fecha_registro)
            values
              (:Id,
               :Tarjeta,
               :NuevaTarjeta,
               :CodigoCliente,
               :Biblioteca,
               :Enviar,
               :UsuarioRegistro,
               :FechaRegistro)";
        public static string ObtenerSiguienteIdReimpresion => @"select tarjeta.sec_reimp_principal.nextval from dual";
        public static string ObtenerSiguienteLogKeyReimpresion => @"select tarjeta.sec_logreimp_principal.nextval from dual";
        public static string ObtenerNumeroProcesoReimpresion => @"select tarjeta.sec_reimp_nroproceso_bpsa.nextval from dual";

        public static string ObtenerTarjetasCourierEntregadas =>
            @"select c.r_nrotarjeta_viejo Tarjeta, TO_CHAR(c.r_fecha_modif, 'YYYYMMDD') FechaEntregada
                  from tarjeta.reimp_principal_encourrier c
                where c.r_biblioteca = :biblioteca
                   and nvl(c.r_archivo_tcentrega, 'N') = 'N'
                   and exists (select t.nro_tarjeta from tarjeta.bpsa_pbtarjeta t where t.nro_tarjeta = c.r_nrotarjeta_viejo)";

        public static string ActualizarEstadoTarjetaCourier =>
            @"update tarjeta.reimp_principal_encourrier c
                 set c.r_archivo_tcentrega = :archivo
               where c.r_nrotarjeta_viejo = :Tarjeta
                 and c.r_biblioteca = :biblioteca
                 and nvl(c.r_archivo_tcentrega, 'N') = 'N'";

        public static string ValidarTarjetaInternacional =>
            @"select max(c.clas_interlocal)
                  from tarjeta.tarafinidadbancard t, tarjeta.tarclasbancard c
                where t.afi_clastar = c.clas_cod
                   and t.afi_id = :afinidad";

        public static string ValidarTarjetaDigitalHibrida =>
            @"select nvl(json_value(s.datos_adicionales, '$.EsDigitalHibrido'), 'false') ""EsDigitalHibrido""
                from userweb.srv_solicitudes s
               where json_value(s.datos_adicionales, '$.Tarjeta') = :numeroTarjeta
                 and exists (select 1
                               from tarjeta.tarjebancard_v2 t
                              where t.tar_cliekey = s.cliekey
                                and t.tar_nrotar || t.tar_nro = :numeroTarjeta)";

        public static string ActualizaEstadoListaBlanca =>
            @"update stage.tar_lista_blanca p
                 set p.estado             = :estado,
                     p.cod_respuesta      = :CodigoRetorno,
                     p.msj_respuesta      = :MensajeRetorno,
                     p.fecha_modificacion = :FechaModificacion,
                     p.id_tarjeta         = :IdTarjeta,
                     p.intentos           = :Intentos
               where p.id = :Id";
        public static string ObtenerOpPendiente =>
            @"select t.id, t.nro_tarjeta NumeroTarjeta, t.intentos Intentos, t.fecha_inicio FechaInicio, 
                 t.fecha_fin FechaFin, t.cod_comercio CodigoComercio, t.nombre_comercio NombreComercio, 
                 t.usuario Usuario,t.tipo_marca TipoMarca 
            from stage.tar_lista_blanca t where t.id = :Id";
    }
}
