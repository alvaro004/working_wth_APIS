﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Infrastructure.Settings.Services
{
    public class CredencialesToken
    {
        public List<Credenciales> Credenciales { get; set; }
    }
}
