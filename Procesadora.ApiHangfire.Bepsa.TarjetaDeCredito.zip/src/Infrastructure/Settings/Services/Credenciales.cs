﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Continental.API.Infrastructure.Settings.Services
{
    public class Credenciales
    {
        public string Key { get; set; }
        public string Usuario { get; set; }
        public string Password { get; set; }
        public string UrlServicio { get; set; }
        public string UrlServicioCredito { get; set; }
        public string UsuarioActivacion { get; set; }
        public string UsuarioServicioReimpresion { get; set; }
    }
}
