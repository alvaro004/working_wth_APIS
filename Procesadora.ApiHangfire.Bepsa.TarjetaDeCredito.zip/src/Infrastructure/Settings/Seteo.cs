﻿namespace Continental.API.Infrastructure.Settings
{
    public class Seteo
    {
        public string Key { get; set; }
        public string Valor { get; set; }
    }
}
