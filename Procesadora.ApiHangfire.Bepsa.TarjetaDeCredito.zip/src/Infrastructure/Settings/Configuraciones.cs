﻿using System.Collections.Generic;
using Continental.API.Infrastructure.Settings.DataBase;
using Continental.API.Infrastructure.Settings.Services;

namespace Continental.API.Infrastructure.Settings
{
    public class Configuraciones
    {
        public SeteosBD SeteosBD { get; set; }
        public List<Seteo> SeteosVarios { get; set; }
        public CredencialesToken CredencialesToken { get; set; }
    }
}