﻿namespace Continental.API.Infrastructure.Settings.DataBase
{
    public class DataSource
    {
        public string Key { get; set; }
        public string SourceDesarrollo { get; set; }
        public string SourceProduccion { get; set; }
    }
}