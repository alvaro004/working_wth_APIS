﻿namespace Continental.API.Infrastructure.Settings.DataBase
{
    public class Credencial
    {
        public string Key { get; set; }
        public string Usuario { get; set; }
        public string PasswordDesarrollo { get; set; }
        public string PasswordProduccion { get; set; }
    }
}