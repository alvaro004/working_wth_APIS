﻿namespace Continental.API.Infrastructure.Settings.DataBase
{
    enum TiposDataSource
    {
        DATOSITA,
        T5
    }
}