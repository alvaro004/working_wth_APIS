﻿namespace Continental.API.Infrastructure.Settings.DataBase
{
    enum TiposCredenciales
    {
        SERVICIOS_SEGURIDAD,
        SERVICIOS_CONSULTA,
        T5,
        GENERICO
    }
}