﻿using Microsoft.EntityFrameworkCore;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;
using System;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Data
{
    public class OracleDbContextBi : DbContext
    {
        public OracleDbContextBi(DbContextOptions<OracleDbContextBi> options) : base(options)
        {
        }

        public DbSet<DatosListaBlanca> ListaBlanca { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DatosListaBlanca>(entity =>
            {
                entity.ToTable("TAR_LISTA_BLANCA", "STAGE");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("ID").HasColumnType("NUMBER").HasMaxLength(30);
                entity.Property(e => e.NumeroTarjeta).HasColumnName("NRO_TARJETA").IsUnicode(false);
                entity.Property(e => e.FechaInicio).HasColumnName("FECHA_INICIO").HasDefaultValue(DateTime.Now.ToLocalTime());
                entity.Property(e => e.FechaFin).HasColumnName("FECHA_FIN").HasDefaultValue(DateTime.Now.ToLocalTime());
                entity.Property(e => e.CodigoComercio).HasColumnName("COD_COMERCIO");
                entity.Property(e => e.NombreComercio).HasColumnName("NOMBRE_COMERCIO");
                entity.Property(e => e.Usuario).HasColumnName("USUARIO");
                entity.Property(e => e.estado).HasColumnName("ESTADO");
                entity.Property(e => e.TipoOperacion).HasColumnName("TIPO_OPERACION");
                entity.Property(e => e.CodigoRetorno).HasColumnName("COD_RESPUESTA");
                entity.Property(e => e.MensajeRetorno).HasColumnName("MSJ_RESPUESTA");
                entity.Property(e => e.Intentos).HasColumnName("INTENTOS");
                entity.Property(e => e.TipoMarca).HasColumnName("TIPO_MARCA");
                entity.Property(e => e.NumeroDocumento).HasColumnName("NRO_DOCUMENTO");
                entity.Property(e => e.FechaModificacion).HasColumnName("FECHA_MODIFICACION");
                entity.Property(e => e.BinAdquirente).HasColumnName("BIN_ADQUIRENTE");
                entity.Property(e => e.IdTarjeta).HasColumnName("ID_TARJETA").HasDefaultValue(0);
            });
        }
    }
}
