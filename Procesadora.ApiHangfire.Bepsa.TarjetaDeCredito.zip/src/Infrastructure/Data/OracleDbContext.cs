using Microsoft.EntityFrameworkCore;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;

namespace Continental.API.Infrastructure.Data
{
    public class OracleDbContext : DbContext
    {
        public OracleDbContext(DbContextOptions<OracleDbContext> options) : base(options)
        {
        }

        public DbSet<PagoEF> Pago { get; set; }

        public DbSet<CajaDescEF> CajaDesc { get; set; }

        public DbSet<DtParametrosFecha> DtParametroFecha { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PagoEF>(entity =>
            {
                entity.ToTable("TARCRD_PAGOS_ONLINE", "TARJETA");
                entity.HasKey(e => e.Comprobante);
                entity.Property(e => e.Comprobante).HasColumnName("ID");
                entity.Property(e => e.Tarjeta).HasColumnName("TARJETA").IsUnicode(false);
                entity.Property(e => e.Monto).HasColumnName("MONTO");
                entity.Property(e => e.EstadoPago).HasColumnName("PAGO_ESTADO");
                entity.Property(e => e.Intento).HasColumnName("PAGO_INTENTO");
                entity.Property(e => e.Procesadora).HasColumnName("TAR_PROCESADORA");
                entity.Property(e => e.PagoProcesado).HasColumnName("PAGADO");
                entity.Property(e => e.OperacionTipo).HasColumnName("TIPOOPERACION");
                entity.Property(e => e.FechaDisponible).HasColumnName("RESP_FECHAAFECDISP");
                entity.Property(e => e.FechaExtracto).HasColumnName("RESP_FECHA_EXT");
                entity.Property(e => e.FechaPago).HasColumnName("RESP_FECHA");
                entity.Property(e => e.CodigoResuesta).HasColumnName("RESP_CODRETORNO");
                entity.Property(e => e.MensajeRespuesta).HasColumnName("RESP_MSGRETORNO");
                entity.Property(e => e.FechaModificacion).HasColumnName("FECHA_MODIFICADO");
                entity.Property(e => e.ComprobanteCajaDesc).HasColumnName("COMPROBANTE");
                entity.Property(e => e.Reversado).HasColumnName("REVERSADO");
            });

            modelBuilder.Entity<CajaDescEF>(entity =>
            {
                entity.ToTable("CAJADESC", "WILSON1");
                entity.HasKey(e => e.Comprobante);
                entity.Property(e => e.Comprobante).HasColumnName("MOVI_COMPROBANTE");
                entity.Property(e => e.Enviado).HasColumnName("MOVI_ENVIADO");
                entity.Property(e => e.FechaEnvio).HasColumnName("MOVI_ENVDATE");
                entity.Property(e => e.HoraEnvio).HasColumnName("MOVI_ENVTIME");
                entity.Property(e => e.UsuarioEnvio).HasColumnName("MOVI_ENVUSER");
                entity.Property(e => e.UsuarioRegistro).HasColumnName("MOVI_CAJER");
                entity.Property(e => e.FechaRegistro).HasColumnName("MOVI_DATE");
                entity.Property(e => e.Operacion).HasColumnName("MOVI_OPERA");
                entity.Property(e => e.Recibo).HasColumnName("MOVI_RECIB");
                entity.Property(e => e.Monto).HasColumnName("MOVI_MONTO");
                entity.Property(e => e.Efectivo).HasColumnName("MOVI_EFECT");
                entity.Property(e => e.Cheque).HasColumnName("MOVI_CHEQU");
                entity.Property(e => e.Cheque24).HasColumnName("MOVI_CH24");
                entity.Property(e => e.Cheque48).HasColumnName("MOVI_CH48");
            });

            modelBuilder.Entity<DtParametrosFecha>(entity =>
            {
                entity.ToTable("DT_PARAMETROS_FECHA", "WILSON1");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("DT_ID").HasColumnType("NUMBER").HasMaxLength(5);
                entity.Property(e => e.Secuencia).HasColumnName("DT_SECUENCIA").HasColumnType("NUMBER").HasMaxLength(5);
                entity.Property(e => e.Valor).HasColumnName("DT_VALOR");
                entity.Property(e => e.Descripcion).HasColumnName("DT_DESCRIPCION");
                entity.Property(e => e.ValorDos).HasColumnName("DT_VALOR2");
                entity.Property(e => e.ValorTres).HasColumnName("DT_VALOR3");
                entity.Property(e => e.Tipo).HasColumnName("DT_TIPO");
            });
        }
    }
}