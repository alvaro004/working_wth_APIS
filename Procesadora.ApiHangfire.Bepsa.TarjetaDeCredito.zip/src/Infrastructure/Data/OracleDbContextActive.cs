﻿using Continental.API.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;

namespace Continental.API.Infrastructure.Data
{
    public class OracleDbContextActive : DbContext
    {
        public OracleDbContextActive(DbContextOptions<OracleDbContextActive> options) : base(options)
        {
        }

        public DbSet<PagoEF> Pago { get; set; }

        public DbSet<Fechus> Fechus { get; set; }

        public DbSet<DtParametrosFecha> DtParametroFecha { get; set; }

        public DbSet<EnviadorReimpresionBepsaEF> EnviadorReimpresionBepsa { get; set; }

        public DbSet<LogReimpresionPrincipalEF> LogReimpresionPrincipal { get; set; }

        public DbSet<LogProcesosReimpresionBepsa> LogProcesosReimpresionBepsa { get; set; }

        public DbSet<Contarje> DatoContarje { get; set; }

        public DbSet<Tartjtdebitos> DatoTarjetaDebito { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PagoEF>(entity =>
            {
                entity.ToTable("TARCRD_PAGOS_ONLINE", "TARJETA");
                entity.HasKey(e => e.Comprobante);
                entity.Property(e => e.Comprobante).HasColumnName("ID").HasColumnType("NUMBER").HasMaxLength(30);
                entity.Property(e => e.Tarjeta).HasColumnName("TARJETA").IsUnicode(false);
                entity.Property(e => e.Monto).HasColumnName("MONTO").HasColumnType("NUMBER").HasMaxLength(30);
                entity.Property(e => e.EstadoPago).HasColumnName("PAGO_ESTADO");
                entity.Property(e => e.Intento).HasColumnName("PAGO_INTENTO");
                entity.Property(e => e.Procesadora).HasColumnName("TAR_PROCESADORA");
                entity.Property(e => e.PagoProcesado).HasColumnName("PAGADO");
                entity.Property(e => e.OperacionTipo).HasColumnName("TIPOOPERACION");
                entity.Property(e => e.FechaDisponible).HasColumnName("RESP_FECHAAFECDISP");
                entity.Property(e => e.FechaExtracto).HasColumnName("RESP_FECHA_EXT");
                entity.Property(e => e.FechaPago).HasColumnName("RESP_FECHA");
                entity.Property(e => e.CodigoResuesta).HasColumnName("RESP_CODRETORNO");
                entity.Property(e => e.MensajeRespuesta).HasColumnName("RESP_MSGRETORNO");
                entity.Property(e => e.FechaModificacion).HasColumnName("FECHA_MODIFICADO");
                entity.Property(e => e.UsuarioRegistro).HasColumnName("ADD_USER");
                entity.Property(e => e.FechaRegistro).HasColumnName("ADD_FECHA");
                entity.Property(e => e.Recibo).HasColumnName("NRO_RECIBO");
                entity.Property(e => e.ComprobanteCajaDesc).HasColumnName("COMPROBANTE");
            });

            modelBuilder.Entity<DtParametrosFecha>(entity =>
            {
                entity.ToTable("DT_PARAMETROS_FECHA", "WILSON1");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).HasColumnName("DT_ID").HasColumnType("NUMBER").HasMaxLength(5);
                entity.Property(e => e.Secuencia).HasColumnName("DT_SECUENCIA").HasColumnType("NUMBER").HasMaxLength(5);
                entity.Property(e => e.Valor).HasColumnName("DT_VALOR");
                entity.Property(e => e.Descripcion).HasColumnName("DT_DESCRIPCION");
                entity.Property(e => e.ValorDos).HasColumnName("DT_VALOR2");
                entity.Property(e => e.ValorTres).HasColumnName("DT_VALOR3");
                entity.Property(e => e.Tipo).HasColumnName("DT_TIPO");
            });

            modelBuilder.Entity<Fechus>(entity =>
            {
                entity.ToTable("CREDPARA", "WILSON1");
                entity.HasKey(e => e.Fecha);
                entity.Property(e => e.Fecha).HasColumnName("PAR_DATE");
            });

            modelBuilder.Entity<EnviadorReimpresionBepsaEF>(entity =>
            {
                entity.ToTable("REIMP_ENVIADOR_BPSA", "TARJETA");
                entity.HasKey(e => e.NumeroProceso);

                entity.Property(e => e.NumeroProceso).HasColumnName("NROPROCES");
                entity.Property(e => e.FechaAlta).HasColumnName("FECHA_ALTA");
                entity.Property(e => e.FechaEnvio).HasColumnName("FECHA_ENVIO");
                entity.Property(e => e.Estado).HasColumnName("ESTADO");
                entity.Property(e => e.CantidadIntento).HasColumnName("LOG_INTENTO");
                entity.Property(e => e.Maquina).HasColumnName("MAQUINA");
                entity.Property(e => e.IdSeguimiento).HasColumnName("ID_SEGUIMIENTO");
                entity.Property(e => e.CantidadIntentoSeguimiento).HasColumnName("INTENTO_SEGUIMIENTO");
            });

            modelBuilder.Entity<LogReimpresionPrincipalEF>(entity =>
            {
                entity.ToTable("LOGREIMP_PRINCIPAL", "TARJETA");

                entity.Property(e => e.LogKey).HasColumnName("LOG_LOGKEY");
                entity.Property(e => e.Id).HasColumnName("LOG_ID");
                entity.Property(e => e.NumeroTarjetaViejo).HasColumnName("LOG_NROTARJETA_VIEJO");
                entity.Property(e => e.NumeroTarjetaNuevo).HasColumnName("LOG_NROTARJETA_NUEVO");
                entity.Property(e => e.ImporteDebitar).HasColumnName("LOG_IMPORTE_DEBITAR");
                entity.Property(e => e.CobrarCosto).HasColumnName("LOG_COBRAR_COSTO");
                entity.Property(e => e.Vencimiento).HasColumnName("LOG_VENCIMIENTO");
                entity.Property(e => e.FechaValidacion).HasColumnName("LOG_FECHA_VALIDACION");
                entity.Property(e => e.UsuarioProceso).HasColumnName("LOG_USER_PROCESO");
                entity.Property(e => e.MotivoTransferencia).HasColumnName("LOG_MOTIVO_TRANSF");
                entity.Property(e => e.NumeroProceso).HasColumnName("LOG_NROPROCESO");
                entity.Property(e => e.Procesado).HasColumnName("LOG_PROCSA").HasDefaultValue("N");
                entity.Property(e => e.Enviar).HasColumnName("LOG_ENVIAR").HasDefaultValue(0);
                entity.Property(e => e.Procesadora).HasColumnName("LOG_PROCESADORA");
            });

            modelBuilder.Entity<LogProcesosReimpresionBepsa>(entity =>
            {
                entity.ToTable("REIMP_LOGPROCESOS_BPSA", "TARJETA");
                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("ID");
                entity.Property(e => e.NumeroProceso).HasColumnName("NRO_PROCESO");
                entity.Property(e => e.UsuarioBase).HasColumnName("USUARIO_BASE");
                entity.Property(e => e.UsuarioBancard).HasColumnName("USUARIO_BANCARD");
                entity.Property(e => e.CantidadEnviado).HasColumnName("CANTIDAD_ENVIADO");
                entity.Property(e => e.MensajeResultado).HasColumnName("MSJ_RESULTADO");
                entity.Property(e => e.Fecha).HasColumnName("FECHA");
                entity.Property(e => e.NumeroTarjeta).HasColumnName("TARJETA");
                entity.Property(e => e.CodigoRetorno).HasColumnName("COD_RETORNO");
                entity.Property(e => e.IdSeguimiento).HasColumnName("ID_SEGUIMIENTO");
            });

            modelBuilder.Entity<Contarje>(entity =>
            {
                entity.ToTable("CONTARJE", "WILSON1");
                entity.HasKey(e => e.NumeroTarjeta);
                entity.Property(e => e.NumeroTarjeta).HasColumnName("T_NTAR");
                entity.Property(e => e.DigitoVerificador).HasColumnName("T_NRO");
                entity.Property(e => e.NumeroDocumento).HasColumnName("T_CEDU");
            });

            modelBuilder.Entity<Tartjtdebitos>(entity =>
            {
                entity.ToTable("tartjtdebitos", "tarjeta");
                entity.HasKey(e => e.NumeroTarjeta);
                entity.Property(e => e.NumeroTarjeta).HasColumnName("TJTD_NROTARJETA");
                entity.Property(e => e.NumeroDocumento).HasColumnName("TJTD_NRODOC");
            });
        }
    }
}