﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Continental.API.Core.Interfaces;
using Continental.API.Infrastructure.DatabaseHelpers;
using Dapper;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Continental.API.Infrastructure.Repositories
{
    public class RepositoryAbmCredito : IRepositoryAbmCredito
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;
        private List<DatosCuenta> datosCuenta = new List<DatosCuenta>();
        private List<DatosCuentaCredito> datosCuentaCreditos = new List<DatosCuentaCredito>();
        private readonly int contador = 0;
        public RepositoryAbmCredito(IConfiguration configuraciones, HttpClient _apiClient)
        {
            _connectionStringActive = configuraciones.GetConnectionString("Active");
            _connectionString = configuraciones.GetConnectionString("Oracle");
        }
        /// <summary>
        /// Devuelve nro de lote pendiente de abm tarjeta credito para envio.
        /// </summary>
        /// <returns></returns>
        public List<PendientesEnvio> GetPendientesEnvio()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select e.nroproces from tarjeta.proceso_envio_bpsa e where e.estado = 1 order by e.nroproces";

                oracleConexion.Open();
                return oracleConexion.Query<PendientesEnvio>(consulta).AsList();
            }
        }
        /// <summary>
        /// Retorna los datos de cuentas de credito a transmitir.
        /// </summary>
        /// <param name="nroProc"></param>
        /// <returns></returns>
        public List<DatosCuentaCredito> GetDatosCuenta(double nroProc)
        {
           
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_nroPro", OracleDbType.Varchar2, ParameterDirection.Input, nroProc);
                dyParam.Add("po_datos_cta", OracleDbType.RefCursor, ParameterDirection.Output);
                var query = "bepsa.pkg_abm_credito.sp_archivocta_bpsa_ws";
                datosCuenta = SqlMapper.Query<DatosCuenta>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
                
                foreach (var item in datosCuenta)
                {
                    DatosCuentaCredito items = new DatosCuentaCredito();
                    items.DatosPersona = new List<DatosPersonas>();
                    items.Codeudores = new List<Codeudores>();
                    items.LineaCredito = new List<LineaCredito>();
                    items.DatoFinanciero = new List<DatosFinancieros>();
                    items.TasaInteres = new List<TasaInteres>();
                    items.Direcciones = new List<Direcciones>();
                    items.CargoPersonalizado = new List<CargoPersonalizado>();
                    items.ExisteRegistro = 1;
                    items.Accion = item.Accion;
                    items.ClienteEntidad = item.ClienteEntidad;
                    items.CodigoAfinidad = item.CodigoAfinidad;
                    items.Empresa = item.Empresa;
                    items.EstadoCuenta = item.EstadoCuenta;
                    items.MotivoNoImprimirExtracto = item.MotivoNoImprimirExtracto;
                    items.MotivoRetencionExtracto = item.MotivoRetencionExtracto;
                    items.NombreCuenta = item.NombreCuenta;
                    items.NroControl = item.NroControl;
                    items.NroCuenta = item.NroCuenta;
                    items.NroDocumento = item.NroDocumento;
                    items.NroDocumentoOficial = item.NroDocumentoOficial;
                    items.RUCExtracto = item.RUCExtracto;
                    items.Sucursal = item.Sucursal;
                    items.TipoCargo = "";
                    items.TipoCierre = item.TipoCierre;
                    items.TipoCuenta = item.TipoCuenta;
                    items.TipoDocumento = item.TipoDocumento;
                    items.TipoDocumentoOficial = item.TipoDocumentoOficial;
                    items.Usuario = item.Usuario;
                    items.PermiteTarjetaInnominada = item.PermiteTrjInnominada;     
                    items.DatosPersona.InsertRange(contador, DatosTitularCuenta(nroProc, item.NroCuenta));  
                    if (items.DatosPersona[contador].Accion == "") 
                    { 
                        items.DatosPersona = new List<DatosPersonas>();
                    }
                    List<DatosPersonas> datosOficial = DatosOficialCuenta(nroProc, item.NroCuenta);
                    if (datosOficial[0].IdOficial != null) 
                    { 
                        items.DatosPersona.InsertRange(1, datosOficial);
                    }
                    List<Codeudores> datosCodeudores = DatosCodeudor(nroProc, item.NroCuenta);
                    if (datosCodeudores[0].NroDocumento !=" " || (datosCodeudores[0].NroDocumento == " " && contador == 0))
                    { 
                        items.Codeudores.InsertRange(contador, DatosCodeudor(nroProc, item.NroCuenta));
                    }
                    items.DatoFinanciero.InsertRange(contador, DatosFinancieros(nroProc, item.NroCuenta));
                    items.LineaCredito.InsertRange(contador, DatosLineaCredito(nroProc, item.NroCuenta));
                    items.Direcciones.InsertRange(contador, DatosDirecciones(item));
                    items.TasaInteres.InsertRange(contador, DatosTasaInteres());
                    if (item.TipoCargo == "N" || item.AplicaSeguroVida == "N")
                    {
                        items.CargoPersonalizado.InsertRange(contador, ExoneracionCargosPersoalizados(
                                                                            item.TipoCargo == "N" && item.AplicaSeguroVida == "N" 
                                                                            ? TiposCargosPersonalizados.Defecto 
                                                                            : item.TipoCargo == "N" 
                                                                            ? TiposCargosPersonalizados.MantenimientoAnual 
                                                                            : TiposCargosPersonalizados.SeguroDeVida));
                        if(items.CargoPersonalizado.Count == 0)
                        {
                            items.CargoPersonalizado.InsertRange(contador, DatosCargoPersonalizado());
                        }
                    }
                    else 
                    { 
                        items.CargoPersonalizado.InsertRange(contador, DatosCargoPersonalizado());
                    }
                    datosCuentaCreditos.Add(items);
                }
                if (datosCuentaCreditos.Count == 0)
                {
                    datosCuentaCreditos = DatosCuentaCreditosNulos();
                }

                return datosCuentaCreditos;
            }
        }
        /// <summary>
        /// Retorna los datos de tarjetas a transmitir.
        /// </summary>
        /// <param name="nroProc"></param>
        /// <returns></returns>
        public List<DatosTarejtaCredito> GetDatosTarjeta(double nroProc)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_nroPro", OracleDbType.Varchar2, ParameterDirection.Input, nroProc);
                dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);
                var query = "bepsa.pkg_abm_credito.sp_datostarjeta";
                List<DatosTarejtaCredito> datosTarejtaCreditos = SqlMapper.Query<DatosTarejtaCredito>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
                foreach (var item in datosTarejtaCreditos)
                {
                    item.ExisteRegistro = 1;
                    item.CampoReservado = "";
                    item.DatosPersona = new List<DatosPersonas>();
                    item.DatosPersona.InsertRange(0,DatosTitularTarjeta(nroProc, item.NroTarjeta));
                    item.DatosPersona.InsertRange(1,DatosPromotorTarjeta(nroProc, item.NroTarjeta));
                }
                if (datosTarejtaCreditos.Count == 0)
                {
                    datosTarejtaCreditos = DatosTarejtaCreditosNulos();
                }

                return datosTarejtaCreditos;
            }
        }
        /// <summary>
        /// Ejecuta el proceso para la transmision de tarjetas de credito.
        /// </summary>
        /// <returns></returns>
        public List<PendientesEnvio> RealizarProceso()
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_envios_bepsaWS_v3";
                return SqlMapper.Query<PendientesEnvio>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        /// <summary>
        /// Actualiza resgistros de cuenta con el id sesion enviadas a la procesadora.
        /// </summary>
        /// <param name="idcta"></param>
        /// <param name="idtartj"></param>
        /// <param name="idsesion"></param>
        /// <returns></returns>
        public void ActualizaTransmisionCuenta(string idcta, string codaficta, string idsesion, double numeroProceso)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();

                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, idcta);
                dyParam.Add("pi_codafinidad", OracleDbType.Varchar2, ParameterDirection.Input, codaficta);
                dyParam.Add("pi_id_sesion", OracleDbType.Varchar2, ParameterDirection.Input, idsesion);
                dyParam.Add("pi_NumeroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);

                var query = "bepsa.pkg_abm_credito.sp_actualiza_ctas_envio_bepsa";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        /// <summary>
        /// Actualiza los registros enviados con el id de sesion retornado por la procesadora.
        /// </summary>
        /// <param name="idctatarj"></param>
        /// <param name="pi_codafi_tartj"></param>
        /// <param name="idsesion"></param>
        /// <returns></returns>
        public void ActualizaTransmisionTarjeta(string nrotarjeta, string idsesion, double numeroProceso)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_nro_tarjt", OracleDbType.Varchar2, ParameterDirection.Input, nrotarjeta);
                dyParam.Add("pi_id_sesion", OracleDbType.Varchar2, ParameterDirection.Input, idsesion);
                dyParam.Add("pi_NumeroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);

                var query = "bepsa.pkg_abm_credito.sp_actualiza_tartjt_envio_bepsa";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        /// <summary>
        /// Actualiza el lote segun respuesta obtenida por la procesadora.
        /// </summary>
        /// <param name="nroProceso"></param>
        public void ActualizaEnvioLoteBepsa(double nroProceso, EstadoEnvio estado, string codigoRespuesta, string mensajeRespuesta)
        {
            using var oracleConexion = new OracleConnection(this._connectionString);
            oracleConexion.Open();
            var dyParam = new DynamicParameters();
            dyParam.Add("@pi_NumeroProceso", nroProceso);
            dyParam.Add("@pi_Estado", estado);
            dyParam.Add("@pi_CodRespuesta", codigoRespuesta);
            dyParam.Add("@pi_MsgRespuesta", mensajeRespuesta);

            var query = "bepsa.pkg_abm_credito.sp_actualizacionproceso";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        private List<DatosPersonas> DatosTitularCuenta(double numeroProceso, string numeroCuenta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("po_datos_tit_cta", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_CTA_titular";
                var vuelto = SqlMapper.Query<DatosPersonas>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
                if (vuelto[0].Nombre1 == null) 
                { 
                    vuelto = DatosPersonasNulo();
                }
                return vuelto;
            }
        }
        private List<DatosPersonas> DatosOficialCuenta(double numeroProceso, string numeroCuenta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("po_datos_ofic_cta", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_oficial_cta";
                var vuelto = SqlMapper.Query<DatosPersonas>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
                if (vuelto[0].NroDocumento == null || vuelto[0].NroDocumento == " ") 
                { 
                    vuelto = DatosPersonasNulo();
                }
                return vuelto;
            }
        }
        private List<Codeudores> DatosCodeudor(double numeroProceso, string numeroCuenta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("po_codeudor_cta", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_codeudor";
                return SqlMapper.Query<Codeudores>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }
        private List<DatosFinancieros> DatosFinancieros(double numeroProceso, string numeroCuenta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("po_datos_financieros", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_financieros";
                return SqlMapper.Query<DatosFinancieros>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }

        private List<LineaCredito> DatosLineaCredito(double numeroProceso, string numeroCuenta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_cta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("po_linea_credito", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_linea_credito";
                return SqlMapper.Query<LineaCredito>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }
        private List<Direcciones> DatosDirecciones(DatosCuenta item)
        {
            Direcciones itemDirecciones = new Direcciones();
            List<Direcciones> datosDirecciones = new List<Direcciones>();
            if (item.Valor1 == " ")
            {
                datosDirecciones = DatosDireccionesNulo();
            }
            else 
            { 
            //direccion recibo
            itemDirecciones.IdDireccion = "RCB";
            itemDirecciones.TipoDireccion = "F";
            itemDirecciones.Valor1 = item.Valor1;
            itemDirecciones.Valor2 = item.Valor2;
            itemDirecciones.Valor3 = "";
            itemDirecciones.DescripcionReferencia = item.DescripcionReferencia;
            itemDirecciones.Pais = "600";
            itemDirecciones.Departamento = item.Departamento;
            itemDirecciones.Ciudad = item.Ciudad;
            itemDirecciones.Barrio = "";
            itemDirecciones.Zona = item.Zona;
            datosDirecciones.Add(itemDirecciones);
            //Extracto
            itemDirecciones = new Direcciones();
            itemDirecciones.IdDireccion = "EXT";
            if (item.MotivoRetencionExtracto == "9" && item.Email != " ")
            {
                itemDirecciones.TipoDireccion = "C";
                itemDirecciones.Valor1 = item.Email;
                itemDirecciones.Valor2 = "";
                itemDirecciones.Valor3 = "";
                itemDirecciones.DescripcionReferencia = "";
                itemDirecciones.Pais = "";
                itemDirecciones.Departamento = "";
                itemDirecciones.Ciudad = "";
                itemDirecciones.Barrio = "";
                itemDirecciones.Zona = "";
            }
            else
            {
                itemDirecciones.TipoDireccion = "F";
                itemDirecciones.Valor1 = item.Valor1;
                itemDirecciones.Valor2 = item.Valor2;
                itemDirecciones.Valor3 = "";
                itemDirecciones.DescripcionReferencia = item.DescripcionReferencia;
                itemDirecciones.Pais = "600";
                itemDirecciones.Departamento = item.Departamento;
                itemDirecciones.Ciudad = item.Ciudad;
                itemDirecciones.Barrio = "";
                itemDirecciones.Zona = item.Zona;
            }

            datosDirecciones.Add(itemDirecciones);
            //Pin
            itemDirecciones = new Direcciones();
            itemDirecciones.IdDireccion = "PIN";
            itemDirecciones.TipoDireccion = "F";
            itemDirecciones.Valor1 = item.Valor1;
            itemDirecciones.Valor2 = "";
            itemDirecciones.Valor3 = "";
            itemDirecciones.DescripcionReferencia = item.DescripcionReferencia;
            itemDirecciones.Pais = "600";
            itemDirecciones.Departamento = item.Departamento;
            itemDirecciones.Ciudad = item.Ciudad;
            itemDirecciones.Barrio = "";
            itemDirecciones.Zona = item.Zona;
            datosDirecciones.Add(itemDirecciones);
            }

            return datosDirecciones;
        }
        private List<DatosPersonas> DatosTitularTarjeta(double numeroProceso, string numeroTarjeta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_nroTarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
                dyParam.Add("po_datos_titular", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_titular_tarjeta";
                return SqlMapper.Query<DatosPersonas>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }
        private List<DatosPersonas> DatosPromotorTarjeta(double numeroProceso, string numeroTarjeta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                dyParam.Add("pi_nroPro", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_nroTarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
                dyParam.Add("po_datos_promotor", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_abm_credito.sp_datos_promotor";
                return SqlMapper.Query<DatosPersonas>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }
        private List<TasaInteres> DatosTasaInteres()
        {
            List<TasaInteres> datosTasaInteres = new List<TasaInteres>();
            TasaInteres item = new TasaInteres();
            item.Moneda = "";
            item.TipoTTI = "";
            item.PeriodoAfectacion = "";
            item.tasaInteres = "";
            datosTasaInteres.Add(item);
            return datosTasaInteres;
        }
        private List<CargoPersonalizado> DatosCargoPersonalizado()
        {
            List<CargoPersonalizado> datosCargoPersonalizado = new List<CargoPersonalizado>();
            CargoPersonalizado itemCargoPersonalizado = new CargoPersonalizado();
            itemCargoPersonalizado.Moneda = "";
            itemCargoPersonalizado.TipoCargoId = "";
            itemCargoPersonalizado.ImporteFijo = "";
            itemCargoPersonalizado.Porcentaje = "";
            itemCargoPersonalizado.FechaDesde = "";
            itemCargoPersonalizado.FechaFin = "";
            itemCargoPersonalizado.AplicaImpuesto = "";
            datosCargoPersonalizado.Add(itemCargoPersonalizado);
            return datosCargoPersonalizado;
        }
        private List<DatosTarejtaCredito> DatosTarejtaCreditosNulos()
        {
            DatosTarejtaCredito itemTarjeta = new DatosTarejtaCredito();
            List<DatosTarejtaCredito> datosTarejtaCreditos = new List<DatosTarejtaCredito>();
            itemTarjeta.DatosPersona = new List<DatosPersonas>();
            itemTarjeta.ExisteRegistro = 0;
            itemTarjeta.Accion = "";
            itemTarjeta.NroControl = "";
            itemTarjeta.NroTarjeta = "";
            itemTarjeta.NombreTarjeta = "";
            itemTarjeta.CodigoAfinidad = "";
            itemTarjeta.NroCuenta = "";
            itemTarjeta.TipoDocumento = "";
            itemTarjeta.NroDocumento = "";
            itemTarjeta.TipoTarjeta = "";
            itemTarjeta.NombrePlastico = "";
            itemTarjeta.TipoPlastico = "";
            itemTarjeta.Duracion = "";
            itemTarjeta.SituacionTarjeta = "";
            itemTarjeta.Renovar = "";
            itemTarjeta.EmbozarPlastico = "";
            itemTarjeta.Sucursal = "";
            itemTarjeta.CampoReservado = "";
            itemTarjeta.IdTipoDocPromotor = "";
            itemTarjeta.NroDocPromotor = "";
            itemTarjeta.OrdenEmbozado = "";
            itemTarjeta.Usuario = "";
            datosTarejtaCreditos.Add(itemTarjeta);
            return datosTarejtaCreditos;
        }
        private List<DatosCuentaCredito> DatosCuentaCreditosNulos()
        {
            List<DatosCuentaCredito> datosCuentaCreditos = new List<DatosCuentaCredito>();
            DatosCuentaCredito item = new DatosCuentaCredito();
            List<Codeudores> datosCodedudores = new List<Codeudores>();
            Codeudores itemCodeudor = new Codeudores();
            CargoPersonalizado itemCargoPersonalizado = new CargoPersonalizado();
            List<CargoPersonalizado> datosCargoPersonalizado = new List<CargoPersonalizado>();
            DatosFinancieros itemDatoFinanciero = new DatosFinancieros();
            List<DatosFinancieros> datosFinancieros = new List<DatosFinancieros>();
            LineaCredito itemLineaCredito = new LineaCredito();
            List<LineaCredito> datosLineaCredito = new List<LineaCredito>();
            TasaInteres itemTasaInteres = new TasaInteres();
            List<TasaInteres> datosTasaInteres = new List<TasaInteres>();
            if (datosCuentaCreditos.Count == 0)
            {
                #region direcciones nulo
                item.Direcciones = DatosDireccionesNulo();
                #endregion
                #region codeudores nulo
                itemCodeudor.NroDocumento = "";
                itemCodeudor.TipoDocumento = "";
                datosCodedudores.Add(itemCodeudor);
                item.Codeudores = datosCodedudores;
                #endregion
                #region cargoPersonalizado nulo
                itemCargoPersonalizado.Moneda = "";
                itemCargoPersonalizado.TipoCargoId = "";
                itemCargoPersonalizado.ImporteFijo = "";
                itemCargoPersonalizado.Porcentaje = "";
                itemCargoPersonalizado.FechaDesde = "";
                itemCargoPersonalizado.FechaFin = "";
                itemCargoPersonalizado.AplicaImpuesto = "";
                datosCargoPersonalizado.Add(itemCargoPersonalizado);
                item.CargoPersonalizado = datosCargoPersonalizado;
                #endregion
                #region datosfinancieros nulo
                itemDatoFinanciero.Moneda = "";
                itemDatoFinanciero.ModoPago = "";
                itemDatoFinanciero.TipoCtaBancaria = "";
                itemDatoFinanciero.NroCtaBancaria = "";
                itemDatoFinanciero.TipoPago = "";
                itemDatoFinanciero.TipoTasaFinanciacion = "";
                itemDatoFinanciero.PersonalizarPM = "";
                itemDatoFinanciero.PorcentajePM = "";
                itemDatoFinanciero.ImporteMinPM = "";
                itemDatoFinanciero.ImporteFijoPM = "";
                itemDatoFinanciero.CargoGastoFinanciero = "";
                datosFinancieros.Add(itemDatoFinanciero);
                item.DatoFinanciero = datosFinancieros;
                #endregion
                #region lineaCredito nulo
                itemLineaCredito.Moneda = "";
                itemLineaCredito.TipoLineaCredito = "";
                itemLineaCredito.ImporteLC = "";
                datosLineaCredito.Add(itemLineaCredito);
                item.LineaCredito = datosLineaCredito;
                #endregion
                #region tasainteres nulo
                itemTasaInteres.Moneda = "";
                itemTasaInteres.TipoTTI = "";
                itemTasaInteres.PeriodoAfectacion = "";
                itemTasaInteres.tasaInteres = "";
                datosTasaInteres.Add(itemTasaInteres);
                item.TasaInteres = datosTasaInteres;
                #endregion
                #region item
                item.ExisteRegistro = 0;
                item.Accion = "";
                item.ClienteEntidad = "";
                item.CodigoAfinidad = "";
                item.Empresa = "";
                item.EstadoCuenta = "";
                item.MotivoNoImprimirExtracto = "";
                item.MotivoRetencionExtracto = "";
                item.NombreCuenta = "";
                item.NroControl = "";
                item.NroCuenta = "";
                item.NroDocumento = "";
                item.NroDocumentoOficial = "";
                item.RUCExtracto = "";
                item.Sucursal = "";
                item.TipoCargo = "";
                item.TipoCierre = "";
                item.TipoCuenta = "";
                item.TipoDocumento = "";
                item.TipoDocumentoOficial = "";
                item.Usuario = "";
                item.PermiteTarjetaInnominada = "";
                #endregion
                datosCuentaCreditos.Add(item);
            }
            return datosCuentaCreditos;
        }
        private List<DatosPersonas> DatosPersonasNulo()
        {
            DatosPersonas item = new DatosPersonas();
            List<DatosPersonas> datosPersonas = new List<DatosPersonas>();
            item.Accion = "";
            item.Apellido1 = "";
            item.Apellido2 = "";
            item.Barrio = "";
            item.Ciudad = "";
            item.DenominacionComercial = "";
            item.Departamento = "";
            item.Direccion = "";
            item.Email = "";
            item.EstadoCivil = "";
            item.FechaNacimiento = "";
            item.Nacionalidad = "";
            item.Nombre1 = "";
            item.Nombre2 = "";
            item.NroDocumento = "";
            item.NroSocio = "";
            item.Ocupacion = "";
            item.OficialCuenta = "";
            item.PaisResidencia = "";
            item.Promotor = "";
            item.RazonSocial = "";
            item.RUCPersonaFisica = "";
            item.Sexo = "";
            item.Telefono = "";
            item.TipoDocumento = "";
            item.TipoFirma = "";
            item.TipoPersona = "";
            item.TipoPersonaJuridica = "";
            item.Usuario = "";
            item.ValidarRUC = "";
            item.ZonaId = "";
            datosPersonas.Add(item);
            return datosPersonas;
        }
        private List<Direcciones> DatosDireccionesNulo() 
        {
            Direcciones itemDirecciones = new Direcciones();
            List<Direcciones> datosDirecciones = new List<Direcciones>();
            
                itemDirecciones.IdDireccion = "";
                itemDirecciones.TipoDireccion = "";
                itemDirecciones.Valor1 = "";
                itemDirecciones.Valor2 = "";
                itemDirecciones.Valor3 = "";
                itemDirecciones.DescripcionReferencia = "";
                itemDirecciones.Pais = "";
                itemDirecciones.Departamento = "";
                itemDirecciones.Ciudad = "";
                itemDirecciones.Barrio = "";
                itemDirecciones.Zona = "";
                datosDirecciones.Add(itemDirecciones);
            return datosDirecciones;
        }
        /// <summary>
        /// listado de movimientos especiales a trasmitir
        /// </summary>
        /// <returns>lista</returns>
        public List<Lote> GetLotesMovEspeciales()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("po_movimientos", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_movimientos_especiales.sp_movimientos_bepsa";
                return SqlMapper.Query<Lote>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        /// <summary>
        /// metodo de actualizacion de las transmisiones.
        /// </summary>
        /// <param name="numeroTarjeta"></param>
        /// <param name="codRespuesta"></param>
        /// <param name="msjRespuesta"></param>
        public void ActualizaTransmisionMovEspeciales(string numeroTarjeta, string codRespuesta, string msjRespuesta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            oracleConexion.Open();
            var datos = oracleConexion.Execute(Queries.ActualizaTransmisionMovimiento, new
            {
                codigoRespuesta = codRespuesta,
                mensajeRespuesta = msjRespuesta,
                nroTarjeta = numeroTarjeta
            });
        }

        public async Task<List<EstadoRegistrosPendientes>> GetTarjetasPendientesEstadoAsync(string tipo)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_tipo", OracleDbType.Varchar2, ParameterDirection.Input, tipo);
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_abm_credito.sp_get_tc_pendientes_estado";
            var result = await SqlMapper.QueryAsync<EstadoRegistrosPendientes>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);

            return result.ToList();
        }

        public async Task ActualizaEstadoAsync(float IdSesion,
                                               string Codigo,
                                               string Mensaje,
                                               float LogKey,
                                               string tipoCredito)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_id_sesion", OracleDbType.Varchar2, ParameterDirection.Input, IdSesion);
            dyParam.Add("pi_cod_respuesta", OracleDbType.Varchar2, ParameterDirection.Input, Codigo);
            dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, Mensaje);
            dyParam.Add("pi_log_key", OracleDbType.Varchar2, ParameterDirection.Input, LogKey);
            dyParam.Add("pi_tipo", OracleDbType.Varchar2, ParameterDirection.Input, tipoCredito);

            var query = "bepsa.pkg_abm_credito.sp_update_pendientes_estado";
            await SqlMapper.QueryAsync<EstadoTransmisionesResponse>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);
        }

        /// <summary>
        /// listado de pagos por TC a trasmitir
        /// </summary>
        /// <returns>LotePagoTC</returns>
        public async Task<List<LotePagoTC>> GetLotesPagoTC()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            var resultado = await oracleConexion.QueryAsync<LotePagoTC>(Queries.ListaTransmisionPagos);

            return resultado?.ToList();
        }
        /// <summary>
        /// Actualiza los registros que fueron transmitidos a Bepsa.
        /// </summary>
        public async Task ActualizaPagosTcAsync(string numeroTarjeta, string codigoRespuesta, string mensaje, string monto)
        {
            using var oracleConexion = new OracleConnection(this._connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_numerotarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
            dyParam.Add("pi_codigo_respuesta", OracleDbType.Char, ParameterDirection.Input, codigoRespuesta);
            dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, mensaje);
            dyParam.Add("pi_monto", OracleDbType.Varchar2, ParameterDirection.Input, monto);

            var query = "bepsa.pkg_pagos_tc.sp_procesar_pago";
           await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }
        /// <summary>
        /// Consulta si el proceso esta aun en ejecucion.
        /// </summary>
        /// <returns> D= Disponible O = Ocupado </returns>
        public async Task<string> ConsultarEstadoProceso()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<string>(Queries.ConsultaEstadoProcesoPagos);
        }

        /// <summary>
        /// Actualiza el estado del Proceso.
        /// </summary>
        /// <param name="estadoProceso"> D = DISPONIBLE O= OCUPADO</param>
        public async Task ActualizaEstadoProceso(string estadoProceso)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaEstadoProcesoPagos, new
            {
                estadoProceso
            });
        }
        private List<CargoPersonalizado> ExoneracionCargosPersoalizados(string tipoCargoID)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("po_cursor", OracleDbType.RefCursor, ParameterDirection.Output);
                dyParam.Add("pi_tipo_cargo_id", OracleDbType.Varchar2, ParameterDirection.Input, tipoCargoID);
                var query = "bepsa.pkg_abm_credito.sp_cobroCargosPersonalizados";
                return SqlMapper.Query<CargoPersonalizado>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            }
        }

        /// <summary>
        /// Elimina el proceso si no hay nada para enviar
        /// </summary>
        /// <param name="nroProceso"> El nro de proceso que eliminaremos</param>
        public void EliminaProceso(double nroProceso)
        {
            using var oracleConexion = new OracleConnection(this._connectionString);
            oracleConexion.Open();
            var dyParam = new DynamicParameters();
            dyParam.Add("pi_nroProces", nroProceso);

            var query = "bepsa.pkg_abm_credito.sp_eliminaProceso";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        public async Task<string> ObtenerParametrica(int idParametrica, int secuencia)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<string>(Queries.ObtenerParametrica, new
            {
                idParametrica,
                secuencia
            });
        }
    }
}