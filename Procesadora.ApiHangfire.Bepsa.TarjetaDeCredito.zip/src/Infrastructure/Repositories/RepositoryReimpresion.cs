﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Continental.API.Core.Interfaces;
using Continental.API.Infrastructure.Data;
using Continental.API.Infrastructure.DatabaseHelpers;
using Continental.API.Infrastructure.Settings;
using Continental.API.Infrastructure.Settings.DataBase;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;

namespace Continental.API.Infrastructure.Repositories
{
    public class RepositoryReimpresion : IRepositoryReimpresion
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;
        private readonly IOptions<Configuraciones> _configuraciones;
        private readonly OracleDbContextActive _dbActive;
        public RepositoryReimpresion(IOptions<Configuraciones> configuraciones, IConfiguration configuration, HttpClient _apiClient,
                                     OracleDbContextActive dbActive)
        {
            _connectionStringActive = configuration.GetConnectionString("Active");
            _connectionString = configuration.GetConnectionString("Oracle");
            this._configuraciones = configuraciones;
            _dbActive = dbActive;
        }
        /// <summary>
        /// Devuelve numeros de procesos pendiente de retransmision
        /// <returns></returns>
        public List<PendientesReimpresion> GetPendientesReenvio()
        {
            var resultado = _dbActive.EnviadorReimpresionBepsa
                .AsNoTracking()
                .Where(e => e.Estado == (int)EstadoEnviadorReimpresion.Pendiente &&
                    _dbActive.LogReimpresionPrincipal
                        .Where(r => r.NumeroProceso == e.NumeroProceso &&
                                    ! _dbActive.DtParametroFecha
                                        .Where(dt => dt.Id == ParametricaRenovacion.Id &&
                                                     dt.Tipo == ParametricaRenovacion.TipoMotivoTransferencia &&
                                                     dt.ValorTres == ParametricaRenovacion.Prendido)
                                        .Select(dt => dt.Valor)
                                        .Contains(r.MotivoTransferencia))
                        .Any())
                .Select(e => new PendientesReimpresion
                {
                    NumeroProceso = e.NumeroProceso.ToString()
                })
                .ToList();

                return resultado;
        }
        /// <summary>
        /// listado de pendietes de reimpresion
        /// </summary>
        /// <returns>lista</returns>
        public List<LoteReimpresion> GetLotesReimpresion(double numeroProceso)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_nroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

                var query = "bepsa.pkg_reimpresiones.sp_reenvio_reimpresion";
                return SqlMapper.Query<LoteReimpresion>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();
            }
        }
        /// <summary>
        /// actualizamos el log con el reenvio
        /// </summary>
        /// <returns>lista</returns>
        public void ActualizaTransmisionReimpresion(string tarjetaActual)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_tarjetaActual", OracleDbType.Varchar2, ParameterDirection.Input, tarjetaActual);

                var query = "bepsa.pkg_reimpresiones.sp_reimp_updatelog";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        /// <summary>
        /// crea nuevo lote con numero de proceso para transmitir
        /// </summary>
        /// <returns>lista</returns>
        public void GetNuevoProcesoReimpresion()
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();

                var query = "bepsa.pkg_reimpresiones.sp_reimp_envios";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        public void InsertaLogProceso(double numeroProceso, double cantidadRegistros, string mensajeResultado,string codigoResultado,string numeroTarjeta)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                var credencial = _configuraciones.Value.CredencialesToken.Credenciales.Where(t => t.Key.Equals(KeyToken.SERVICIO.ToString().ToUpper())).FirstOrDefault();
                string usuarioServicio = credencial.UsuarioServicioReimpresion;
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_numeroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_usuarioServicio", OracleDbType.Varchar2, ParameterDirection.Input, usuarioServicio);
                dyParam.Add("pi_cantidadRegistros", OracleDbType.Double, ParameterDirection.Input, cantidadRegistros);
                dyParam.Add("pi_mensajeResultado", OracleDbType.Varchar2, ParameterDirection.Input, mensajeResultado);
                dyParam.Add("pi_codigoResultado", OracleDbType.Varchar2, ParameterDirection.Input, codigoResultado);
                dyParam.Add("pi_numeroTarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
                var query = "bepsa.pkg_reimpresiones.sp_reimp_insertaLogProceso";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        public void ActualizaDatosEnvio(double numeroProceso, string estadoEnvio)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_numeroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_estadoEnvio", OracleDbType.Varchar2, ParameterDirection.Input, estadoEnvio);

                var query = "bepsa.pkg_reimpresiones.sp_reimp_upd_Envio";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        public void ErrorTransmision(double numeroProceso, string mensajeResultado)
        {
            using (var oracleConexion = new OracleConnection(_connectionString))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_numeroProceso", OracleDbType.Double, ParameterDirection.Input, numeroProceso);
                dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, mensajeResultado);

                var query = "bepsa.pkg_reimpresiones.sp_reimp_mailerror";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
    }
}
