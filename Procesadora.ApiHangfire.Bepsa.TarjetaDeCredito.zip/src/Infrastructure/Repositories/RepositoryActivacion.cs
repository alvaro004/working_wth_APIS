﻿using Continental.API.Core.Entities;
using Continental.API.Core.Enums;
using Continental.API.Core.Interfaces;
using Continental.API.Infrastructure.DatabaseHelpers;
using Continental.API.Infrastructure.Settings;
using Continental.API.Infrastructure.Settings.DataBase;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;

namespace Continental.API.Infrastructure.Repositories
{
    public class RepositoryActivacion : IRepositoryActivacion
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;
        private readonly IOptions<Configuraciones> _configuraciones;

        public RepositoryActivacion(IOptions<Configuraciones> configuraciones, IConfiguration configuration, HttpClient _apiClient)
        {
            _connectionStringActive = configuration.GetConnectionString("Active");
            _connectionString = configuration.GetConnectionString("Oracle");
            _configuraciones = configuraciones;
        }
        /// <summary>
        /// Devuelve la cantidad de cuentas pendientes de activación.
        /// </summary>
        /// <returns></returns>
        public List<SecuenciasPendientes> GetPendientesEnvio()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select c.secuencia Numero from tarjeta.tarcrd_activaciones_ws c where c.estado = 0 and nvl(c.procesadora, 3) = 3 order by c.secuencia asc";

                oracleConexion.Open();
                return oracleConexion.Query<SecuenciasPendientes>(consulta).AsList();
            }
        }
        /// <summary>
        /// Retorna los datos de cuentas de credito a transmitir.
        /// </summary>
        /// <param name="nroProc"></param>
        /// <returns></returns>
        public List<CuentaTarjeta> GetDatosCuentaTarjetaCredito()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("po_datos_cta", OracleDbType.RefCursor, ParameterDirection.Output);
                var query = "BEPSA.PKG_ACTIVACION_TARJETA.SP_ACTI_CTA_TC_PENDIENTE";
                List<CuentaTarjeta> datosCuenta = new List<CuentaTarjeta>();
                datosCuenta = SqlMapper.Query<CuentaTarjeta>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

                return datosCuenta;
            }
        }
        public void SetEstadoNroRegistro(double secuencia, EstadoActivacion estado, string webServiceMensaje)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                var credencial = _configuraciones.Value.CredencialesToken.Credenciales.Where(t => t.Key.Equals(KeyToken.SERVICIO.ToString().ToUpper())).FirstOrDefault();
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_secuencia", OracleDbType.Double, ParameterDirection.Input, secuencia);
                dyParam.Add("pi_estado", OracleDbType.Int16, ParameterDirection.Input, (int)estado);
                dyParam.Add("pi_usuarioWS", OracleDbType.Varchar2, ParameterDirection.Input, credencial.UsuarioActivacion);
                dyParam.Add("pi_msgbancard", OracleDbType.Varchar2, ParameterDirection.Input, webServiceMensaje);

                var query = "BEPSA.PKG_ACTIVACION_TARJETA.SP_ACTIV_SET_ESTADO";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        public List<SucursalTarjeta> GetSucursalActivacion(string tarjeta, string digitoVerificador)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select nvl(max(t.stdo_sucukey),'01') Sucursal " +
                                    "from tarjeta.tarcrdutmstdo t " +
                                   "where t.stdo_nrotar = '" + tarjeta + 
                                     "' and t.stdo_nrodig = '" + digitoVerificador + "'";

                oracleConexion.Open();
                return oracleConexion.Query<SucursalTarjeta>(consulta).AsList();
            }
        }
        public void ConfirmaActivacion(string numeroTarjeta, string digitoVerificador, string numeroCuenta, string sucursal)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();

                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_nroTar", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
                dyParam.Add("pi_digVer", OracleDbType.Varchar2, ParameterDirection.Input, digitoVerificador);
                dyParam.Add("pi_nroCuenta", OracleDbType.Varchar2, ParameterDirection.Input, numeroCuenta);
                dyParam.Add("pi_suc", OracleDbType.Varchar2, ParameterDirection.Input, sucursal);
                dyParam.Add("po_control", OracleDbType.RefCursor, direction: ParameterDirection.Output);

                var query = "BEPSA.PKG_ACTIVACION_TARJETA.SP_CONFIRM_ACTIVACION";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
                
            }
        }
        public void EnviaCorreos(string numeroTarjeta, EstadoActivacion tipo, string mensajeResp, double nroSecuencia)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("pi_tarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);
                dyParam.Add("pi_tipoCorreo", OracleDbType.Double, ParameterDirection.Input, (int)tipo);
                dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, mensajeResp);
                dyParam.Add("pi_secuencia", OracleDbType.Double, ParameterDirection.Input, nroSecuencia);

                var query = "BEPSA.PKG_ACTIVACION_TARJETA.sp_envia_correos";
                SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
            }
        }
        public List<DatosTarjeta> GetDatosTarjetaCredito()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                var dyParam = new OracleDynamicParameters();
                dyParam.Add("po_datos_cta", OracleDbType.RefCursor, ParameterDirection.Output);
                var query = "BEPSA.PKG_ACTIVACION_TARJETA.SP_ACTI_TC_PENDIENTE";
                List<DatosTarjeta> datosTarjeta = new List<DatosTarjeta>();
                datosTarjeta = SqlMapper.Query<DatosTarjeta>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

                return datosTarjeta;
            }
        }
        /// <summary>
        /// Actualiza el estado del registro cuya cuenta ya fue transmitida, para habilitar la activación de la TC
        /// </summary>
        /// <param name="nroSecuencia"></param>
        public void EstadoCtaTarActivacion(double nroCuenta, EstadoActivacion estado, string mensaje)
        {
            string sql = " update tarjeta.tarcrd_activaciones_ws c " +
                "set c.estado = " + (int)estado + ", " +
                    "c.msg_bancard = '" + mensaje +
                 "' where c.estado = 0 and c.cuentabancard = " + nroCuenta + "";
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                oracleConexion.Open();
                oracleConexion.Execute(sql);
            }
        }
        /// <summary>
        /// Devuelve la cantidad de tarjetas pendientes de activación.
        /// </summary>
        /// <returns></returns>
        public List<SecuenciasPendientes> GetTarjetasPendientesEnvio()
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select c.secuencia Numero from tarjeta.tarcrd_activaciones_ws c where c.estado = 2 and nvl(c.procesadora, 3) = 3 order by c.secuencia asc";

                oracleConexion.Open();
                return oracleConexion.Query<SecuenciasPendientes>(consulta).AsList();
            }
        }
        public List<NumeroCuentaTarjeta> GetNumeroCuentaTarjeta(double nroProceso)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select c.cuentabancard NumeroCuenta from tarjeta.tarcrd_activaciones_ws c where c.secuencia = " + nroProceso +" and c.estado = 1 and nvl(c.procesadora, 3) = 3 order by c.secuencia asc";

                oracleConexion.Open();
                return oracleConexion.Query<NumeroCuentaTarjeta>(consulta).AsList();
            }
        }
        public List<SecuenciasPendientes> GetNumeroSecuencia(string tarjeta)
        {
            using (var oracleConexion = new OracleConnection(_connectionStringActive))
            {
                string consulta = "select nvl(max(c.secuencia),'00000') Numero " +
                                    "from tarjeta.tarcrd_activaciones_ws c " +
                                   "where c.estado = 2 and c.nrotarjeta = '" + tarjeta + "'";

                oracleConexion.Open();
                return oracleConexion.Query<SecuenciasPendientes>(consulta).AsList();
            }
        }

    }
}
