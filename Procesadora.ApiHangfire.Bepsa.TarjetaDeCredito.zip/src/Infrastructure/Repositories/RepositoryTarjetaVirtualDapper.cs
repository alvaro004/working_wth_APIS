﻿using Continental.API.Infrastructure.DatabaseHelpers;
using Dapper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.TarjetaVirtual;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories
{
    public class RepositoryTarjetaVirtualDapper : IRepositoryTarjetaVirtualDapper
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;

        public RepositoryTarjetaVirtualDapper(IConfiguration configuraciones)
        {
            _connectionStringActive = configuraciones.GetConnectionString("Active");
            _connectionString = configuraciones.GetConnectionString("Oracle");
        }


        /// <summary>
        /// Setea la fecha en la BD
        /// </summary>
        /// <param name="db">Conexion Oracle</param>
        public void SetOracleSession(OracleConnection db)
        {
            var sessionInfo = db.GetSessionInfo();
            sessionInfo.DateFormat = "DD-MM-RRRR";
            db.SetSessionInfo(sessionInfo);
        }

        public async Task<List<TarjetaVirtualPendiente>> TarjetaVirtualPendiente()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            const int procesadora = 3;
            const int enviar = 1;
            const string proceso = "S";
            const string movimiento = "A";
            const string embozar = "N";

            var resultado = await oracleConexion.QueryAsync<TarjetaVirtualPendiente>(Queries.TarjetaVirualPendiente, new
            {
                procesadora,
                enviar,
                proceso,
                movimiento,
                embozar
            });

            return resultado.ToList();
        }

        public async Task<Contarje> DatosParaContarje(string tarjeta, string cuenta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var resultado = await oracleConexion.QueryAsync<Contarje>(Queries.ObtenerDatoParaContarje, new
            {
                tarjeta,
                cuenta
            });

            return resultado?.FirstOrDefault();
        }

        public async Task GrabarContarje(Contarje contarje)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var FechaEmisionCompleto = contarje.FechaEmisionCompleto.ToString("dd/MM/yyyy");

            await oracleConexion.QueryAsync(Queries.InsertarContarje, new
            {
                contarje.Cuenta,
                contarje.Tarjeta,
                contarje.Digito,
                contarje.FechaEmision,
                contarje.Linea,
                contarje.Tasa,
                contarje.Vencimiento,
                contarje.Saldo,
                contarje.Situacion,
                contarje.Cedula,
                contarje.CodigoCliente,
                contarje.Sucursal,
                contarje.EsPrincipal,
                contarje.MontoMora,
                contarje.DiaMora,
                contarje.NombrePlastico,
                contarje.Direccion,
                contarje.Telefono,
                contarje.Judicial,
                contarje.Estado,
                contarje.FechaUltimoPago,
                contarje.SaldoUltimoExtracto,
                contarje.PagoMinimo,
                contarje.PagoAcumuladoMes,
                FechaEmisionCompleto,
                contarje.MontoLineaCuota,
                contarje.MontoDeudaCuota,
                contarje.IndicadorEstado,
                contarje.Codeudor,
                contarje.DocumentoCodeudor,
                contarje.Renovacion
            });
        }

        public async Task<PbTarjeta> DatosParaPbTarjeta(string tarjeta, string cuenta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var resultado = await oracleConexion.QueryAsync<PbTarjeta>(Queries.ObtenerDatoParaPbTarjeta, new
            {
                tarjeta,
                cuenta
            });

            return resultado?.FirstOrDefault();
        }

        public async Task GrabarPbtarjeta(PbTarjeta pbTarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            string FechaRecibo = pbTarjeta.FechaRecibo.ToString("dd/MM/yyyy");
            string FechaEmbozado = pbTarjeta.FechaEmbozado.ToString("dd/MM/yyyy");
            string FechaPin = pbTarjeta.FechaPin.ToString("dd/MM/yyyy");
            string FechaEmision = pbTarjeta.FechaEmision.ToString("dd/MM/yyyy");
            string FechaAdd = pbTarjeta.FechaAdd.ToString("dd/MM/yyyy");
            string FechaSituacion = pbTarjeta.FechaSituacion.ToString("dd/MM/yyyy");

            await oracleConexion.QueryAsync(Queries.InsertarPbTarjeta, new
            {
                pbTarjeta.NumeroTarjeta,
                pbTarjeta.Tarjeta,
                pbTarjeta.Digito,
                pbTarjeta.NombreTarjeta,
                pbTarjeta.CodigoEntidad,
                pbTarjeta.Afinidad,
                pbTarjeta.Marca,
                pbTarjeta.CodigoProducto,
                pbTarjeta.Cuenta,
                pbTarjeta.IdPersona,
                pbTarjeta.Documento,
                pbTarjeta.TipoTarjeta,
                pbTarjeta.NombrePlastico,
                pbTarjeta.ValeDesde,
                pbTarjeta.Duracion,
                pbTarjeta.ValeHasta,
                pbTarjeta.ValeHastaEmbozado,
                pbTarjeta.Personalizada,
                pbTarjeta.Renovar,
                pbTarjeta.TipoPlastico,
                pbTarjeta.IdTipoDocumento,
                pbTarjeta.NombreBandaMagnetica,
                FechaRecibo,
                FechaEmbozado,
                FechaPin,
                FechaEmision,
                pbTarjeta.TipoUltimoEmbozado,
                pbTarjeta.CobrarFraude,
                pbTarjeta.Recuperada,
                pbTarjeta.Vencida,
                pbTarjeta.IdTipoBloqueo,
                pbTarjeta.SituacionTarjeta,
                pbTarjeta.Reservado1,
                pbTarjeta.UserAdd,
                FechaAdd,
                pbTarjeta.ModificacionUsuario,
                pbTarjeta.FechaModificacion,
                FechaSituacion,
                pbTarjeta.ObservacionSituacion,
                pbTarjeta.EmbozarPlastico,
                pbTarjeta.Reservado2,
                pbTarjeta.Reservado3,
                pbTarjeta.Reservado4,
                pbTarjeta.Reservado5,
                pbTarjeta.Reservado6,
                pbTarjeta.Reservado7,
                pbTarjeta.IdMotivoNovedad,
                pbTarjeta.IdMotivoEntidad,
                pbTarjeta.IdFormatoRecibo,
                pbTarjeta.IdFormatoPin,
                pbTarjeta.IdPromotor,
                pbTarjeta.IdMotivoNovedad2,
                pbTarjeta.IdMotivoEntidad2,
                pbTarjeta.ObservacionMotivoTarjeta,
                pbTarjeta.DisenhoDataCard,
                pbTarjeta.CodigoCliente,
                pbTarjeta.FechaCreacion,
                pbTarjeta.UsuarioCreacion,
                pbTarjeta.FechaModificacionPb,
                pbTarjeta.UsuarioModificacion,
                pbTarjeta.Firma,
                pbTarjeta.Reservado8,
                pbTarjeta.Reservado9,
                pbTarjeta.FormaBloqueo
            });
        }

        public async Task<DatosPersona> DatosPersona(string codigoCliente)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var resultado = await oracleConexion.QueryAsync<DatosPersona>(Queries.DatosPersona, new
            {
                codigoCliente
            });

            return resultado?.FirstOrDefault();
        }

        public async Task<bool> VerificaContarje(string tarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var resultado = await oracleConexion.ExecuteScalarAsync<string>(Queries.VerificaContarje, new
            {
                tarjeta
            });

            return resultado != "0";
        }

        public async Task<bool> VerificaPbTarjeta(string tarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            SetOracleSession(oracleConexion);

            var resultado = await oracleConexion.ExecuteScalarAsync<string>(Queries.VerificaPbTarjeta, new
            {
                tarjeta
            });

            return resultado != "0";
        }

        public async Task<string> ObtenerParametrica(int idParametrica, int secuencia)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<string>(Queries.ObtenerParametrica, new
            {
                idParametrica,
                secuencia
            });
        }

        public async Task EnvioPush(string codigCliente, string tipoNotificacion, string mensaje)
        {
            using var oracleConexion = new OracleConnection(this._connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_cliekey", OracleDbType.Varchar2, ParameterDirection.Input, codigCliente);
            dyParam.Add("pi_tiponotifc", OracleDbType.Varchar2, ParameterDirection.Input, tipoNotificacion);
            dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, mensaje);

            var query = "userweb.pkg_push_notification.sp_pushmensaje";
            await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        public async Task InsertarReGrabacionPrincipal(Reimpresion reimpresion)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.ExecuteScalarAsync<string>(Queries.InsertarReImpresionPrincipal, new
            {
                reimpresion.Id,
                reimpresion.Tarjeta,
                reimpresion.TarjetaNuevo,
                reimpresion.CodigoCliente,
                reimpresion.Motivo,
                reimpresion.Importe,
                reimpresion.Costo,
                reimpresion.Vencimiento,
                reimpresion.FechaValidacion,
                reimpresion.UsuarioProceso,
                reimpresion.MotivoTransferencia,
                reimpresion.Ald,
                reimpresion.Ofac,
                reimpresion.Onu,
                reimpresion.Clasbcp,
                reimpresion.Mora,
                reimpresion.TarjetaVencida,
                reimpresion.TarjetaBloqueada,
                reimpresion.Observacion,
                reimpresion.UsuarioRegistro,
                reimpresion.FechaRegistro,
                reimpresion.SucursalRegistro,
                reimpresion.UsuarioAutorizo,
                reimpresion.FechaAutorizo,
                reimpresion.SucursalAutorizo,
                reimpresion.Estado,
                reimpresion.Procesadora,
            });
        }
        public async Task InsertarReGrabacionPrincipalLog(Reimpresion reimpresion)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.ExecuteScalarAsync<string>(Queries.InsertarReImpresionPrincipalLog, new
            {
                reimpresion.LogKey,
                reimpresion.Id,
                reimpresion.Tarjeta,
                reimpresion.TarjetaNuevo,
                reimpresion.Importe,
                reimpresion.Costo,
                reimpresion.Vencimiento,
                reimpresion.FechaValidacion,
                reimpresion.UsuarioProceso,
                reimpresion.MotivoTransferencia,
                reimpresion.NumeroProceso,
                reimpresion.Procesado,
                reimpresion.Enviar,
                reimpresion.Procesadora
            });
        }
        public async Task InsertarReGrabacionCourier(Reimpresion reimpresion)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.ExecuteScalarAsync<string>(Queries.InsertarReImpresionCourier, new
            {
                reimpresion.Id,
                reimpresion.Tarjeta,
                reimpresion.NuevaTarjeta,
                reimpresion.CodigoCliente,
                reimpresion.Biblioteca,
                reimpresion.Enviar,
                reimpresion.UsuarioRegistro,
                reimpresion.FechaRegistro
            });
        }

        public async Task<int> ObtenerNuevoIdRegrabacion()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<int>(Queries.ObtenerSiguienteIdReimpresion);
        }

        public async Task<string> ValidarTarjetaInternacional(string afinidad) 
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
        
            var resultado = await oracleConexion.ExecuteScalarAsync<string>(Queries.ValidarTarjetaInternacional, new
            {
                afinidad
            });
        
            return resultado;
        }

        public async Task<bool> ValidarTarjetaDigitalHibrida(string numeroTarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            var resultado = await oracleConexion.ExecuteScalarAsync<bool>(Queries.ValidarTarjetaDigitalHibrida, new
            {
                numeroTarjeta
            });

            return resultado;
        }

        public async Task<int> ObtenerNuevoLogKey()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<int>(Queries.ObtenerSiguienteLogKeyReimpresion);
        }

        public async Task<int> ObtenerNumeroProceso()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<int>(Queries.ObtenerNumeroProcesoReimpresion);
        }
    }
}
