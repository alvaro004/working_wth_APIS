﻿using Continental.API.Core.Interfaces;
using Continental.API.Infrastructure.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.ListaBlanca;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Continental.API.Infrastructure.Repositories
{
    public class RepositoryListaBlanca : IRepositoryListaBlanca
    {
        private readonly OracleDbContextBi _connectionStringBI;
        private readonly OracleDbContext _dbContext;
        private readonly OracleDbContextActive _dbActive;
        private readonly string _connectionString;

        public RepositoryListaBlanca(OracleDbContextBi dbBi, OracleDbContext dbContext, OracleDbContextActive oracleDbContextActive, IConfiguration configuraciones, HttpClient _apiClient)
        {
            _connectionStringBI = dbBi;
            _dbContext = dbContext;
            _dbActive = oracleDbContextActive;
            _connectionString = configuraciones.GetConnectionString("OracleBi");
        }

        public async Task<List<DatosListaBlanca>> ObtenerListaPendientes(ParametricaListaBlanca parametrica) =>

            await _connectionStringBI.ListaBlanca
               .AsNoTracking()
               .Where(t => t.estado == parametrica.Estado &&
                           t.TipoOperacion == parametrica.OperacionTipo &&
                           t.Intentos < parametrica.Intento
            ).Take(parametrica.Cantidad).Select(p => new DatosListaBlanca
            {
                Id = p.Id,
                NumeroTarjeta = p.NumeroTarjeta,
                TipoMarca = p.TipoMarca,
                Intentos = p.Intentos,
                FechaFin = p.FechaFin,
                FechaInicio = p.FechaInicio,
                CodigoComercio = p.CodigoComercio,
                NombreComercio = p.NombreComercio,
                BinAdquirente = p.BinAdquirente,
                Usuario = p.Usuario,
                IdTarjeta = p.IdTarjeta
            }).ToListAsync();

        public async Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia) =>
            await _dbActive.DtParametroFecha
               .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == id && e.Secuencia == secuencia);

        /// <summary>
        /// dato de nro de documento de la tarjeta.
        /// </summary>
        /// <param name="NumeroTarjeta"></param>
        /// <returns></returns>
        public async Task<string> ObtenerNumeroDocumento(string NumeroTarjeta, string digito) =>
            await _dbActive.DatoContarje
            .AsNoTracking()
            .Where(e => e.NumeroTarjeta == NumeroTarjeta && e.DigitoVerificador == digito)
            .Select(e => e.NumeroDocumento)
            .FirstOrDefaultAsync();

        public async Task<string> ObtenerNroDocumentoTd(string NumeroTarjeta) =>
            await _dbActive.DatoTarjetaDebito
            .AsNoTracking()
            .Where(e => e.NumeroTarjeta == NumeroTarjeta)
            .Select(e => e.NumeroDocumento)
            .FirstOrDefaultAsync();

        public async Task ActualizaEstadoListaBlanca(DatosListaBlanca dato)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaEstadoListaBlanca, new
            {
                dato.estado,
                dato.CodigoRetorno,
                dato.MensajeRetorno,
                dato.IdTarjeta,
                dato.FechaModificacion,
                dato.Intentos,
                dato.Id
            });
        }

        public async Task<DatosListaBlanca> ObtenerOperacionPendiente(decimal id)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            var resultado = await oracleConexion.QueryAsync<DatosListaBlanca>(Queries.ObtenerOpPendiente, new
            {
                id
            });

            return resultado?.FirstOrDefault();
        }
    }
}
