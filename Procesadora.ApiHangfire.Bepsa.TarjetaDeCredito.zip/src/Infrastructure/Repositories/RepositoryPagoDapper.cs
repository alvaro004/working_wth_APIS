﻿using Continental.API.Infrastructure.DatabaseHelpers;
using Dapper;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories
{
    public class RepositoryPagoDapper : IRepositoryPagoDapper
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;

        public RepositoryPagoDapper(IConfiguration configuraciones)
        {
            _connectionStringActive = configuraciones.GetConnectionString("Active");
            _connectionString = configuraciones.GetConnectionString("Oracle");
        }

        /// <summary>
        /// Consulta si el proceso esta aun en ejecucion.
        /// </summary>
        /// <returns> D= Disponible O = Ocupado </returns>
        public async Task<string> ConsultarEstadoProceso()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            return await oracleConexion.ExecuteScalarAsync<string>(Queries.ConsultaEstadoProcesoPagos);
        }

        /// <summary>
        /// Actualiza el estado del Proceso.
        /// </summary>
        /// <param name="estadoProceso"> D = DISPONIBLE O= OCUPADO</param>
        public async Task ActualizaEstadoProceso(string estadoProceso)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaEstadoProcesoPagos, new
            {
                estadoProceso
            });
        }

        public async Task<PagoEF> ObtenerPago(decimal comprobante)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            var resultado = await oracleConexion.QueryAsync<PagoEF>(Queries.ObtenerPago, new
            {
                comprobante
            });

            return resultado?.FirstOrDefault();
        }

        public async Task ActualizarEstadoPago(PagoEF pagoEF)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaPagoProcesado, new
            {
                pagoEF.EstadoPago,
                pagoEF.PagoProcesado,
                pagoEF.Intento,
                pagoEF.FechaDisponible,
                pagoEF.FechaExtracto,
                pagoEF.FechaPago,
                pagoEF.CodigoResuesta,
                pagoEF.MensajeRespuesta,
                pagoEF.Comprobante
            });
        }

        public async Task ActualizarCajaDesc(CajaDescEF cajaDescEF)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaPagoProcesadoCajaDesc, new
            {
                cajaDescEF.Enviado,
                cajaDescEF.FechaEnvio,
                cajaDescEF.HoraEnvio,
                cajaDescEF.UsuarioEnvio,
                cajaDescEF.UsuarioRegistro,
                cajaDescEF.FechaRegistro,
                cajaDescEF.Operacion,
                cajaDescEF.Comprobante,
                cajaDescEF.Recibo,
                cajaDescEF.Monto,
                cajaDescEF.Efectivo,
                cajaDescEF.Cheque,
                cajaDescEF.Cheque24,
                cajaDescEF.Cheque48
            });
        }

        public async Task<Fechus> Fechus()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            var resultado = await oracleConexion.QueryAsync<Fechus>(Queries.Fechus);

            return resultado?.FirstOrDefault();
        }

        public async Task EnvioCorreo(string de, string para, string asunto, string copia, string body, string esHtml)
        {
            using var oracleConexion = new OracleConnection(this._connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("a_de", OracleDbType.Varchar2, ParameterDirection.Input, de);
            dyParam.Add("a_destino", OracleDbType.Char, ParameterDirection.Input, para);
            dyParam.Add("a_asunto", OracleDbType.Varchar2, ParameterDirection.Input, asunto);
            dyParam.Add("a_concopia", OracleDbType.Varchar2, ParameterDirection.Input, copia);
            dyParam.Add("a_cuerpo", OracleDbType.Varchar2, ParameterDirection.Input, body);
            dyParam.Add("a_eshtml", OracleDbType.Varchar2, ParameterDirection.Input, esHtml);

            var query = "userweb.temporal.EmailAgregar2";
            await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        public async Task ActualizaMotivoPago(PagoEF pago)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaMensajePago, new
            {
                pago.MensajeRespuesta,
                pago.CodigoResuesta,
                pago.Intento,
                pago.FechaModificacion,
                pago.Comprobante
            });
        }

        public async Task ActualizaEstadoPago(PagoEF pago)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            await oracleConexion.QueryAsync(Queries.ActualizaEstadoPago, new
            {
                pago.EstadoPago,
                pago.PagoProcesado,
                pago.MensajeRespuesta,
                pago.CodigoResuesta,
                pago.Intento,
                pago.FechaModificacion,
                pago.Comprobante
            });
        }
    }
}
