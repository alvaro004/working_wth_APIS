﻿using Continental.API.Core.Entities;
using Continental.API.Core.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Continental.API.Infrastructure.Data;
using Continental.API.Infrastructure.DatabaseHelpers;
using AutoMapper;
using Continental.API.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Enums;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Renovacion;

namespace Continental.API.Infrastructure.Repositories
{
    public class RenovacionRepository : IRenovacionRepository
    {
        private readonly OracleDbContextActive _dbActive;
        private readonly string _connectionStringActive;
        private readonly string _connectionString;

        public RenovacionRepository(OracleDbContextActive dbActive, IConfiguration configuration)
        {
            _connectionStringActive = configuration.GetConnectionString("Active");
            _connectionString = configuration.GetConnectionString("Oracle");
            _dbActive = dbActive;
        }

        /// <summary>
        /// Retorna si es día de transmisión de renovaciones de tarjeta de crédito
        /// </summary>
        public string GetEsDiaDeRenovacion()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            oracleConexion.Open();

            var dyParam = new DynamicParameters();
            dyParam.Add("@result", dbType: DbType.String, direction: ParameterDirection.ReturnValue, size: 2000);

            var query = "tarjeta.pkg_reimpresiones.f_es_dia_evitarejecucion";
            SqlMapper.ExecuteScalar<string>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);

            return dyParam.Get<string>("@result");
        }

        /// <summary>
        /// Obtiene el numero de proceso pendiente de transmisión
        /// </summary>
        public List<PendienteRenovacion> GetNumeroProcesoPendientesReenvio()
        {
            var resultado = _dbActive.EnviadorReimpresionBepsa
                .AsNoTracking()
                .Where(e => e.Estado == (int)EstadoEnviadorReimpresion.Pendiente &&
                            _dbActive.LogReimpresionPrincipal
                                .Where(r => r.NumeroProceso == e.NumeroProceso &&
                                            _dbActive.DtParametroFecha
                                                .Where(dt => dt.Id == ParametricaRenovacion.Id &&
                                                             dt.Tipo == ParametricaRenovacion.TipoMotivoTransferencia &&
                                                             dt.ValorTres == ParametricaRenovacion.Prendido)
                                                .Select(dt => dt.Valor)
                                                .Contains(r.MotivoTransferencia))
                                .Any())
                .Select(e => new PendienteRenovacion
                {
                    NumeroProceso = e.NumeroProceso
                })
                .ToList();

            return resultado;
        }

        /// <summary>
        /// Genera el nuevo numero de proceso para la transmisión
        /// </summary>
        public void GetNuevoProcesoRenovacion()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();

            var query = "bepsa.pkg_reimpresiones.sp_reimp_envios";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Obtiene la lista de tarjetas que serán transmitidas a la procesaora
        /// </summary>
        public List<LoteRenovacionBepsaRequest> GetLotesReimpresion(decimal numeroProceso)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_nroProceso", OracleDbType.Decimal, ParameterDirection.Input, numeroProceso);
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_reimpresiones.sp_reenvio_reimpresion_v2";
            var result = SqlMapper.Query<LoteRenovacionBepsaRequest>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure).ToList();

            return result;
        }

        /// <summary>
        /// Actualiza el log de la tabla de reimpresiones
        /// </summary>
        public void ActualizaTransmisionReimpresion(string tarjetaActual)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_tarjetaActual", OracleDbType.Varchar2, ParameterDirection.Input, tarjetaActual);

            var query = "bepsa.pkg_reimpresiones.sp_reimp_updatelog";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Envia mail con el error
        /// </summary>
        public void GeneraMail(string asuntoMail,
                               string cuerpoMail)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_asunto", OracleDbType.Varchar2, ParameterDirection.Input, asuntoMail);
            dyParam.Add("pi_cuerpo", OracleDbType.Varchar2, ParameterDirection.Input, cuerpoMail);

            var query = "bepsa.pkg_reimpresiones.sp_genera_mail";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Actualiza el estado de la tabla cabecera
        /// </summary>
        public void ActualizaDatosEnvio(decimal numeroProceso,
                                        decimal idSeguimiento,
                                        string  estadoEnvio)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_numeroProceso", OracleDbType.Decimal, ParameterDirection.Input, numeroProceso);
            dyParam.Add("pi_id_seguimiento", OracleDbType.Decimal, ParameterDirection.Input, idSeguimiento);
            dyParam.Add("pi_estadoEnvio", OracleDbType.Varchar2, ParameterDirection.Input, estadoEnvio);

            var query = "bepsa.pkg_reimpresiones.sp_reimp_upd_envio_v2";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Inserta el log en la tabla de procesos de reimpresiones
        /// </summary>
        public void InsertaLogProceso(decimal numeroProceso, 
                                      decimal idSeguimiento,
                                      decimal cantidadRegistros,
                                      string  codigoResultado,
                                      string  mensajeResultado,
                                      string  numeroTarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            string usuarioServicio = CodigoProcesadora.Bepsa.ToString().ToUpper();
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_numeroProceso", OracleDbType.Decimal, ParameterDirection.Input, numeroProceso);
            dyParam.Add("pi_idSeguimiento", OracleDbType.Decimal, ParameterDirection.Input, idSeguimiento);
            dyParam.Add("pi_usuarioServicio", OracleDbType.Varchar2, ParameterDirection.Input, usuarioServicio);
            dyParam.Add("pi_cantidadRegistros", OracleDbType.Decimal, ParameterDirection.Input, cantidadRegistros);
            dyParam.Add("pi_mensajeResultado", OracleDbType.Varchar2, ParameterDirection.Input, mensajeResultado);
            dyParam.Add("pi_codigoResultado", OracleDbType.Varchar2, ParameterDirection.Input, codigoResultado);
            dyParam.Add("pi_numeroTarjeta", OracleDbType.Varchar2, ParameterDirection.Input, numeroTarjeta);

            var query = "bepsa.pkg_reimpresiones.sp_reimp_insertaLogProceso_v2";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Obtiene el valor del parámetro
        /// </summary>
        public async Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia, string switchParametro)
        {
            var resultado = await _dbActive.DtParametroFecha
                .AsNoTracking()
                .Where(dt => dt.Id == id && 
                             dt.Secuencia == secuencia &&
                             dt.ValorTres == switchParametro)
                .FirstOrDefaultAsync();

            return resultado;
        }

        public async Task<List<SeguimientoRenovacion>> GetSeguimientosPendientes(int maxIntentos)
        {
            var resultado = await _dbActive.EnviadorReimpresionBepsa
                .AsNoTracking()
                .Where(e => e.Estado == (int)EstadoEnviadorReimpresion.Correcto &&
                            e.IdSeguimiento != null &&
                            _dbActive.LogReimpresionPrincipal
                                .Any(lr => lr.NumeroProceso == e.NumeroProceso &&
                                           lr.Procesadora == (int)CodigoProcesadora.Bepsa &&
                                           lr.Procesado == ConstanteDefault.ProcesadoCorrectamente &&
                                           !_dbActive.LogProcesosReimpresionBepsa
                                                .Any(lp => lp.NumeroProceso == lr.NumeroProceso &&
                                                           lp.NumeroTarjeta == lr.NumeroTarjetaViejo)))
                .Where(i => i.CantidadIntentoSeguimiento < maxIntentos)
                .Select(s => new SeguimientoRenovacion
                {
                    NumeroProceso = s.NumeroProceso,
                    Id = (decimal)s.IdSeguimiento,
                    CantidadIntentos = (int)s.CantidadIntentoSeguimiento
                })
                .Distinct()
                .ToListAsync();

            return resultado;
        }

        public void ActualizarCantidadIntento(decimal idSeguimiento)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            string usuarioServicio = CodigoProcesadora.Bepsa.ToString().ToUpper();
            oracleConexion.Open();

            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_idSeguimiento", OracleDbType.Decimal, ParameterDirection.Input, idSeguimiento);

            var query = "bepsa.pkg_reimpresiones.sp_actualiza_cantidad_reintento";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        public async Task<List<TarjetasEntregadasPendientes>> ObtenerTarjetasEntregadas()
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();

            const string biblioteca = "TCENTREGA";


            var resultado = await oracleConexion.QueryAsync<TarjetasEntregadasPendientes>(Queries.ObtenerTarjetasCourierEntregadas, new
            {
                biblioteca
            });

            return resultado.ToList();
        }

        public async Task ActualizarTarjetaEntregada(LoteCambioVencimiento loteCambioVencimiento)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            await oracleConexion.OpenAsync();

            const string archivo = "S";
            const string biblioteca = "TCENTREGA";


            await oracleConexion.ExecuteAsync(Queries.ActualizarEstadoTarjetaCourier, new
            {
                archivo,
                loteCambioVencimiento.Tarjeta,
                biblioteca
            });
        }
    }
}
