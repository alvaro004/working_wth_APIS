﻿using Continental.API.Infrastructure.DatabaseHelpers;
using Continental.API.Infrastructure.Settings;
using Continental.API.Infrastructure.Settings.DataBase;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories
{
    public class BloqueoDesbloqueoRepository : IBloqueoDesbloqueoRepository
    {
        private readonly string _connectionStringActive;
        private readonly string _connectionString;

        public BloqueoDesbloqueoRepository(IConfiguration configuraciones)
        {
            _connectionStringActive = configuraciones.GetConnectionString("Active");
            _connectionString = configuraciones.GetConnectionString("Oracle");
        }

        /// <summary>
        /// Obtiene el listado de bloqueos de TC pendientes de transmision
        /// </summary>
        public async Task<List<SolicitudBloqueo>> GetBloqueosPendientesAsync()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_obtenerbloqueosPendientes";
            var result = await SqlMapper.QueryAsync<SolicitudBloqueo>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);

            return result.Where(x => x.EsWaled == "N")?.ToList();
        }

        public async Task<List<SolicitudBloqueo>> GetBloqueosPendientesWaledAsync()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_obtenerbloqueosPendientes";
            var result = await SqlMapper.QueryAsync<SolicitudBloqueo>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);

            return result.Where(x => x.EsWaled == "S")?.ToList();
        }

        /// <summary>
        /// Registra en el Log del Envio
        /// </summary>
        public async Task InsertarLogEnvioAsync(string numeroProceso, string usuarioBepsa, string mensajeRetorno)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_nro_proceso", OracleDbType.Varchar2, ParameterDirection.Input, numeroProceso);
            dyParam.Add("pi_user_bepsa", OracleDbType.Char, ParameterDirection.Input, usuarioBepsa);
            dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, mensajeRetorno);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_insertarLogBloqDesbloq";
            await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Registra en el Log del Envio
        /// </summary>
        public async Task ActualizarRegistroBloqueoAsync(string numeroProceso, string codigoRetorno)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_nro_proceso", OracleDbType.Varchar2, ParameterDirection.Input, numeroProceso);
            dyParam.Add("pi_retorno", OracleDbType.Varchar2, ParameterDirection.Input, codigoRetorno);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_actualizaEnvio";
            await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Registra en el Log del Envio
        /// </summary>
        public void EnviarEmailBloqueo(EmailBloqueoDesbloqueo emailBloqueo)
        {

            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_tipo_email", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.TipoEmailBloqueo);
            dyParam.Add("pi_accion", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.Accion);
            dyParam.Add("pi_nro_tarjeta", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.NumeroTarjeta);
            dyParam.Add("pi_mensaje", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.MensajeRetorno);
            dyParam.Add("pi_asunto", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.Asunto);
            dyParam.Add("pi_destinatario", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.EmailUsuario);
            dyParam.Add("pi_intentos", OracleDbType.Varchar2, ParameterDirection.Input, emailBloqueo.NumeroIntento);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_envia_email";
            SqlMapper.Query(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// metodo de actualizacion de las transmisiones.
        /// </summary>
        /// <param name="numeroTarjeta"></param>
        /// <param name="codRespuesta"></param>
        /// <param name="msjRespuesta"></param>
        public string GetCantidadIntentos(string nroProceso)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            oracleConexion.Open();
            var datos = oracleConexion.ExecuteScalar(Queries.ObtenerCantidadIntentos, new
            {
                numeroProceso = nroProceso
            }).ToString();

            return datos;
        }

        /// <summary>
        /// Registra en el Log del Envio
        /// </summary>
        public async Task ActualizarEstadoBloqueoAsync(string numeroProceso, decimal estado)
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("pi_nro_proceso", OracleDbType.Varchar2, ParameterDirection.Input, numeroProceso);
            dyParam.Add("pi_estado", OracleDbType.Decimal, ParameterDirection.Input, estado);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_actualiza_EstadoEnvio_bepsa";
            await SqlMapper.QueryAsync(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Obtiene el listado de desbloqueos de TC pendientes de transmision
        /// </summary>
        public async Task<List<SolicitudDesbloqueo>> GetDesbloqueosPendientesAsync()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_DesbloqueosPendientes";
            var result = await SqlMapper.QueryAsync<SolicitudDesbloqueo>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);

            return result.Where(x => x.EsWaled == "N")?.ToList();
        }

        /// <summary>
        /// Obtiene el listado de desbloqueos de TC pendientes de transmision para Waled
        /// </summary>
        public async Task<List<SolicitudDesbloqueo>> GetDesbloqueosPendientesWaledAsync()
        {
            using var oracleConexion = new OracleConnection(_connectionString);
            oracleConexion.Open();
            var dyParam = new OracleDynamicParameters();
            dyParam.Add("po_datos", OracleDbType.RefCursor, ParameterDirection.Output);

            var query = "bepsa.pkg_bloqueo_desbloqueoTC.sp_DesbloqueosPendientes";
            var result = await SqlMapper.QueryAsync<SolicitudDesbloqueo>(oracleConexion, query, param: dyParam, commandType: CommandType.StoredProcedure, commandTimeout: 600);

            return result.Where(x => x.EsWaled == "S")?.ToList();
        }

        /// <summary>
        /// Consulta si la tarjeta es waled.
        /// </summary>
        /// <returns> <> 0 = Es Waled 0 = No es Waled </returns>
        public async Task<bool> EsWaledAsync(string numeroTarjeta)
        {
            using var oracleConexion = new OracleConnection(_connectionStringActive);
            await oracleConexion.OpenAsync();
            var datos = await oracleConexion.ExecuteScalarAsync<int>(Queries.EsWaled, new
            {
                pi_tarjeta = numeroTarjeta
            });
            return datos > 0;
        }

        public string EnmascararTarjeta(string numeroTarjeta)
        {
            string visibleDerecha = numeroTarjeta.Substring(numeroTarjeta.Length - 4);
            string visibleIzquierda = numeroTarjeta.Substring(0, 4);
            string formatoIzquierda = visibleIzquierda.PadRight(numeroTarjeta.Length - 8, '*');
            string formatoDerecha = visibleDerecha.PadLeft(numeroTarjeta.Length - 8, '*');
            string resultFormat = formatoIzquierda + formatoDerecha;
            return resultFormat;
        }

        public string CapitalizarPrimeraLetra(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return texto;

            return char.ToUpper(texto[0]) + texto[1..].ToLower();
        }
    }
}
