﻿using Continental.API.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Pagos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Entities.Reversos;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories
{
    public class RepositoryPagoEF : IRepositoryPagoEF
    {
        private readonly OracleDbContextActive _dbActive;
        private readonly OracleDbContext _db;

        public RepositoryPagoEF(OracleDbContextActive dbActive, OracleDbContext db)
        {
            _dbActive = dbActive;
            _db = db;
        }

        public async Task<List<LotePago>> ObtenerPagosPendientes(ParametricaPago parametricaPago) =>
            await _dbActive.Pago
               .AsNoTracking()
               .Where(t => t.EstadoPago == parametricaPago.EstadoPago &&
                           t.PagoProcesado == parametricaPago.PagoProceso &&
                           t.Procesadora == parametricaPago.Procesadora &&
                           t.OperacionTipo == parametricaPago.OperacionTipo &&
                           t.Intento < parametricaPago.Intento
            ).Take(parametricaPago.Cantidad).Select(p => new LotePago
            {
                Comprobante = p.Comprobante.ToString(),
                Importe = p.Monto,
                Moneda = 600,
                NumeroTarjeta = p.Tarjeta
            }).ToListAsync();

        public async Task<PagoEF> ObtenerPago(decimal comprobante) =>
            await _dbActive.Pago
              .AsNoTracking()
            .FirstOrDefaultAsync(t => t.Comprobante == comprobante);

        public async Task ActualizarEstadoPago(PagoEF pagoEF) =>
            await _db.Pago
                .Where(p => p.Comprobante == pagoEF.Comprobante)
                .ExecuteUpdateAsync(s => s.SetProperty(e => e.EstadoPago, pagoEF.EstadoPago)
                                          .SetProperty(e => e.PagoProcesado, pagoEF.PagoProcesado)
                                          .SetProperty(e => e.Intento, pagoEF.Intento)
                                          .SetProperty(e => e.FechaDisponible, pagoEF.FechaDisponible)
                                          .SetProperty(e => e.FechaExtracto, pagoEF.FechaExtracto)
                                          .SetProperty(e => e.FechaPago, pagoEF.FechaPago)
                                          .SetProperty(e => e.FechaModificacion, pagoEF.FechaModificacion)
                                          .SetProperty(e => e.CodigoResuesta, pagoEF.CodigoResuesta)
                                          .SetProperty(e => e.MensajeRespuesta, pagoEF.MensajeRespuesta));

        public async Task<Fechus> Fechus() =>
            await _dbActive.Fechus
               .AsNoTracking()
               .FirstOrDefaultAsync();

        public async Task ActualizarCajaDesc(CajaDescEF cajaDescEF) =>
            await _db.CajaDesc
                .Where(p => p.UsuarioRegistro == cajaDescEF.UsuarioRegistro &&
                            p.FechaRegistro == cajaDescEF.FechaRegistro &&
                            p.Operacion == cajaDescEF.Operacion &&
                            p.Comprobante == cajaDescEF.Comprobante &&
                            p.Recibo == cajaDescEF.Recibo &&
                            p.Monto == cajaDescEF.Monto &&
                            p.Efectivo == cajaDescEF.Efectivo &&
                            p.Cheque == cajaDescEF.Cheque &&
                            p.Cheque24 == cajaDescEF.Cheque24 &&
                            p.Cheque48 == cajaDescEF.Cheque48)
                .ExecuteUpdateAsync(s => s.SetProperty(e => e.Enviado, cajaDescEF.Enviado)
                                          .SetProperty(e => e.FechaEnvio, cajaDescEF.FechaEnvio)
                                          .SetProperty(e => e.HoraEnvio, cajaDescEF.HoraEnvio)
                                          .SetProperty(e => e.UsuarioEnvio, cajaDescEF.UsuarioEnvio));

        public async Task<DtParametrosFecha> ObtenerParametrica(decimal id, decimal secuencia) =>
            await _dbActive.DtParametroFecha
               .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == id && e.Secuencia == secuencia);

        public async Task<IEnumerable<decimal>> PagosRechazados(ParametricaPagoRechazado parametricaPagoRechazado) =>
            await _dbActive.Pago
               .AsNoTracking()
               .Where(t => parametricaPagoRechazado.Estados.Contains(t.EstadoPago) &&
                           t.CodigoResuesta == parametricaPagoRechazado.CodigoRespuesta &&
                           t.Procesadora == parametricaPagoRechazado.Procesadora &&
                           t.OperacionTipo == parametricaPagoRechazado.OperacionTipo
            ).Select(p => p.Comprobante).ToListAsync();

        public async Task<List<RequestReverso>> ObtenerReversossPendientes(ParametricaPago parametricaPago, DateTime fecha) =>
            await _dbActive.Pago
               .AsNoTracking()
               .Where(t => t.EstadoPago == parametricaPago.EstadoPago &&
                           t.PagoProcesado == parametricaPago.PagoProceso &&
                           t.Procesadora == parametricaPago.Procesadora &&
                           t.OperacionTipo == parametricaPago.OperacionTipo &&
                           t.Intento < parametricaPago.Intento &&
                           t.FechaRegistro == fecha
            ).Take(parametricaPago.Cantidad).Select(p => new RequestReverso
            {
                Comprobante = p.Comprobante
            }).ToListAsync();

        public async Task ActualizarEstadoReverso(PagoEF pagoEF) =>
            await _db.Pago
                .Where(p => p.Comprobante == pagoEF.Comprobante)
                .ExecuteUpdateAsync(s => s.SetProperty(e => e.EstadoPago, pagoEF.EstadoPago)
                                          .SetProperty(e => e.Reversado, pagoEF.Reversado)
                                          .SetProperty(e => e.Intento, pagoEF.Intento)
                                          .SetProperty(e => e.FechaModificacion, pagoEF.FechaModificacion)
                                          .SetProperty(e => e.CodigoResuesta, pagoEF.CodigoResuesta)
                                          .SetProperty(e => e.MensajeRespuesta, pagoEF.MensajeRespuesta));

    }
}
