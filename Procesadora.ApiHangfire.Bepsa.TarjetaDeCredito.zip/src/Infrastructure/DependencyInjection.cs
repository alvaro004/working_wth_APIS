﻿using Continental.API.Core.Interfaces;
using Continental.API.Infrastructure.Data;
using Continental.API.Infrastructure.Repositories;
using Continental.API.Infrastructure.Settings;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Core.Interfaces;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Data;
using Procesadora.ApiHangfire.Bepsa.TarjetaDeCredito.Infrastructure.Repositories;

namespace Continental.API.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AgregarInfraestructura(this IServiceCollection services)
        {
            services.BuildServiceProvider().GetService<IOptions<Configuraciones>>();
            services.AddTransient<IRepositoryAbmCredito, RepositoryAbmCredito>();
            services.AddTransient<IRepositoryActivacion,RepositoryActivacion>();
            services.AddTransient<IRepositoryReimpresion, RepositoryReimpresion>();
            services.AddTransient<IBloqueoDesbloqueoRepository, BloqueoDesbloqueoRepository>();
            services.AddTransient<IRepositoryPagoEF, RepositoryPagoEF>();
            services.AddTransient<IRepositoryPagoDapper, RepositoryPagoDapper>();
            services.AddTransient<IRepositoryTarjetaVirtualDapper, RepositoryTarjetaVirtualDapper>();
            services.AddTransient<IRenovacionRepository, RenovacionRepository>();
            services.AddTransient<IRepositoryListaBlanca, RepositoryListaBlanca>();
            services.AddHttpClient<IRepositoryAbmCredito, RepositoryAbmCredito>();
            services.AddHttpClient<IRepositoryActivacion, RepositoryActivacion>();
            services.AddHttpClient<IRepositoryReimpresion, RepositoryReimpresion>();
            services.AddHttpClient<IRepositoryListaBlanca, RepositoryListaBlanca>();
            var config = services.BuildServiceProvider().GetService<IConfiguration>();
            services.AddDbContext<OracleDbContextActive>(o =>
                 o.UseOracle(config.GetConnectionString("Active")));
            services.AddDbContext<OracleDbContext>(o =>
                 o.UseOracle(config.GetConnectionString("Oracle")));
            services.AddDbContext<OracleDbContextBi>(o =>
                o.UseOracle(config.GetConnectionString("OracleBi")));
            return services;
        }
    }
}
