# Descripcion del Proyecto
Api de transmision de altas, bajas y modificaciones de trajetas de credito procesadora Bepsa. Ejecuta el proceso que prepara las tarjetas y cuentas y luego las transmite al servicio.

# Pasos de ejecucion
Para configurar el proyecto para que se ejecute en desarrollo se debe modificar el archivo appsetting que se encuentra en la capa webapi y establecer  como proyecto
de inicio la capa web api, ademas se debe modificar la url del servicio de bepsa por la ip del proxy(wrapper) que corresponde a desarrollo.

# Quien mantiene y contribuye con el proyecto
Ruth Sanchez, Oscar Santacruz, Andrea Caballero

# Herramientas
Net core 3.1 y visual studio 2019

# Dependencias
Servicio Api externo de bepsa. Proyecto: Procesadora.Proxy.Bepsa.TarjetaDeCredito
# Recursos disponibles
/v1/api/bepsa/tarjeta/credito/cuenta/activacion: lista todas las cuentas de tarjetas de credito pendientes de activación y las transmite a la procesadora.
/v1/api/bepsa/tarjeta/credito/activacion: lista todas las tarjetas de credito pendientes de activación, las transmite a la procesadora y según respuesta del servicio marca la activación correcta en la entidad.
/v1/api/bepsa/tarjeta/credito/reimpresion: lista todas las tarjetas de crédito pendientes de reimpresión y transmite a la procesadora.